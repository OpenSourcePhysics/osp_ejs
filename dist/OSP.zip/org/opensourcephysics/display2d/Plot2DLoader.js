(function(){var P$=Clazz.newPackage("org.opensourcephysics.display2d"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Plot2DLoader", null, 'org.opensourcephysics.controls.XMLLoader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var p2d=obj;
control.setValue$S$O("grid data", p2d.getGridData$());
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var p2d=obj;
var child=control.getChildControl$S("grid data");
p2d.setGridData$org_opensourcephysics_display2d_GridData(child.loadObject$O(p2d.getGridData$()));
p2d.update$();
return p2d;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-01 19:14:14 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
