(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'javax.swing.SwingUtilities',['org.opensourcephysics.media.core.ClipControl','.Loader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VideoClipControl", null, 'org.opensourcephysics.media.core.ClipControl');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_VideoClip', function (videoClip) {
;C$.superclazz.c$$org_opensourcephysics_media_core_VideoClip.apply(this,[videoClip]);C$.$init$.apply(this);
this.video.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
}, 1);

Clazz.newMeth(C$, 'play$', function () {
this.video.play$();
});

Clazz.newMeth(C$, 'stop$', function () {
this.video.stop$();
});

Clazz.newMeth(C$, 'step$', function () {
this.video.stop$();
this.setStepNumber$I(this.stepNumber + 1);
});

Clazz.newMeth(C$, 'back$', function () {
this.video.stop$();
this.setStepNumber$I(this.stepNumber - 1);
});

Clazz.newMeth(C$, 'setStepNumber$I', function (n) {
if (n == this.stepNumber && this.clip.stepToFrame$I(n) == this.getFrameNumber$() ) {
return;
}n=Math.max(0, n);
var stepNum=Math.min(this.clip.getStepCount$() - 1, n);
var runner=((P$.VideoClipControl$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoClipControl$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
var m=this.b$['org.opensourcephysics.media.core.VideoClipControl'].clip.stepToFrame$I(this.$finals$.stepNum) + this.b$['org.opensourcephysics.media.core.VideoClipControl'].clip.getFrameShift$();
this.b$['org.opensourcephysics.media.core.VideoClipControl'].video.setFrameNumber$I(m);
});
})()
), Clazz.new_(P$.VideoClipControl$1.$init$,[this, {stepNum:stepNum}]));
$I$(1).invokeLater$Runnable(runner);
});

Clazz.newMeth(C$, 'getStepNumber$', function () {
return this.clip.frameToStep$I(this.video.getFrameNumber$());
});

Clazz.newMeth(C$, 'setRate$D', function (newRate) {
if ((newRate == 0 ) || (newRate == this.rate ) ) {
return;
}this.rate=Math.abs(newRate);
this.video.setRate$D(this.rate);
});

Clazz.newMeth(C$, 'getRate$', function () {
return this.video.getRate$();
});

Clazz.newMeth(C$, 'setLooping$Z', function (loops) {
if (loops == this.isLooping$() ) {
return;
}this.video.setLooping$Z(loops);
});

Clazz.newMeth(C$, 'isLooping$', function () {
return this.video.isLooping$();
});

Clazz.newMeth(C$, 'getFrameNumber$', function () {
var n=this.video.getFrameNumber$() - this.clip.getFrameShift$();
n=Math.max(0, n);
return n;
});

Clazz.newMeth(C$, 'isPlaying$', function () {
return this.video.isPlaying$();
});

Clazz.newMeth(C$, 'getTime$', function () {
var n=this.video.getFrameNumber$();
return (this.video.getFrameTime$I(n) - this.video.getStartTime$()) * this.timeStretch;
});

Clazz.newMeth(C$, 'getStepTime$I', function (stepNumber) {
var n=this.clip.stepToFrame$I(stepNumber);
return (this.video.getFrameTime$I(n) - this.video.getStartTime$()) * this.timeStretch;
});

Clazz.newMeth(C$, 'setFrameDuration$D', function (duration) {
if (duration == 0 ) {
return;
}duration=Math.abs(duration);
var ti=this.video.getFrameTime$I(this.video.getStartFrameNumber$());
var tf=this.video.getFrameTime$I(this.video.getEndFrameNumber$());
var count=this.video.getEndFrameNumber$() - this.video.getStartFrameNumber$();
if (count != 0) {
this.timeStretch=duration * count / (tf - ti);
}this.support.firePropertyChange$S$O$O("frameduration", null,  new Double(duration));
});

Clazz.newMeth(C$, 'getMeanFrameDuration$', function () {
var count=this.video.getEndFrameNumber$() - this.video.getStartFrameNumber$();
if (count != 0) {
var ti=this.video.getFrameTime$I(this.video.getStartFrameNumber$());
var tf=this.video.getFrameTime$I(this.video.getEndFrameNumber$());
return this.timeStretch * (tf - ti) / count;
}return this.timeStretch * this.video.getDuration$() / this.video.getFrameCount$();
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var name=e.getPropertyName$();
if (name.equals$O("framenumber")) {
var n=(e.getNewValue$()).intValue$();
if (n == this.videoFrameNumber) {
C$.superclazz.prototype.setFrameNumber$I.apply(this, [n - this.clip.getFrameShift$()]);
return;
}C$.superclazz.prototype.setFrameNumber$I.apply(this, [n - this.clip.getFrameShift$()]);
var nInt= new Integer(this.stepNumber);
this.support.firePropertyChange$S$O$O("stepnumber", null, nInt);
} else if (name.equals$O("playing")) {
this.support.firePropertyChange$java_beans_PropertyChangeEvent(e);
} else if (name.equals$O("rate") || name.equals$O("looping") ) {
this.support.firePropertyChange$java_beans_PropertyChangeEvent(e);
} else C$.superclazz.prototype.propertyChange$java_beans_PropertyChangeEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'dispose$', function () {
this.video.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-28 10:19:01 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
