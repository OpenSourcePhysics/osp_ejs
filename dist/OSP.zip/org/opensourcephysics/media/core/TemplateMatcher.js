(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.TPoint','org.opensourcephysics.display.Dataset','org.opensourcephysics.tools.DatasetCurveFitter','org.opensourcephysics.tools.FitBuilder','org.opensourcephysics.tools.UserFunction','java.awt.image.BufferedImage','java.util.HashMap',['java.awt.geom.Line2D','.Double'],['java.awt.geom.Point2D','.Double'],'java.util.TreeMap','java.util.ArrayList','java.awt.AlphaComposite']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TemplateMatcher");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.p=Clazz.new_($I$(1,1));
this.largeNumber=1.0E20;
this.pixelOffsets=Clazz.array(Double.TYPE, -1, [-1, 0, 1]);
this.xValues=Clazz.array(Double.TYPE, [3]);
this.yValues=Clazz.array(Double.TYPE, [3]);
this.alphas=Clazz.array(Integer.TYPE, [2]);
},1);

C$.$fields$=[['D',['largeNumber','peakHeight','peakWidth'],'I',['wTemplate','hTemplate','wTarget','hTarget','wTest','hTest','trimLeft','trimTop','index'],'O',['original','java.awt.image.BufferedImage','+template','+working','+match','mask','java.awt.Shape','pixels','int[]','+templateR','+templateG','+templateB','isPixelTransparent','boolean[]','targetPixels','int[]','+matchPixels','p','org.opensourcephysics.media.core.TPoint','fitter','org.opensourcephysics.tools.DatasetCurveFitter','dataset','org.opensourcephysics.display.Dataset','f','org.opensourcephysics.tools.UserFunction','pixelOffsets','double[]','+xValues','+yValues','alphas','int[]']]]

Clazz.newMeth(C$, 'c$$java_awt_image_BufferedImage$java_awt_Shape', function (image, maskShape) {
;C$.$init$.apply(this);
this.mask=maskShape;
this.setTemplate$java_awt_image_BufferedImage(image);
this.dataset=Clazz.new_($I$(2,1));
this.fitter=Clazz.new_([this.dataset, Clazz.new_($I$(4,1).c$$java_awt_Component,[null])],$I$(3,1).c$$org_opensourcephysics_display_Dataset$org_opensourcephysics_tools_FitBuilder);
this.fitter.setActive$Z(true);
this.fitter.setAutofit$Z(true);
this.f=Clazz.new_($I$(5,1).c$$S,["gaussian"]);
this.f.setParameters$SA$DA(Clazz.array(String, -1, ["a", "b", "c"]), Clazz.array(Double.TYPE, -1, [1, 0, 1]));
this.f.setExpression$S$SA("a*exp(-(x-b)^2/c)", Clazz.array(String, -1, ["x"]));
}, 1);

Clazz.newMeth(C$, 'setTemplate$java_awt_image_BufferedImage', function (image) {
if (this.template != null  && image.getType$() == 2  && this.wTemplate == image.getWidth$()  && this.hTemplate == image.getHeight$() ) {
this.template=image;
this.template.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.wTemplate, this.hTemplate, this.pixels);
for (var i=0; i < this.pixels.length; i++) {
var val=this.pixels[i];
this.templateR[i]=C$.getRed$I(val);
this.templateG[i]=C$.getGreen$I(val);
this.templateB[i]=C$.getBlue$I(val);
this.isPixelTransparent[i]=C$.getAlpha$I(val) == 0;
}
} else {
if (image.getType$() != 2) {
this.original=Clazz.new_([image.getWidth$(), image.getHeight$(), 2],$I$(6,1).c$$I$I$I);
this.original.createGraphics$().drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(image, 0, 0, null);
} else this.original=image;
this.template=this.buildTemplate$java_awt_image_BufferedImage$I$I(this.original, 255, 0);
this.setTemplate$java_awt_image_BufferedImage(this.template);
}});

Clazz.newMeth(C$, 'getTemplate$', function () {
if (this.template == null ) {
this.template=this.buildTemplate$java_awt_image_BufferedImage$I$I(this.original, 255, 0);
this.setTemplate$java_awt_image_BufferedImage(this.template);
}return this.template;
});

Clazz.newMeth(C$, 'buildTemplate$java_awt_image_BufferedImage$I$I', function (image, alphaInput, alphaOriginal) {
var w=image.getWidth$();
var h=image.getHeight$();
if (this.original.getWidth$() != w || this.original.getHeight$() != h ) return null;
if (alphaInput == 0 && alphaOriginal == 0 ) return this.template != null  ? this.template : this.original;
this.alphas[0]=alphaInput;
this.alphas[1]=alphaOriginal;
var input;
if (image.getType$() == 2) input=image;
 else {
input=Clazz.new_($I$(6,1).c$$I$I$I,[w, h, 2]);
input.createGraphics$().drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(image, 0, 0, null);
}if (this.working == null ) {
this.working=Clazz.new_($I$(6,1).c$$I$I$I,[w, h, 2]);
}if (this.template == null  || w != this.wTemplate  || h != this.hTemplate ) {
this.wTemplate=w;
this.hTemplate=h;
var len=w * h;
this.template=Clazz.new_($I$(6,1).c$$I$I$I,[w, h, 2]);
this.pixels=Clazz.array(Integer.TYPE, [len]);
this.templateR=Clazz.array(Integer.TYPE, [len]);
this.templateG=Clazz.array(Integer.TYPE, [len]);
this.templateB=Clazz.array(Integer.TYPE, [len]);
this.isPixelTransparent=Clazz.array(Boolean.TYPE, [len]);
this.matchPixels=Clazz.array(Integer.TYPE, [len]);
}var gWorking=this.working.createGraphics$();
alphaInput=Math.max(0, Math.min(255, alphaInput));
if (alphaInput > 0) {
gWorking.setComposite$java_awt_Composite(p$1.getComposite$I.apply(this, [alphaInput]));
gWorking.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(input, 0, 0, null);
}alphaOriginal=Math.max(0, Math.min(255, alphaOriginal));
if (alphaOriginal > 0) {
gWorking.setComposite$java_awt_Composite(p$1.getComposite$I.apply(this, [alphaOriginal]));
gWorking.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.original, 0, 0, null);
}this.working.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.wTemplate, this.hTemplate, this.pixels);
if (this.mask != null ) {
for (var i=0; i < this.pixels.length; i++) {
var inside=true;
var x=i % this.wTemplate;
var y=(i/this.wTemplate|0);
for (var j=0; j < 2; j++) {
for (var k=0; k < 2; k++) {
this.p.setLocation$D$D(x + j, y + k);
inside=inside && this.mask.contains$java_awt_geom_Point2D(this.p) ;
}
}
if (!inside) this.pixels[i]=this.pixels[i] & (0);
}
}this.template.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.wTemplate, this.hTemplate, this.pixels);
var trimRight=0;
var trimBottom=0;
this.trimLeft=this.trimTop=0;
var transparentEdge=true;
while (transparentEdge && this.trimLeft < this.wTemplate ){
for (var line=0; line < this.hTemplate; line++) {
var i=line * this.wTemplate + this.trimLeft;
transparentEdge=transparentEdge && C$.getAlpha$I(this.pixels[i]) == 0 ;
}
if (transparentEdge) this.trimLeft++;
}
transparentEdge=true;
while (transparentEdge && (this.trimLeft + trimRight) < this.wTemplate ){
for (var line=0; line < this.hTemplate; line++) {
var i=(line + 1) * this.wTemplate - 1 - trimRight;
transparentEdge=transparentEdge && C$.getAlpha$I(this.pixels[i]) == 0 ;
}
if (transparentEdge) trimRight++;
}
transparentEdge=true;
while (transparentEdge && this.trimTop < this.hTemplate ){
for (var col=0; col < this.wTemplate; col++) {
var i=this.trimTop * this.wTemplate + col;
transparentEdge=transparentEdge && C$.getAlpha$I(this.pixels[i]) == 0 ;
}
if (transparentEdge) this.trimTop++;
}
transparentEdge=true;
while (transparentEdge && (this.trimTop + trimBottom) < this.hTemplate ){
for (var col=0; col < this.wTemplate; col++) {
var i=(this.hTemplate - 1 - trimBottom ) * this.wTemplate + col;
transparentEdge=transparentEdge && C$.getAlpha$I(this.pixels[i]) == 0 ;
}
if (transparentEdge) trimBottom++;
}
if (this.trimLeft + trimRight + this.trimTop + trimBottom  > 0) {
this.wTemplate-=(this.trimLeft + trimRight);
this.hTemplate-=(this.trimTop + trimBottom);
this.wTemplate=Math.max(this.wTemplate, 1);
this.hTemplate=Math.max(this.hTemplate, 1);
var len=this.wTemplate * this.hTemplate;
this.pixels=Clazz.array(Integer.TYPE, [len]);
this.templateR=Clazz.array(Integer.TYPE, [len]);
this.templateG=Clazz.array(Integer.TYPE, [len]);
this.templateB=Clazz.array(Integer.TYPE, [len]);
this.isPixelTransparent=Clazz.array(Boolean.TYPE, [len]);
this.matchPixels=Clazz.array(Integer.TYPE, [len]);
var bi=Clazz.new_($I$(6,1).c$$I$I$I,[this.wTemplate, this.hTemplate, 2]);
bi.createGraphics$().drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.template, -this.trimLeft, -this.trimTop, null);
this.template=bi;
this.template.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.wTemplate, this.hTemplate, this.pixels);
}return this.template;
});

Clazz.newMeth(C$, 'getAlphas$', function () {
return this.alphas;
});

Clazz.newMeth(C$, 'setIndex$I', function (index) {
this.index=index;
});

Clazz.newMeth(C$, 'getIndex$', function () {
return this.index;
});

Clazz.newMeth(C$, 'getWorkingPixels$IA', function (pixels) {
if (pixels == null  || pixels.length != this.wTemplate * this.hTemplate ) {
pixels=Clazz.array(Integer.TYPE, [this.wTemplate * this.hTemplate]);
}this.working.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.wTemplate, this.hTemplate, pixels);
return pixels;
});

Clazz.newMeth(C$, 'setWorkingPixels$IA', function (pixels) {
if (pixels != null  && pixels.length == this.wTemplate * this.hTemplate ) this.working.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.wTemplate, this.hTemplate, pixels);
});

Clazz.newMeth(C$, 'getMatchLocation$java_awt_image_BufferedImage$java_awt_Rectangle', function (target, searchRect) {
this.wTarget=target.getWidth$();
this.hTarget=target.getHeight$();
var left=(this.wTemplate/2|0);
var right=left;
if (this.wTemplate % 2 > 0) right++;
var top=(this.hTemplate/2|0);
var bottom=top;
if (this.hTemplate % 2 > 0) bottom++;
searchRect.x=Math.max(left, Math.min(this.wTarget - right, searchRect.x));
searchRect.y=Math.max(top, Math.min(this.hTarget - bottom, searchRect.y));
searchRect.width=Math.min(this.wTarget - searchRect.x - right , searchRect.width);
searchRect.height=Math.min(this.hTarget - searchRect.y - bottom , searchRect.height);
if (searchRect.width <= 0 || searchRect.height <= 0 ) {
this.peakHeight=NaN;
this.peakWidth=NaN;
return null;
}var xMin=Math.max(0, searchRect.x - left);
var xMax=Math.min(this.wTarget, searchRect.x + searchRect.width + right );
var yMin=Math.max(0, searchRect.y - top);
var yMax=Math.min(this.hTarget, searchRect.y + searchRect.height + bottom );
this.wTest=xMax - xMin;
this.hTest=yMax - yMin;
if (target.getType$() != 1) {
var image=Clazz.new_($I$(6,1).c$$I$I$I,[this.wTarget, this.hTarget, 1]);
image.createGraphics$().drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(target, 0, 0, null);
target=image;
}this.targetPixels=Clazz.array(Integer.TYPE, [this.wTest * this.hTest]);
target.getRaster$().getDataElements$I$I$I$I$O(xMin, yMin, this.wTest, this.hTest, this.targetPixels);
var matchDiff=this.largeNumber;
var xMatch=0;
var yMatch=0;
var avgDiff=0;
for (var x=0; x <= searchRect.width; x++) {
for (var y=0; y <= searchRect.height; y++) {
var diff=p$1.getDifferenceAtTestPoint$I$I.apply(this, [x, y]);
avgDiff += diff;
if (diff < matchDiff ) {
matchDiff=diff;
xMatch=x;
yMatch=y;
}}
}
avgDiff /= (searchRect.width * searchRect.height);
this.peakHeight=avgDiff / matchDiff - 1;
this.peakWidth=NaN;
var dx=0;
var dy=0;
if (!Double.isInfinite$D(this.peakHeight)) {
this.xValues[1]=this.yValues[1]=this.peakHeight;
for (var i=-1; i < 2; i++) {
if (i == 0) continue;
var diff=p$1.getDifferenceAtTestPoint$I$I.apply(this, [xMatch + i, yMatch]);
this.xValues[i + 1]=avgDiff / diff - 1;
diff=p$1.getDifferenceAtTestPoint$I$I.apply(this, [xMatch, yMatch + i]);
this.yValues[i + 1]=avgDiff / diff - 1;
}
var pull=1 / (this.xValues[1] - this.xValues[0]);
var push=1 / (this.xValues[1] - this.xValues[2]);
if (Double.isNaN$D(pull)) pull=1.0E10;
if (Double.isNaN$D(push)) push=1.0E10;
dx=0.6 * (push - pull) / (push + pull);
var ratio=dx > 0  ? this.peakHeight / this.xValues[0] : this.peakHeight / this.xValues[2];
var wx=dx > 0  ? dx + 1 : dx - 1;
wx=wx * wx / Math.log(ratio);
pull=1 / (this.yValues[1] - this.yValues[0]);
push=1 / (this.yValues[1] - this.yValues[2]);
if (Double.isNaN$D(pull)) pull=1.0E10;
if (Double.isNaN$D(push)) push=1.0E10;
dy=0.6 * (push - pull) / (push + pull);
ratio=dy > 0  ? this.peakHeight / this.yValues[0] : this.peakHeight / this.yValues[2];
var wy=dy > 0  ? dy + 1 : dy - 1;
wy=wy * wy / Math.log(ratio);
this.dataset.clear$();
this.dataset.append$DA$DA(this.pixelOffsets, this.xValues);
var rmsDev=1;
for (var k=0; k < 3; k++) {
var c=k == 0 ? wx : k == 1 ? wx / 3 : wx * 3;
this.f.setParameterValue$I$D(0, this.peakHeight);
this.f.setParameterValue$I$D(1, dx);
this.f.setParameterValue$I$D(2, c);
rmsDev=this.fitter.fit$org_opensourcephysics_tools_KnownFunction(this.f);
if (rmsDev < 0.01 ) {
dx=this.f.getParameterValue$I(1);
this.peakWidth=this.f.getParameterValue$I(2);
break;
}}
if (!Double.isNaN$D(this.peakWidth)) {
this.dataset.clear$();
this.dataset.append$DA$DA(this.pixelOffsets, this.yValues);
for (var k=0; k < 3; k++) {
var c=k == 0 ? wy : k == 1 ? wy / 3 : wy * 3;
this.f.setParameterValue$I$D(0, this.peakHeight);
this.f.setParameterValue$I$D(1, dy);
this.f.setParameterValue$I$D(2, c);
rmsDev=this.fitter.fit$org_opensourcephysics_tools_KnownFunction(this.f);
if (rmsDev < 0.01 ) {
dy=this.f.getParameterValue$I(1);
this.peakWidth=(this.peakWidth + this.f.getParameterValue$I(2)) / 2;
break;
}}
if (rmsDev > 0.01 ) this.peakWidth=NaN;
}}xMatch=xMatch + searchRect.x - left - this.trimLeft;
yMatch=yMatch + searchRect.y - top - this.trimTop;
p$1.refreshMatchImage$java_awt_image_BufferedImage$I$I.apply(this, [target, xMatch, yMatch]);
return Clazz.new_($I$(1,1).c$$D$D,[xMatch + dx, yMatch + dy]);
});

Clazz.newMeth(C$, 'refreshMatchImage$java_awt_image_BufferedImage$I$I', function (target, x, y) {
target.getRaster$().getDataElements$I$I$I$I$O(x + 1, y + 1, this.wTemplate, this.hTemplate, this.matchPixels);
for (var i=0; i < this.matchPixels.length; i++) {
this.matchPixels[i]=C$.getValue$I$I(this.isPixelTransparent[i] ? 0 : 255, this.matchPixels[i]);
}
if (this.match == null  || this.match.getWidth$() != this.wTemplate  || this.match.getHeight$() != this.hTemplate ) {
this.match=Clazz.new_($I$(6,1).c$$I$I$I,[this.wTemplate, this.hTemplate, 2]);
}this.match.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.wTemplate, this.hTemplate, this.matchPixels);
}, p$1);

Clazz.newMeth(C$, 'getMatchLocation$java_awt_image_BufferedImage$java_awt_Rectangle$D$D$D$I', function (target, searchRect, x0, y0, theta, spread) {
this.wTarget=target.getWidth$();
this.hTarget=target.getHeight$();
var left=(this.wTemplate/2|0);
var right=left;
if (this.wTemplate % 2 > 0) right++;
var top=(this.hTemplate/2|0);
var bottom=top;
if (this.hTemplate % 2 > 0) bottom++;
searchRect.x=Math.max(left, Math.min(this.wTarget - right, searchRect.x));
searchRect.y=Math.max(top, Math.min(this.hTarget - bottom, searchRect.y));
searchRect.width=Math.min(this.wTarget - searchRect.x - right , searchRect.width);
searchRect.height=Math.min(this.hTarget - searchRect.y - bottom , searchRect.height);
if (searchRect.width <= 0 || searchRect.height <= 0 ) {
this.peakHeight=NaN;
this.peakWidth=NaN;
return null;
}var xMin=Math.max(0, searchRect.x - left);
var xMax=Math.min(this.wTarget, searchRect.x + searchRect.width + right );
var yMin=Math.max(0, searchRect.y - top);
var yMax=Math.min(this.hTarget, searchRect.y + searchRect.height + bottom );
this.wTest=xMax - xMin;
this.hTest=yMax - yMin;
if (target.getType$() != 1) {
var image=Clazz.new_($I$(6,1).c$$I$I$I,[this.wTarget, this.hTarget, 1]);
image.createGraphics$().drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(target, 0, 0, null);
target=image;
}this.targetPixels=Clazz.array(Integer.TYPE, [this.wTest * this.hTest]);
target.getRaster$().getDataElements$I$I$I$I$O(xMin, yMin, this.wTest, this.hTest, this.targetPixels);
var searchPts=this.getSearchPoints$java_awt_Rectangle$D$D$D(searchRect, x0, y0, theta);
if (searchPts == null ) {
this.peakHeight=NaN;
this.peakWidth=-1;
return null;
}var diffs=Clazz.new_($I$(7,1));
var matchDiff=this.largeNumber;
var xMatch=0;
var yMatch=0;
var avgDiff=0;
var matchPt=null;
for (var pt, $pt = searchPts.iterator$(); $pt.hasNext$()&&((pt=($pt.next$())),1);) {
var x=(pt.getX$()|0);
var y=(pt.getY$()|0);
var diff=p$1.getDifferenceAtTestPoint$I$I.apply(this, [x, y]);
diffs.put$O$O(pt, new Double(diff));
avgDiff += diff;
if (diff < matchDiff ) {
matchDiff=diff;
xMatch=x;
yMatch=y;
matchPt=pt;
}}
avgDiff /= searchPts.size$();
this.peakHeight=avgDiff / matchDiff - 1;
this.peakWidth=NaN;
var dl=0;
var matchIndex=searchPts.indexOf$O(matchPt);
if (!Double.isInfinite$D(this.peakHeight) && matchIndex > 0  && matchIndex < searchPts.size$() - 1 ) {
var pt=searchPts.get$I(matchIndex - 1);
var diff=(diffs.get$O(pt)).valueOf();
this.xValues[0]=-pt.distance$java_awt_geom_Point2D(matchPt);
this.yValues[0]=avgDiff / diff - 1;
this.xValues[1]=0;
this.yValues[1]=this.peakHeight;
pt=searchPts.get$I(matchIndex + 1);
diff=(diffs.get$O(pt)).valueOf();
this.xValues[2]=pt.distance$java_awt_geom_Point2D(matchPt);
this.yValues[2]=avgDiff / diff - 1;
var pull=-this.xValues[0] / (this.yValues[1] - this.yValues[0]);
var push=this.xValues[2] / (this.yValues[1] - this.yValues[2]);
if (Double.isNaN$D(pull)) pull=1.0E10;
if (Double.isNaN$D(push)) push=1.0E10;
dl=0.3 * (this.xValues[2] - this.xValues[0]) * (push - pull)  / (push + pull);
var ratio=dl > 0  ? this.peakHeight / this.yValues[0] : this.peakHeight / this.yValues[2];
var w=dl > 0  ? dl - this.xValues[0] : dl - this.xValues[2];
w=w * w / Math.log(ratio);
this.dataset.clear$();
this.dataset.append$DA$DA(this.xValues, this.yValues);
var rmsDev=1;
for (var k=0; k < 3; k++) {
var c=k == 0 ? w : k == 1 ? w / 3 : w * 3;
this.f.setParameterValue$I$D(0, this.peakHeight);
this.f.setParameterValue$I$D(1, dl);
this.f.setParameterValue$I$D(2, c);
rmsDev=this.fitter.fit$org_opensourcephysics_tools_KnownFunction(this.f);
if (rmsDev < 0.01 ) {
dl=this.f.getParameterValue$I(1);
this.peakWidth=this.f.getParameterValue$I(2);
break;
}}
}var dx=dl * Math.cos(theta);
var dy=dl * Math.sin(theta);
xMatch=xMatch + searchRect.x - left - this.trimLeft;
yMatch=yMatch + searchRect.y - top - this.trimTop;
p$1.refreshMatchImage$java_awt_image_BufferedImage$I$I.apply(this, [target, xMatch, yMatch]);
return Clazz.new_($I$(1,1).c$$D$D,[xMatch + dx, yMatch + dy]);
});

Clazz.newMeth(C$, 'getMatchImage$', function () {
return this.match;
});

Clazz.newMeth(C$, 'getMatchWidthAndHeight$', function () {
return Clazz.array(Double.TYPE, -1, [this.peakWidth, this.peakHeight]);
});

Clazz.newMeth(C$, 'getValue$I$I', function (a, argb) {
var r=C$.getRed$I(argb);
var g=C$.getGreen$I(argb);
var b=C$.getBlue$I(argb);
return C$.getValue$I$I$I$I(a, r, g, b);
}, 1);

Clazz.newMeth(C$, 'getValue$I$I$I$I', function (a, r, g, b) {
var value=(a << 24) + (r << 16) + (g << 8) + b ;
return value;
}, 1);

Clazz.newMeth(C$, 'getAlpha$I', function (value) {
var alpha=(value >> 24) & 255;
return alpha;
}, 1);

Clazz.newMeth(C$, 'getRed$I', function (value) {
var red=(value >> 16) & 255;
return red;
}, 1);

Clazz.newMeth(C$, 'getGreen$I', function (value) {
var green=(value >> 8) & 255;
return green;
}, 1);

Clazz.newMeth(C$, 'getBlue$I', function (value) {
var blue=value & 255;
return blue;
}, 1);

Clazz.newMeth(C$, 'getSearchPoints$java_awt_Rectangle$D$D$D', function (searchRect, x0, y0, theta) {
var slope=-Math.tan(theta);
var line=Clazz.new_($I$(8,1));
if (Math.abs(slope) > 1.0E10 ) {
line.setLine$D$D$D$D(x0, y0, x0, y0 + 1);
} else if (Math.abs(slope) < 1.0E-10 ) {
line.setLine$D$D$D$D(x0, y0, x0 + 1, y0);
} else {
line.setLine$D$D$D$D(x0, y0, x0 + 1, y0 + slope);
}var p1=Clazz.new_($I$(9,1));
var p2=Clazz.new_($I$(9,1).c$$D$D,[NaN, NaN]);
var p=p1;
var foundBoth=false;
var d=searchRect.x;
var data=p$1.getDistanceAndPointAtX$java_awt_geom_Line2D$D.apply(this, [line, d]);
if (data != null ) {
p.setLocation$java_awt_geom_Point2D(data[1]);
if (p.getY$() >= searchRect.y  && p.getY$() <= searchRect.y + searchRect.height  ) {
p=p2;
}}d += searchRect.width;
data=p$1.getDistanceAndPointAtX$java_awt_geom_Line2D$D.apply(this, [line, d]);
if (data != null ) {
p.setLocation$java_awt_geom_Point2D(data[1]);
if (p.getY$() >= searchRect.y  && p.getY$() <= searchRect.y + searchRect.height  ) {
if (p === p1 ) p=p2;
 else foundBoth=true;
}}if (!foundBoth) {
d=searchRect.y;
data=p$1.getDistanceAndPointAtY$java_awt_geom_Line2D$D.apply(this, [line, d]);
if (data != null ) {
p.setLocation$java_awt_geom_Point2D(data[1]);
if (p.getX$() >= searchRect.x  && p.getX$() <= searchRect.x + searchRect.width  ) {
if (p === p1 ) p=p2;
 else if (!p1.equals$O(p2)) foundBoth=true;
}}}if (!foundBoth) {
d += searchRect.height;
data=p$1.getDistanceAndPointAtY$java_awt_geom_Line2D$D.apply(this, [line, d]);
if (data != null ) {
p.setLocation$java_awt_geom_Point2D(data[1]);
if (p.getX$() >= searchRect.x  && p.getX$() <= searchRect.x + searchRect.width  ) {
if (p === p2  && !p1.equals$O(p2) ) foundBoth=true;
}}}if (foundBoth) {
line.setLine$java_awt_geom_Point2D$java_awt_geom_Point2D(p1, p2);
if (p1.getX$() > p2.getX$() ) {
line.setLine$java_awt_geom_Point2D$java_awt_geom_Point2D(p2, p1);
}var xMin=(Math.ceil(Math.min(p1.getX$(), p2.getX$()))|0);
var xMax=(Math.floor(Math.max(p1.getX$(), p2.getX$()))|0);
var yMin=(Math.ceil(Math.min(p1.getY$(), p2.getY$()))|0);
var yMax=(Math.floor(Math.max(p1.getY$(), p2.getY$()))|0);
var intersections=Clazz.new_($I$(10,1));
for (var x=xMin; x <= xMax; x++) {
var next=p$1.getDistanceAndPointAtX$java_awt_geom_Line2D$D.apply(this, [line, x]);
if (next == null ) continue;
intersections.put$O$O(next[0], next[1]);
}
for (var y=yMin; y <= yMax; y++) {
var next=p$1.getDistanceAndPointAtY$java_awt_geom_Line2D$D.apply(this, [line, y]);
if (next == null ) continue;
intersections.put$O$O(next[0], next[1]);
}
p=null;
var searchPts=Clazz.new_($I$(11,1));
for (var key, $key = intersections.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
var next=intersections.get$O(key);
if (p != null ) {
var x=(p.getX$() + next.getX$()) / 2 - searchRect.x;
var y=(p.getY$() + next.getY$()) / 2 - searchRect.y;
p.setLocation$D$D(x, y);
searchPts.add$O(p);
}p=next;
}
return searchPts;
}return null;
});

Clazz.newMeth(C$, 'getDistanceAndPointAtX$java_awt_geom_Line2D$D', function (line, x) {
var dx=line.getX2$() - line.getX1$();
if (dx == 0 ) return null;
var u=(x - line.getX1$()) / dx;
var y=line.getY1$() + u * (line.getY2$() - line.getY1$());
return Clazz.array(java.lang.Object, -1, [new Double(u), Clazz.new_($I$(9,1).c$$D$D,[x, y])]);
}, p$1);

Clazz.newMeth(C$, 'getDistanceAndPointAtY$java_awt_geom_Line2D$D', function (line, y) {
var dy=line.getY2$() - line.getY1$();
if (dy == 0 ) return null;
var u=(y - line.getY1$()) / dy;
var x=line.getX1$() + u * (line.getX2$() - line.getX1$());
return Clazz.array(java.lang.Object, -1, [new Double(u), Clazz.new_($I$(9,1).c$$D$D,[x, y])]);
}, p$1);

Clazz.newMeth(C$, 'getDifferenceAtTestPoint$I$I', function (x, y) {
var diff=0;
for (var i=0; i < this.wTemplate; i++) {
for (var j=0; j < this.hTemplate; j++) {
var templateIndex=j * this.wTemplate + i;
var testIndex=(y + j) * this.wTest + x + i;
if (testIndex < 0 || testIndex >= this.targetPixels.length ) return NaN;
if (!this.isPixelTransparent[templateIndex]) {
var pixel=this.targetPixels[testIndex];
diff += p$1.getRGBDifference$I$I$I$I.apply(this, [pixel, this.templateR[templateIndex], this.templateG[templateIndex], this.templateB[templateIndex]]);
}}
}
return diff;
}, p$1);

Clazz.newMeth(C$, 'getRGBDifference$I$I$I$I', function (pixel, r, g, b) {
var rPix=(pixel >> 16) & 255;
var gPix=(pixel >> 8) & 255;
var bPix=(pixel) & 255;
var dr=r - rPix;
var dg=g - gPix;
var db=b - bPix;
return dr * dr + dg * dg + db * db;
}, p$1);

Clazz.newMeth(C$, 'getComposite$I', function (alpha) {
var a=1.0 * alpha / 255;
return $I$(12).getInstance$I$F(3, a);
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:12 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
