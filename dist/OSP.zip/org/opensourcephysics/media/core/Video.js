(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Video", null, null, ['org.opensourcephysics.media.core.InteractiveImage', 'org.opensourcephysics.media.core.Playable', 'org.opensourcephysics.media.core.Trackable', 'java.beans.PropertyChangeListener']);

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-28 10:19:01 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
