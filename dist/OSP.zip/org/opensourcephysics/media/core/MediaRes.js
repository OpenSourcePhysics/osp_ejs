(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'java.util.Locale','java.util.ResourceBundle']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MediaRes");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['BUNDLE_NAME'],'O',['resourceLocale','java.util.Locale','res','java.util.ResourceBundle']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getString$S', function (key) {
try {
return C$.res.getString$S(key);
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.util.MissingResourceException")){
return "!" + key + "!" ;
} else {
throw ex;
}
}
}, 1);

Clazz.newMeth(C$, 'setLocale$java_util_Locale', function (locale) {
C$.resourceLocale=locale;
C$.res=$I$(2).getBundle$S$java_util_Locale(C$.BUNDLE_NAME, locale);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.BUNDLE_NAME="org.opensourcephysics.resources.media.video";
C$.resourceLocale=$I$(1).getDefault$();
C$.res=$I$(2).getBundle$S$java_util_Locale(C$.BUNDLE_NAME, C$.resourceLocale);
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-28 10:19:01 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
