(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.MediaRes','java.awt.Toolkit','javax.swing.JLabel','org.opensourcephysics.media.core.DecimalField','javax.swing.JSlider','javax.swing.BorderFactory','java.awt.GridBagLayout','javax.swing.JPanel','java.awt.GridBagConstraints','java.awt.Insets','java.awt.FlowLayout','org.opensourcephysics.media.core.GhostFilter',['org.opensourcephysics.media.core.GhostFilter','.Inspector'],'javax.swing.JOptionPane','java.awt.image.BufferedImage',['org.opensourcephysics.media.core.GhostFilter','.Loader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GhostFilter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.Filter');
C$.$classes$=[['Inspector',2],['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.defaultFade=0.05;
},1);

C$.$fields$=[['D',['fade','defaultFade'],'O',['pixels','int[]','+values','inspector','org.opensourcephysics.media.core.GhostFilter.Inspector','fadeLabel','javax.swing.JLabel','fadeField','org.opensourcephysics.media.core.NumberField','fadeSlider','javax.swing.JSlider']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.setFade$D(this.defaultFade);
this.hasInspector=true;
}, 1);

Clazz.newMeth(C$, 'setFade$D', function (fade) {
var prev= new Double(this.fade);
this.fade=Math.min(Math.abs(fade), 1);
this.support.firePropertyChange$S$O$O("fade", prev,  new Double(fade));
});

Clazz.newMeth(C$, 'getFade$', function () {
return this.fade;
});

Clazz.newMeth(C$, 'setEnabled$Z', function (enabled) {
if (this.isEnabled$() == enabled ) {
return;
}this.source=null;
C$.superclazz.prototype.setEnabled$Z.apply(this, [enabled]);
});

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}p$1.setOutputToGhost.apply(this, []);
return this.output;
});

Clazz.newMeth(C$, 'getInspector$', function () {
var myInspector=this.inspector;
if (myInspector == null ) {
myInspector=Clazz.new_($I$(13,1),[this, null]);
}if (myInspector.isModal$() && this.vidPanel != null  ) {
this.frame=$I$(14).getFrameForComponent$java_awt_Component(this.vidPanel);
myInspector.setVisible$Z(false);
myInspector.dispose$();
myInspector=Clazz.new_($I$(13,1),[this, null]);
}this.inspector=myInspector;
this.inspector.initialize$();
return this.inspector;
});

Clazz.newMeth(C$, 'clear$', function () {
this.source=null;
this.support.firePropertyChange$S$O$O("image", null, null);
});

Clazz.newMeth(C$, 'refresh$', function () {
C$.superclazz.prototype.refresh$.apply(this, []);
if (this.inspector != null ) {
this.inspector.setTitle$S($I$(1).getString$S("Filter.Ghost.Title"));
this.fadeLabel.setText$S($I$(1).getString$S("Filter.Ghost.Label.Fade"));
this.fadeSlider.setToolTipText$S($I$(1).getString$S("Filter.Ghost.ToolTip.Fade"));
var enabled=this.isEnabled$();
this.fadeLabel.setEnabled$Z(enabled);
this.fadeSlider.setEnabled$Z(enabled);
this.fadeField.setEnabled$Z(enabled);
this.inspector.pack$();
}});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (sourceImage) {
this.source=sourceImage;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
this.pixels=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.values=Clazz.array(Integer.TYPE, [this.w * this.h]);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(15,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}this.output=Clazz.new_($I$(15,1).c$$I$I$I,[this.w, this.h, 1]);
this.output.createGraphics$().drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
this.output.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
var pixel;
var r;
var g;
var b;
for (var i=0; i < this.values.length; i++) {
pixel=this.pixels[i];
r=(pixel >> 16) & 255;
g=(pixel >> 8) & 255;
b=(pixel) & 255;
this.values[i]=((r + g + b )/3|0);
}
}, p$1);

Clazz.newMeth(C$, 'setOutputToGhost', function () {
this.input.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
var pixel;
var r;
var g;
var b;
var v;
var ghost;
for (var i=0; i < this.pixels.length; i++) {
pixel=this.pixels[i];
r=(pixel >> 16) & 255;
g=(pixel >> 8) & 255;
b=(pixel) & 255;
v=((r + g + b )/3|0);
ghost=(((1 - this.fade) * this.values[i])|0);
if (ghost > v) {
this.pixels[i]=(ghost << 16) | (ghost << 8) | ghost ;
this.values[i]=ghost;
} else {
this.values[i]=v;
}}
this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixels);
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(16,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.GhostFilter, "Inspector", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[this.this$0.frame, !(Clazz.instanceOf(this.this$0.frame, "org.opensourcephysics.display.OSPFrame"))]);C$.$init$.apply(this);
this.setTitle$S($I$(1).getString$S("Filter.Ghost.Title"));
this.setResizable$Z(false);
this.createGUI$();
this.this$0.refresh$.apply(this.this$0, []);
this.pack$();
var rect=this.getBounds$();
var dim=$I$(2).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - rect.width)/2|0);
var y=((dim.height - rect.height)/2|0);
this.setLocation$I$I(x, y);
}, 1);

Clazz.newMeth(C$, 'createGUI$', function () {
this.this$0.fadeLabel=Clazz.new_($I$(3,1));
this.this$0.fadeField=Clazz.new_($I$(4,1).c$$I$I,[4, 2]);
this.this$0.fadeField.setMaxValue$D(0.5);
this.this$0.fadeField.setMinValue$D(0);
this.this$0.fadeField.addActionListener$java_awt_event_ActionListener(((P$.GhostFilter$Inspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "GhostFilter$Inspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.GhostFilter'].setFade$D.apply(this.b$['org.opensourcephysics.media.core.GhostFilter'], [this.b$['org.opensourcephysics.media.core.GhostFilter'].fadeField.getValue$()]);
this.b$['org.opensourcephysics.media.core.GhostFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.GhostFilter.Inspector'], []);
this.b$['org.opensourcephysics.media.core.GhostFilter'].fadeField.selectAll$();
});
})()
), Clazz.new_(P$.GhostFilter$Inspector$1.$init$,[this, null])));
this.this$0.fadeField.addFocusListener$java_awt_event_FocusListener(((P$.GhostFilter$Inspector$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "GhostFilter$Inspector$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.GhostFilter'].fadeField.selectAll$();
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.b$['org.opensourcephysics.media.core.GhostFilter'].setFade$D.apply(this.b$['org.opensourcephysics.media.core.GhostFilter'], [this.b$['org.opensourcephysics.media.core.GhostFilter'].fadeField.getValue$()]);
this.b$['org.opensourcephysics.media.core.GhostFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.GhostFilter.Inspector'], []);
});
})()
), Clazz.new_(P$.GhostFilter$Inspector$2.$init$,[this, null])));
this.this$0.fadeSlider=Clazz.new_($I$(5,1).c$$I$I$I,[0, 0, 0]);
this.this$0.fadeSlider.setMaximum$I(50);
this.this$0.fadeSlider.setMinimum$I(0);
this.this$0.fadeSlider.setBorder$javax_swing_border_Border($I$(6).createEmptyBorder$I$I$I$I(0, 2, 0, 2));
this.this$0.fadeSlider.addChangeListener$javax_swing_event_ChangeListener(((P$.GhostFilter$Inspector$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "GhostFilter$Inspector$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.ChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
var i=this.b$['org.opensourcephysics.media.core.GhostFilter'].fadeSlider.getValue$();
if (i != ((this.b$['org.opensourcephysics.media.core.GhostFilter'].getFade$.apply(this.b$['org.opensourcephysics.media.core.GhostFilter'], []) * 100)|0)) {
this.b$['org.opensourcephysics.media.core.GhostFilter'].setFade$D.apply(this.b$['org.opensourcephysics.media.core.GhostFilter'], [i / 100.0]);
this.b$['org.opensourcephysics.media.core.GhostFilter.Inspector'].updateDisplay$.apply(this.b$['org.opensourcephysics.media.core.GhostFilter.Inspector'], []);
}});
})()
), Clazz.new_(P$.GhostFilter$Inspector$3.$init$,[this, null])));
var gridbag=Clazz.new_($I$(7,1));
var panel=Clazz.new_($I$(8,1).c$$java_awt_LayoutManager,[gridbag]);
this.setContentPane$java_awt_Container(panel);
var c=Clazz.new_($I$(9,1));
c.anchor=13;
c.fill=0;
c.weightx=0.0;
c.gridx=0;
c.insets=Clazz.new_($I$(10,1).c$$I$I$I$I,[5, 5, 0, 2]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.fadeLabel, c);
panel.add$java_awt_Component(this.this$0.fadeLabel);
c.fill=2;
c.gridx=1;
c.insets=Clazz.new_($I$(10,1).c$$I$I$I$I,[5, 0, 0, 0]);
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.fadeField, c);
panel.add$java_awt_Component(this.this$0.fadeField);
c.gridx=2;
c.insets=Clazz.new_($I$(10,1).c$$I$I$I$I,[5, 0, 0, 0]);
c.weightx=1.0;
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.this$0.fadeSlider, c);
panel.add$java_awt_Component(this.this$0.fadeSlider);
var buttonbar=Clazz.new_([Clazz.new_($I$(11,1))],$I$(8,1).c$$java_awt_LayoutManager);
buttonbar.add$java_awt_Component(this.this$0.ableButton);
buttonbar.add$java_awt_Component(this.this$0.clearButton);
buttonbar.add$java_awt_Component(this.this$0.closeButton);
c.gridx=2;
c.gridy=1;
gridbag.setConstraints$java_awt_Component$java_awt_GridBagConstraints(buttonbar, c);
panel.add$java_awt_Component(buttonbar);
});

Clazz.newMeth(C$, 'initialize$', function () {
this.updateDisplay$();
this.this$0.refresh$.apply(this.this$0, []);
});

Clazz.newMeth(C$, 'updateDisplay$', function () {
this.this$0.fadeField.setValue$D(this.this$0.getFade$.apply(this.this$0, []));
this.this$0.fadeSlider.setValue$I(((100 * this.this$0.getFade$.apply(this.this$0, []))|0));
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.GhostFilter, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
control.setValue$S$D("fade", filter.getFade$());
if ((filter.frame != null ) && (filter.inspector != null ) && filter.inspector.isVisible$()  ) {
var x=filter.inspector.getLocation$().x - filter.frame.getLocation$().x;
var y=filter.inspector.getLocation$().y - filter.frame.getLocation$().y;
control.setValue$S$I("inspector_x", x);
control.setValue$S$I("inspector_y", y);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(12,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (control.getPropertyNames$().contains$O("fade")) {
filter.setFade$D(control.getDouble$S("fade"));
}filter.inspectorX=control.getInt$S("inspector_x");
filter.inspectorY=control.getInt$S("inspector_y");
return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-01 19:14:16 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
