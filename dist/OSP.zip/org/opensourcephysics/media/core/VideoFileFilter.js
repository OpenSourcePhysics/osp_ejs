(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'org.opensourcephysics.media.core.VideoIO','org.opensourcephysics.media.core.MediaRes','java.util.TreeSet']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VideoFileFilter", null, 'javax.swing.filechooser.FileFilter', 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.type="Video";
},1);

C$.$fields$=[['S',['type','description'],'O',['extensions','String[]']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'c$$S$SA', function (containerType, extensions) {
Clazz.super_(C$, this);
if (containerType != null  && extensions != null   && extensions.length > 0 ) {
this.type=containerType;
this.extensions=extensions;
}}, 1);

Clazz.newMeth(C$, 'accept$java_io_File', function (f) {
if (f == null ) {
return false;
}if (f.isDirectory$()) {
return true;
}if (this.extensions != null ) {
var extension=$I$(1).getExtension$java_io_File(f);
if (extension != null ) {
for (var next, $next = 0, $$next = this.extensions; $next<$$next.length&&((next=($$next[$next])),1);$next++) {
if (extension.toLowerCase$().equals$O(next.toLowerCase$())) return true;
}
}} else for (var next, $next = $I$(1).singleVideoTypeFilters.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
if (next.accept$java_io_File(f)) return true;
}
return false;
});

Clazz.newMeth(C$, 'getDescription$', function () {
if (this.description != null ) return this.description;
var desc=$I$(2,"getString$S",[this.type.toUpperCase$() + "FileFilter.Description"]);
if (this.extensions != null ) {
desc += " (";
for (var i=0; i < this.extensions.length; i++) {
if (i > 0) desc += ", ";
desc += "." + this.extensions[i];
}
desc += ")";
}return this.description=desc;
});

Clazz.newMeth(C$, 'getDefaultExtension$', function () {
if (this.extensions != null ) return this.extensions[0];
for (var next, $next = $I$(1).singleVideoTypeFilters.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
var ext=next.getDefaultExtension$();
if (ext != null ) return ext;
}
return null;
});

Clazz.newMeth(C$, 'getExtensions$', function () {
if (this.extensions != null ) return this.extensions;
var set=Clazz.new_($I$(3,1));
for (var next, $next = $I$(1).singleVideoTypeFilters.iterator$(); $next.hasNext$()&&((next=($next.next$())),1);) {
var exts=next.getExtensions$();
for (var ext, $ext = 0, $$ext = exts; $ext<$$ext.length&&((ext=($$ext[$ext])),1);$ext++) set.add$O(ext);

}
return set.toArray$OA(Clazz.array(String, [set.size$()]));
});

Clazz.newMeth(C$, 'getContainerType$', function () {
return this.type;
});

Clazz.newMeth(C$, ['compareTo$org_opensourcephysics_media_core_VideoFileFilter','compareTo$O'], function (filter) {
return this.getDescription$().compareTo$S(filter.getDescription$());
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-01 19:14:17 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
