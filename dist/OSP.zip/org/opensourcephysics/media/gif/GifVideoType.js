(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.gif"),I$=[[0,'org.opensourcephysics.media.core.VideoFileFilter','org.opensourcephysics.media.gif.GifVideo','org.opensourcephysics.controls.OSPLog','org.opensourcephysics.media.gif.GifVideoRecorder']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GifVideoType", null, null, 'org.opensourcephysics.media.core.VideoType');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['gifFilter','org.opensourcephysics.media.core.VideoFileFilter']]]

Clazz.newMeth(C$, 'getVideo$S', function (name) {
try {
var video=Clazz.new_($I$(2,1).c$$S,[name]);
video.setProperty$S$O("video_type", this);
return video;
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
$I$(3,"fine$S",[ex.getMessage$()]);
return null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'getRecorder$', function () {
return Clazz.new_($I$(4,1));
});

Clazz.newMeth(C$, 'canRecord$', function () {
return true;
});

Clazz.newMeth(C$, 'getDescription$', function () {
return C$.gifFilter.getDescription$();
});

Clazz.newMeth(C$, 'getDefaultExtension$', function () {
return C$.gifFilter.getDefaultExtension$();
});

Clazz.newMeth(C$, 'getFileFilters$', function () {
return Clazz.array($I$(1), -1, [C$.gifFilter]);
});

Clazz.newMeth(C$, 'getDefaultFileFilter$', function () {
return C$.gifFilter;
});

Clazz.newMeth(C$, 'isType$org_opensourcephysics_media_core_Video', function (video) {
return video.getClass$().equals$O(Clazz.getClass($I$(2)));
});

C$.$static$=function(){C$.$static$=0;
C$.gifFilter=Clazz.new_(["gif", Clazz.array(String, -1, ["gif"])],$I$(1,1).c$$S$SA);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:12 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
