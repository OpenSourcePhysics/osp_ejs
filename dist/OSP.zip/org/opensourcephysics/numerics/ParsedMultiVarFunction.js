(function(){var P$=Clazz.newPackage("org.opensourcephysics.numerics"),I$=[[0,'org.opensourcephysics.numerics.SuryonoParser']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParsedMultiVarFunction", null, null, 'org.opensourcephysics.numerics.MultiVarFunction');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['fStr'],'O',['$function','org.opensourcephysics.numerics.MultiVarFunction','functionNames','String[]']]]

Clazz.newMeth(C$, 'c$$S$SA', function (_fStr, $var) {
;C$.$init$.apply(this);
this.fStr=_fStr;
var parser=null;
parser=Clazz.new_($I$(1,1).c$$S$SA,[this.fStr, $var]);
this.$function=parser;
this.functionNames=parser.getFunctionNames$();
}, 1);

Clazz.newMeth(C$, 'evaluate$DA', function (x) {
return this.$function.evaluate$DA(x);
});

Clazz.newMeth(C$, 'toString', function () {
return "f(x) = " + this.fStr;
});

Clazz.newMeth(C$, 'getFunctionNames$', function () {
return this.functionNames;
});

Clazz.newMeth(C$, 'evaluatedToNaN$', function () {
if (Clazz.instanceOf(this.$function, "org.opensourcephysics.numerics.SuryonoParser")) {
return (this.$function).evaluatedToNaN$();
}return false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:12 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
