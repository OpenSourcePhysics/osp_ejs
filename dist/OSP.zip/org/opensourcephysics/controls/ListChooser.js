(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),p$1={},I$=[[0,'javax.swing.JPanel','javax.swing.JOptionPane','javax.swing.JLabel','javax.swing.BorderFactory','javax.swing.JButton','org.opensourcephysics.controls.ControlsRes','javax.swing.BoxLayout','javax.swing.Box','java.awt.Color','javax.swing.JScrollPane','java.awt.Dimension','java.awt.BorderLayout','java.awt.Toolkit','java.awt.Rectangle','javax.swing.JCheckBox','java.util.ArrayList','org.opensourcephysics.tools.FontSizer']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ListChooser", null, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.checkPane=Clazz.new_($I$(1,1));
this.applyChanges=false;
this.separator=":  ";
},1);

C$.$fields$=[['Z',['applyChanges'],'S',['separator'],'O',['checkPane','javax.swing.JPanel','objects','Object[]','selections','boolean[]','checkBoxes','javax.swing.JCheckBox[]','instructions','javax.swing.JLabel','lightFont','java.awt.Font']]]

Clazz.newMeth(C$, 'c$$S$S', function (title, text) {
C$.c$$S$S$javax_swing_JDialog.apply(this, [title, text, null]);
}, 1);

Clazz.newMeth(C$, 'c$$S$S$java_awt_Component', function (title, text, owner) {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[$I$(2).getFrameForComponent$java_awt_Component(owner), true]);C$.$init$.apply(this);
this.setTitle$S(title);
this.instructions=Clazz.new_($I$(3,1).c$$S,[" " + text]);
this.instructions.setBorder$javax_swing_border_Border($I$(4).createEmptyBorder$I$I$I$I(0, 0, 0, 6));
p$1.createGUI.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$S$S$javax_swing_JDialog', function (title, text, owner) {
;C$.superclazz.c$$java_awt_Dialog$Z.apply(this,[owner, true]);C$.$init$.apply(this);
this.setTitle$S(title);
this.instructions=Clazz.new_($I$(3,1).c$$S,[" " + text]);
this.instructions.setBorder$javax_swing_border_Border($I$(4).createEmptyBorder$I$I$I$I(0, 0, 0, 6));
p$1.createGUI.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'createGUI', function () {
this.lightFont=Clazz.new_($I$(3,1)).getFont$().deriveFont$I(0);
var cancelButton=Clazz.new_([$I$(6).getString$S("Chooser.Button.Cancel")],$I$(5,1).c$$S);
var okButton=Clazz.new_([$I$(6).getString$S("Chooser.Button.OK")],$I$(5,1).c$$S);
var selectAllButton=Clazz.new_([$I$(6).getString$S("Chooser.Button.SelectAll")],$I$(5,1).c$$S);
cancelButton.addActionListener$java_awt_event_ActionListener(((P$.ListChooser$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "ListChooser$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['java.awt.Dialog'].setVisible$Z.apply(this.b$['java.awt.Dialog'], [false]);
});
})()
), Clazz.new_(P$.ListChooser$1.$init$,[this, null])));
okButton.addActionListener$java_awt_event_ActionListener(((P$.ListChooser$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "ListChooser$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
for (var i=0; i < this.b$['org.opensourcephysics.controls.ListChooser'].checkBoxes.length; i++) {
this.b$['org.opensourcephysics.controls.ListChooser'].selections[i]=this.b$['org.opensourcephysics.controls.ListChooser'].checkBoxes[i].isSelected$();
}
this.b$['org.opensourcephysics.controls.ListChooser'].applyChanges=true;
this.b$['java.awt.Dialog'].setVisible$Z.apply(this.b$['java.awt.Dialog'], [false]);
});
})()
), Clazz.new_(P$.ListChooser$2.$init$,[this, null])));
selectAllButton.addActionListener$java_awt_event_ActionListener(((P$.ListChooser$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "ListChooser$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
for (var i=0; i < this.b$['org.opensourcephysics.controls.ListChooser'].checkBoxes.length; i++) {
this.b$['org.opensourcephysics.controls.ListChooser'].checkBoxes[i].setSelected$Z(true);
}
});
})()
), Clazz.new_(P$.ListChooser$3.$init$,[this, null])));
this.getRootPane$().setDefaultButton$javax_swing_JButton(okButton);
var headerPane=Clazz.new_($I$(1,1));
headerPane.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$java_awt_Container$I,[headerPane, 0]));
headerPane.add$java_awt_Component(this.instructions);
headerPane.add$java_awt_Component($I$(8).createHorizontalGlue$());
headerPane.add$java_awt_Component(selectAllButton);
headerPane.setBorder$javax_swing_border_Border($I$(4).createEmptyBorder$I$I$I$I(10, 10, 0, 10));
this.checkPane.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$java_awt_Container$I,[this.checkPane, 1]));
this.checkPane.setBackground$java_awt_Color($I$(9).white);
var scroller=Clazz.new_($I$(10,1).c$$java_awt_Component,[this.checkPane]);
scroller.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(11,1).c$$I$I,[250, 180]));
var scrollPane=Clazz.new_([Clazz.new_($I$(12,1))],$I$(1,1).c$$java_awt_LayoutManager);
scrollPane.add$java_awt_Component$O(scroller, "Center");
scrollPane.setBorder$javax_swing_border_Border($I$(4).createEmptyBorder$I$I$I$I(10, 10, 10, 10));
var buttonPane=Clazz.new_($I$(1,1));
buttonPane.setLayout$java_awt_LayoutManager(Clazz.new_($I$(7,1).c$$java_awt_Container$I,[buttonPane, 0]));
buttonPane.setBorder$javax_swing_border_Border($I$(4).createEmptyBorder$I$I$I$I(0, 10, 10, 10));
buttonPane.add$java_awt_Component($I$(8).createHorizontalGlue$());
buttonPane.add$java_awt_Component(okButton);
buttonPane.add$java_awt_Component($I$(8,"createRigidArea$java_awt_Dimension",[Clazz.new_($I$(11,1).c$$I$I,[10, 0])]));
buttonPane.add$java_awt_Component(cancelButton);
var contentPane=this.getContentPane$();
contentPane.add$java_awt_Component$O(headerPane, "North");
contentPane.add$java_awt_Component$O(scrollPane, "Center");
contentPane.add$java_awt_Component$O(buttonPane, "South");
this.pack$();
var dim=$I$(13).getDefaultToolkit$().getScreenSize$();
var rect=Clazz.new_($I$(14,1).c$$java_awt_Dimension,[dim]);
if (this.getOwner$() != null ) {
rect=this.getOwner$().getBounds$();
}var x=rect.x + ((rect.width - this.getBounds$().width)/2|0);
var y=rect.y + ((rect.height - this.getBounds$().height)/2|0);
this.setLocation$I$I(x, y);
}, p$1);

Clazz.newMeth(C$, 'setSeparator$S', function (separator) {
if (separator != null ) {
this.separator=separator;
}});

Clazz.newMeth(C$, 'choose$java_util_Collection$java_util_Collection', function (choices, names) {
return this.choose$java_util_Collection$java_util_Collection$java_util_Collection(choices, names, null);
});

Clazz.newMeth(C$, 'choose$java_util_Collection$java_util_Collection$java_util_Collection', function (choices, names, values) {
var selected=Clazz.array(Boolean.TYPE, [choices.size$()]);
return this.choose$java_util_Collection$java_util_Collection$java_util_Collection$ZA(choices, names, values, selected);
});

Clazz.newMeth(C$, 'choose$java_util_Collection$java_util_Collection$java_util_Collection$ZA', function (choices, names, values, selected) {
var disabled=Clazz.array(Boolean.TYPE, [choices.size$()]);
return this.choose$java_util_Collection$java_util_Collection$java_util_Collection$ZA$ZA(choices, names, values, selected, disabled);
});

Clazz.newMeth(C$, 'choose$java_util_Collection$java_util_Collection$java_util_Collection$ZA$ZA', function (choices, names, values, selected, disabled) {
return this.choose$java_util_Collection$java_util_Collection$java_util_Collection$java_util_Collection$ZA$ZA(choices, names, values, null, selected, disabled);
});

Clazz.newMeth(C$, 'choose$java_util_Collection$java_util_Collection$java_util_Collection$java_util_Collection$ZA', function (choices, names, values, descriptions, selected) {
var disabled=Clazz.array(Boolean.TYPE, [choices.size$()]);
return this.choose$java_util_Collection$java_util_Collection$java_util_Collection$java_util_Collection$ZA$ZA(choices, names, values, descriptions, selected, disabled);
});

Clazz.newMeth(C$, 'choose$java_util_Collection$java_util_Collection$java_util_Collection$java_util_Collection$ZA$ZA', function (choices, names, values, descriptions, selected, disabled) {
this.checkPane.removeAll$();
this.checkBoxes=Clazz.array($I$(15), [choices.size$()]);
this.selections=Clazz.array(Boolean.TYPE, [choices.size$()]);
this.objects=Clazz.array(java.lang.Object, [choices.size$()]);
var nameList=Clazz.new_($I$(16,1));
if (names != null ) {
nameList.addAll$java_util_Collection(names);
}var valueList=Clazz.new_($I$(16,1));
if (values != null ) {
valueList.addAll$java_util_Collection(values);
}var descriptionList=Clazz.new_($I$(16,1));
if (descriptions != null ) {
descriptionList.addAll$java_util_Collection(descriptions);
}var it=choices.iterator$();
var i=0;
while (it.hasNext$()){
this.objects[i]=it.next$();
this.selections[i]=false;
if ((nameList.size$() <= i) || (nameList.get$I(i) == null ) ) {
this.checkBoxes[i]=Clazz.new_([this.objects[i].toString()],$I$(15,1).c$$S);
} else {
var text=nameList.get$I(i);
if (valueList.size$() > i && valueList.get$I(i) != null  ) {
text += this.separator + valueList.get$I(i);
}this.checkBoxes[i]=Clazz.new_($I$(15,1).c$$S,[text]);
}this.checkBoxes[i].setSelected$Z(selected[i]);
this.checkBoxes[i].setEnabled$Z(!disabled[i]);
this.checkBoxes[i].setBackground$java_awt_Color($I$(9).white);
this.checkBoxes[i].setFont$java_awt_Font(this.lightFont);
this.checkBoxes[i].setIconTextGap$I(10);
var box=$I$(8).createHorizontalBox$();
box.setBorder$javax_swing_border_Border($I$(4).createEmptyBorder$I$I$I$I(0, 4, 0, 8));
box.add$java_awt_Component(this.checkBoxes[i]);
box.add$java_awt_Component($I$(8).createHorizontalGlue$());
this.checkPane.add$java_awt_Component(box);
if (descriptionList.size$() > i && descriptionList.get$I(i) != null  ) {
var label=Clazz.new_([descriptionList.get$I(i)],$I$(3,1).c$$S);
label.setFont$java_awt_Font(this.lightFont);
box.add$java_awt_Component(label);
}i++;
}
$I$(17,"setFonts$O$I",[this, $I$(17).getLevel$()]);
this.pack$();
this.setVisible$Z(true);
if (!this.applyChanges) {
return false;
}for (i=0; i < this.objects.length; i++) {
if (!this.selections[i]) {
choices.remove$O(this.objects[i]);
}}
return true;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-01 19:14:11 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
