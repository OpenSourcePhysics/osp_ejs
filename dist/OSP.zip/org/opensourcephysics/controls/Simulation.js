(function(){var P$=Clazz.newPackage("org.opensourcephysics.controls"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Simulation", null, null, 'org.opensourcephysics.controls.Animation');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-01 19:14:11 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
