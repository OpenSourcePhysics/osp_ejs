(function(){var P$=Clazz.newPackage("org.opensourcephysics.display.axes"),I$=[[0,'java.awt.BorderLayout','java.awt.Color','javax.swing.AbstractAction','javax.swing.JCheckBox','javax.swing.BorderFactory','org.opensourcephysics.media.core.ScientificField','java.awt.event.FocusAdapter','java.awt.event.MouseAdapter','java.awt.event.ActionEvent','java.awt.Rectangle','java.awt.event.InputEvent','java.util.ArrayList',['org.opensourcephysics.display.axes.CartesianInteractive','.AxisMouseListener'],'java.awt.Cursor','java.awt.event.KeyAdapter',['org.opensourcephysics.display.axes.CartesianInteractive','.ScaleSetter'],'javax.swing.JPanel','org.opensourcephysics.tools.ResourceLoader','org.opensourcephysics.display.GUIUtils','java.awt.Point','org.opensourcephysics.tools.FontSizer','org.opensourcephysics.display.dialogs.DialogsRes']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CartesianInteractive", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.display.axes.CartesianType1', 'org.opensourcephysics.display.Selectable');
C$.$classes$=[['ScaleSetter',1],['AxisMouseListener',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.hitRect=Clazz.new_($I$(10,1));
this.enabled=true;
this.axisListeners=Clazz.new_($I$(12,1));
},1);

C$.$fields$=[['Z',['drawHitRect','enabled','altDown'],'D',['mouseX','mouseY'],'I',['mouseRegion'],'O',['hitRect','java.awt.Rectangle','scaleSetter','org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter','scaleSetterPanel','javax.swing.JPanel','axisListener','org.opensourcephysics.display.axes.CartesianInteractive.AxisMouseListener','mouseLoc','java.awt.Point','plot','org.opensourcephysics.display.PlottingPanel','horzCenter','java.awt.Cursor','+horzRight','+horzLeft','+vertCenter','+vertUp','+vertDown','+move','axisListeners','java.util.List']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_display_PlottingPanel', function (panel) {
;C$.superclazz.c$$org_opensourcephysics_display_PlottingPanel.apply(this,[panel]);C$.$init$.apply(this);
this.plot=panel;
this.axisListener=Clazz.new_($I$(13,1),[this, null]);
panel.addMouseListener$java_awt_event_MouseListener(this.axisListener);
panel.addMouseMotionListener$java_awt_event_MouseMotionListener(this.axisListener);
panel.addKeyListener$java_awt_event_KeyListener(((P$.CartesianInteractive$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "CartesianInteractive$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (!this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].enabled) return;
if ((this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].mouseRegion == 0) && !this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.isFixedScale$() && (e.getKeyCode$() == 18)  ) {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].altDown=true;
this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].plot.setMouseCursor$java_awt_Cursor(this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].getPreferredCursor$.apply(this.b$['org.opensourcephysics.display.axes.CartesianInteractive'], []));
}});

Clazz.newMeth(C$, 'keyReleased$java_awt_event_KeyEvent', function (e) {
if (!this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].enabled) return;
if (e.getKeyCode$() == 18) {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].altDown=false;
this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].plot.setMouseCursor$java_awt_Cursor($I$(14).getPredefinedCursor$I(1));
}});
})()
), Clazz.new_($I$(15,1),[this, null],P$.CartesianInteractive$1)));
this.scaleSetter=Clazz.new_($I$(16,1),[this, null]);
this.scaleSetterPanel=Clazz.new_($I$(17,1).c$$java_awt_LayoutManager,[null]);
this.scaleSetterPanel.setOpaque$Z(false);
this.scaleSetterPanel.add$java_awt_Component(this.scaleSetter);
this.plot.getGlassPanel$().add$java_awt_Component$O(this.scaleSetterPanel, "Center");
}, 1);

Clazz.newMeth(C$, 'getMouseRegion$', function () {
return this.mouseRegion;
});

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
C$.superclazz.prototype.draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics.apply(this, [panel, g]);
if (this.drawHitRect) {
g.drawRect$I$I$I$I(this.hitRect.x, this.hitRect.y, this.hitRect.width, this.hitRect.height);
}if (!panel.isFixedScale$() && this.scaleSetter.isVisible$() && (this.scaleSetter.scaleField.getBackground$() !== $I$(2).yellow )  ) {
switch (this.scaleSetter.region) {
case 1:
this.scaleSetter.scaleField.setValue$D(this.drawingPanel.getXMin$());
this.scaleSetter.autoscaleCheckbox.setSelected$Z(this.drawingPanel.isAutoscaleXMin$());
break;
case 2:
this.scaleSetter.scaleField.setValue$D(this.drawingPanel.getXMax$());
this.scaleSetter.autoscaleCheckbox.setSelected$Z(this.drawingPanel.isAutoscaleXMax$());
break;
case 3:
this.scaleSetter.scaleField.setValue$D(this.drawingPanel.getYMin$());
this.scaleSetter.autoscaleCheckbox.setSelected$Z(this.drawingPanel.isAutoscaleYMin$());
break;
case 4:
this.scaleSetter.scaleField.setValue$D(this.drawingPanel.getYMax$());
this.scaleSetter.autoscaleCheckbox.setSelected$Z(this.drawingPanel.isAutoscaleYMax$());
}
}});

Clazz.newMeth(C$, 'getX$', function () {
return Double.isNaN$D(this.mouseX) ? this.plot.pixToX$I(this.plot.getMouseIntX$()) : this.mouseX;
});

Clazz.newMeth(C$, 'getY$', function () {
return Double.isNaN$D(this.mouseY) ? this.plot.pixToY$I(this.plot.getMouseIntY$()) : this.mouseY;
});

Clazz.newMeth(C$, 'setSelected$Z', function (selectable) {
});

Clazz.newMeth(C$, 'isSelected$', function () {
return false;
});

Clazz.newMeth(C$, 'toggleSelected$', function () {
});

Clazz.newMeth(C$, 'getPreferredCursor$', function () {
switch (this.mouseRegion) {
case 6:
if (this.horzLeft == null ) {
var imageFile="/org/opensourcephysics/resources/tools/images/horzleft.gif";
var im=$I$(18).getImage$S(imageFile);
this.horzLeft=$I$(19,"createCustomCursor$java_awt_Image$java_awt_Point$S$I",[im, Clazz.new_($I$(20,1).c$$I$I,[16, 16]), "Horizontal Left", 10]);
}return this.horzLeft;
case 7:
if (this.horzRight == null ) {
var imageFile="/org/opensourcephysics/resources/tools/images/horzright.gif";
var im=$I$(18).getImage$S(imageFile);
this.horzRight=$I$(19,"createCustomCursor$java_awt_Image$java_awt_Point$S$I",[im, Clazz.new_($I$(20,1).c$$I$I,[16, 16]), "Horizontal Right", 11]);
}return this.horzRight;
case 5:
if (this.horzCenter == null ) {
var imageFile="/org/opensourcephysics/resources/tools/images/horzcenter.gif";
var im=$I$(18).getImage$S(imageFile);
this.horzCenter=$I$(19,"createCustomCursor$java_awt_Image$java_awt_Point$S$I",[im, Clazz.new_($I$(20,1).c$$I$I,[16, 16]), "Horizontal Center", 13]);
}return this.horzCenter;
case 9:
if (this.vertDown == null ) {
var imageFile="/org/opensourcephysics/resources/tools/images/vertdown.gif";
var im=$I$(18).getImage$S(imageFile);
this.vertDown=$I$(19,"createCustomCursor$java_awt_Image$java_awt_Point$S$I",[im, Clazz.new_($I$(20,1).c$$I$I,[16, 16]), "Vertical Down", 9]);
}return this.vertDown;
case 10:
if (this.vertUp == null ) {
var imageFile="/org/opensourcephysics/resources/tools/images/vertup.gif";
var im=$I$(18).getImage$S(imageFile);
this.vertUp=$I$(19,"createCustomCursor$java_awt_Image$java_awt_Point$S$I",[im, Clazz.new_($I$(20,1).c$$I$I,[16, 16]), "Vertical Up", 8]);
}return this.vertUp;
case 8:
if (this.vertCenter == null ) {
var imageFile="/org/opensourcephysics/resources/tools/images/vertcenter.gif";
var im=$I$(18).getImage$S(imageFile);
this.vertCenter=$I$(19,"createCustomCursor$java_awt_Image$java_awt_Point$S$I",[im, Clazz.new_($I$(20,1).c$$I$I,[16, 16]), "Vertical Center", 13]);
}return this.vertCenter;
case 0:
if (this.move == null ) {
var imageFile="/org/opensourcephysics/resources/tools/images/movecursor.gif";
var im=$I$(18).getImage$S(imageFile);
this.move=$I$(19,"createCustomCursor$java_awt_Image$java_awt_Point$S$I",[im, Clazz.new_($I$(20,1).c$$I$I,[16, 16]), "Move All Ways", 13]);
}return this.move;
case 11:
case 12:
return $I$(14).getPredefinedCursor$I(12);
}
return $I$(14).getDefaultCursor$();
});

Clazz.newMeth(C$, 'isEnabled$', function () {
return this.enabled;
});

Clazz.newMeth(C$, 'setEnabled$Z', function (enable) {
this.enabled=enable;
});

Clazz.newMeth(C$, 'addAxisListener$java_awt_event_ActionListener', function (listener) {
this.axisListeners.add$O(listener);
});

Clazz.newMeth(C$, 'findInteractive$org_opensourcephysics_display_DrawingPanel$I$I', function (panel, xpix, ypix) {
if (this.drawingPanel.isFixedScale$()) {
return null;
}if (this.mouseRegion >= 1) {
return this;
}if (this.mouseRegion == -1) {
return this;
}if ((this.mouseRegion == 0) && this.altDown ) {
return this;
}return null;
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
});

Clazz.newMeth(C$, 'isMeasured$', function () {
return true;
});

Clazz.newMeth(C$, 'getXMin$', function () {
return this.drawingPanel.getXMin$();
});

Clazz.newMeth(C$, 'getXMax$', function () {
return this.drawingPanel.getXMax$();
});

Clazz.newMeth(C$, 'getYMin$', function () {
return this.drawingPanel.getYMin$();
});

Clazz.newMeth(C$, 'getYMax$', function () {
return this.drawingPanel.getYMax$();
});

Clazz.newMeth(C$, 'hideScaleSetter$', function () {
if (this.scaleSetter != null ) {
this.scaleSetter.autoscaleCheckbox.requestFocusInWindow$();
this.scaleSetter.setVisible$Z(false);
}});

Clazz.newMeth(C$, 'resizeFonts$D$org_opensourcephysics_display_DrawingPanel', function (factor, panel) {
C$.superclazz.prototype.resizeFonts$D$org_opensourcephysics_display_DrawingPanel.apply(this, [factor, panel]);
if (this.scaleSetter != null ) {
this.scaleSetter.scaleField.setFont$java_awt_Font($I$(21,"getResizedFont$java_awt_Font$D",[this.scaleSetter.scaleField.getFont$(), factor]));
this.scaleSetter.autoscaleCheckbox.setFont$java_awt_Font($I$(21,"getResizedFont$java_awt_Font$D",[this.scaleSetter.autoscaleCheckbox.getFont$(), factor]));
}});

Clazz.newMeth(C$, 'hasHorzVariablesPopup$', function () {
return false;
});

Clazz.newMeth(C$, 'getHorzVariablesPopup$', function () {
return null;
});

Clazz.newMeth(C$, 'hasVertVariablesPopup$', function () {
return false;
});

Clazz.newMeth(C$, 'getVertVariablesPopup$', function () {
return null;
});

Clazz.newMeth(C$, 'findRegion$java_awt_Point', function (p) {
var l=this.drawingPanel.getLeftGutter$();
var r=this.drawingPanel.getRightGutter$();
var t=this.drawingPanel.getTopGutter$();
var b=this.drawingPanel.getBottomGutter$();
var plotDim=this.drawingPanel.getSize$();
var axisLen=plotDim.width - r - l ;
this.hitRect.setSize$I$I((axisLen/4|0), 12);
this.hitRect.setLocation$I$I(l + (axisLen/2|0) - (this.hitRect.width/2|0), plotDim.height - b - (this.hitRect.height/2|0) );
if (this.hitRect.contains$java_awt_Point(p)) {
return 5;
}this.hitRect.setLocation$I$I(l + 4, plotDim.height - b - (this.hitRect.height/2|0) );
if (this.hitRect.contains$java_awt_Point(p)) {
return 6;
}this.hitRect.setLocation$I$I(l + axisLen - this.hitRect.width - 4, plotDim.height - b - (this.hitRect.height/2|0) );
if (this.hitRect.contains$java_awt_Point(p)) {
return 7;
}axisLen=plotDim.height - t - b ;
this.hitRect.setSize$I$I(12, (axisLen/4|0));
this.hitRect.setLocation$I$I(l - (this.hitRect.width/2|0), t + (axisLen/2|0) - (this.hitRect.height/2|0));
if (this.hitRect.contains$java_awt_Point(p)) {
return 8;
}this.hitRect.setLocation$I$I(l - (this.hitRect.width/2|0), t + 4);
if (this.hitRect.contains$java_awt_Point(p)) {
return 10;
}this.hitRect.setLocation$I$I(l - (this.hitRect.width/2|0), t + axisLen - this.hitRect.height - 4);
if (this.hitRect.contains$java_awt_Point(p)) {
return 9;
}var g=this.drawingPanel.getGraphics$();
try {
var w=this.xLine.getWidth$java_awt_Graphics(g) + 8;
var h=this.xLine.getHeight$java_awt_Graphics(g);
this.hitRect.setSize$I$I(w, h);
var x=((this.xLine.getX$() - (w/2|0))|0);
var y=((this.xLine.getY$() - (h/2|0) - (this.xLine.getFontSize$()/3|0))|0);
this.hitRect.setLocation$I$I(x, y);
if (this.hitRect.contains$java_awt_Point(p) && this.hasHorzVariablesPopup$() ) {
return 11;
}w=this.yLine.getHeight$java_awt_Graphics(g);
h=this.yLine.getWidth$java_awt_Graphics(g) + 8;
this.hitRect.setSize$I$I(w, h);
x=((this.yLine.getX$() - (w/2|0) - (this.yLine.getFontSize$()/3|0))|0);
y=((this.yLine.getY$() - (h/2|0) - 1)|0);
this.hitRect.setLocation$I$I(x, y);
if (this.hitRect.contains$java_awt_Point(p) && this.hasVertVariablesPopup$() ) {
return 12;
}if (!((p.x < l) || (p.y < t) || (p.x > plotDim.width - r) || (p.y > plotDim.height - b)  )) {
return 0;
}var field=this.scaleSetter.scaleField;
var fieldDim=field.getPreferredSize$();
this.hitRect.setSize$java_awt_Dimension(fieldDim);
var xmin=this.drawingPanel.getXMin$();
var xmax=this.drawingPanel.getXMax$();
var ymin=this.drawingPanel.getYMin$();
var ymax=this.drawingPanel.getYMax$();
var offset=8;
this.hitRect.setLocation$I$I(l - 12, plotDim.height - b + 6 + offset);
if (this.hitRect.contains$java_awt_Point(p)) {
var hitLoc=this.hitRect.getLocation$();
this.scaleSetter.add$java_awt_Component$O(this.scaleSetter.autoscaleCheckbox, "North");
this.scaleSetter.validate$();
var fieldLoc=field.getLocation$();
var size=this.scaleSetter.getPreferredSize$();
this.scaleSetter.setBounds$I$I$I$I(hitLoc.x - fieldLoc.x, hitLoc.y - fieldLoc.y - offset , size.width, size.height);
return 1;
}this.hitRect.setLocation$I$I(plotDim.width - r - fieldDim.width  + 12, plotDim.height - b + 6 + offset);
if (this.hitRect.contains$java_awt_Point(p)) {
field.setExpectedRange$D$D(xmin, xmax);
var hitLoc=this.hitRect.getLocation$();
this.scaleSetter.add$java_awt_Component$O(this.scaleSetter.autoscaleCheckbox, "North");
this.scaleSetter.validate$();
var fieldLoc=field.getLocation$();
var size=this.scaleSetter.getPreferredSize$();
this.scaleSetter.setBounds$I$I$I$I(hitLoc.x - fieldLoc.x, hitLoc.y - fieldLoc.y - offset , size.width, size.height);
return 2;
}this.hitRect.setLocation$I$I(l - fieldDim.width - 1 - offset , plotDim.height - b - fieldDim.height  + 8);
if (this.hitRect.contains$java_awt_Point(p)) {
field.setExpectedRange$D$D(ymin, ymax);
var hitLoc=this.hitRect.getLocation$();
this.scaleSetter.add$java_awt_Component$O(this.scaleSetter.autoscaleCheckbox, "East");
this.scaleSetter.validate$();
var fieldLoc=field.getLocation$();
var minLoc=hitLoc.x - fieldLoc.x;
var size=this.scaleSetter.getPreferredSize$();
this.scaleSetter.setBounds$I$I$I$I(Math.max(minLoc, 1 - fieldLoc.x), hitLoc.y - fieldLoc.y, size.width, size.height);
return 3;
}this.hitRect.setLocation$I$I(l - fieldDim.width - 1 - offset , t - 8);
if (this.hitRect.contains$java_awt_Point(p)) {
field.setExpectedRange$D$D(ymin, ymax);
var hitLoc=this.hitRect.getLocation$();
this.scaleSetter.add$java_awt_Component$O(this.scaleSetter.autoscaleCheckbox, "East");
this.scaleSetter.validate$();
var fieldLoc=field.getLocation$();
var minLoc=hitLoc.x - fieldLoc.x;
var size=this.scaleSetter.getPreferredSize$();
this.scaleSetter.setBounds$I$I$I$I(Math.max(minLoc, 1 - fieldLoc.x), hitLoc.y - fieldLoc.y, size.width, size.height);
return 4;
}} finally {
g.dispose$();
}
return -1;
});

Clazz.newMeth(C$, 'getScaleSetter$', function () {
var s=$I$(22).SCALE_AUTO;
if (!s.equals$O(this.scaleSetter.autoscaleCheckbox.getText$())) {
this.scaleSetter.autoscaleCheckbox.setText$S(s);
}return this.scaleSetter;
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.CartesianInteractive, "ScaleSetter", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JPanel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.pinned=false;
},1);

C$.$fields$=[['Z',['pinned'],'I',['region'],'O',['scaleAction','javax.swing.Action','autoscaleCheckbox','javax.swing.JCheckBox','scaleField','org.opensourcephysics.media.core.ScientificField']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_LayoutManager.apply(this,[Clazz.new_($I$(1,1))]);C$.$init$.apply(this);
this.scaleAction=((P$.CartesianInteractive$ScaleSetter$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "CartesianInteractive$ScaleSetter$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].scaleField.setBackground$java_awt_Color($I$(2).white);
this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].pinned=false;
var auto=this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].autoscaleCheckbox.isSelected$();
var horzAxis=true;
var min=auto ? NaN : this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].scaleField.getValue$();
var max=min;
switch (this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].region) {
default:
return;
case 1:
max=this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.isAutoscaleXMax$() ? NaN : this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.getXMax$();
break;
case 2:
min=this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.isAutoscaleXMin$() ? NaN : this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.getXMin$();
break;
case 3:
horzAxis=false;
max=this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.isAutoscaleYMax$() ? NaN : this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.getYMax$();
break;
case 4:
horzAxis=false;
min=this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.isAutoscaleYMin$() ? NaN : this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.getYMin$();
}
if (horzAxis) {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.setPreferredMinMaxX$D$D(min, max);
} else {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.setPreferredMinMaxY$D$D(min, max);
}var bounds=this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.getBounds$();
bounds.setLocation$I$I(0, 0);
this.b$['org.opensourcephysics.display.axes.CartesianInteractive'].drawingPanel.paintImmediately$java_awt_Rectangle(bounds);
});
})()
), Clazz.new_($I$(3,1),[this, null],P$.CartesianInteractive$ScaleSetter$1));
this.autoscaleCheckbox=Clazz.new_($I$(4,1));
this.autoscaleCheckbox.setBorder$javax_swing_border_Border($I$(5).createEmptyBorder$I$I$I$I(1, 2, 2, 1));
this.autoscaleCheckbox.setBackground$java_awt_Color(this.this$0.drawingPanel.getBackground$());
this.autoscaleCheckbox.setHorizontalTextPosition$I(4);
this.autoscaleCheckbox.addActionListener$java_awt_event_ActionListener(this.scaleAction);
this.scaleField=((P$.CartesianInteractive$ScaleSetter$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "CartesianInteractive$ScaleSetter$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('org.opensourcephysics.media.core.ScientificField'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
var dim=C$.superclazz.prototype.getPreferredSize$.apply(this, []);
dim.width-=4;
return dim;
});
})()
), Clazz.new_($I$(6,1).c$$I$I,[this, null, 6, 3],P$.CartesianInteractive$ScaleSetter$2));
this.scaleField.addActionListener$java_awt_event_ActionListener(((P$.CartesianInteractive$ScaleSetter$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "CartesianInteractive$ScaleSetter$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.AbstractAction'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].autoscaleCheckbox.setSelected$Z(false);
this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].scaleAction.actionPerformed$java_awt_event_ActionEvent(null);
});
})()
), Clazz.new_($I$(3,1),[this, null],P$.CartesianInteractive$ScaleSetter$3)));
this.scaleField.addFocusListener$java_awt_event_FocusListener(((P$.CartesianInteractive$ScaleSetter$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "CartesianInteractive$ScaleSetter$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.FocusAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
if (this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].scaleField.getBackground$() === $I$(2).yellow ) {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].autoscaleCheckbox.setSelected$Z(false);
this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].scaleAction.actionPerformed$java_awt_event_ActionEvent(null);
}});
})()
), Clazz.new_($I$(7,1),[this, null],P$.CartesianInteractive$ScaleSetter$4)));
this.scaleField.addMouseListener$java_awt_event_MouseListener(((P$.CartesianInteractive$ScaleSetter$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "CartesianInteractive$ScaleSetter$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].pinned=true;
if (e.getClickCount$() == 2) {
this.b$['org.opensourcephysics.display.axes.CartesianInteractive.ScaleSetter'].scaleField.selectAll$();
}});
})()
), Clazz.new_($I$(8,1),[this, null],P$.CartesianInteractive$ScaleSetter$5)));
this.add$java_awt_Component$O(this.scaleField, "Center");
}, 1);

Clazz.newMeth(C$, 'hideIfInactive$', function () {
if ((this.scaleField.getBackground$() !== $I$(2).yellow ) && (this.scaleField.getSelectedText$() == null ) && !this.pinned  ) {
this.this$0.hideScaleSetter$.apply(this.this$0, []);
}});

Clazz.newMeth(C$, 'setRegion$I', function (mouseRegion) {
if (this.region != mouseRegion) {
this.autoscaleCheckbox.requestFocusInWindow$();
if (this.scaleField.getBackground$() === $I$(2).yellow ) {
this.autoscaleCheckbox.setSelected$Z(false);
this.scaleAction.actionPerformed$java_awt_event_ActionEvent(null);
}this.region=mouseRegion;
this.pinned=false;
this.scaleField.select$I$I(20, 20);
this.scaleField.requestFocusInWindow$();
}});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CartesianInteractive, "AxisMouseListener", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.event.MouseInputAdapter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
if (!this.this$0.enabled) return;
this.this$0.altDown=e.isAltDown$();
var p=e.getPoint$();
this.this$0.mouseRegion=this.this$0.findRegion$java_awt_Point.apply(this.this$0, [p]);
if ((this.this$0.mouseRegion > 0) && (this.this$0.mouseRegion < 5) && !this.this$0.drawingPanel.isFixedScale$()  ) {
this.this$0.getScaleSetter$.apply(this.this$0, []).setRegion$I(this.this$0.mouseRegion);
this.this$0.scaleSetter.validate$();
this.this$0.scaleSetter.setVisible$Z(true);
} else {
this.this$0.scaleSetter.hideIfInactive$();
}this.this$0.drawHitRect=((this.this$0.mouseRegion == 11) || (this.this$0.mouseRegion == 12) );
});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
if (!this.this$0.enabled) return;
var dx=0;
var dy=0;
var min=0;
var max=0;
switch (this.this$0.mouseRegion) {
case 0:
if (!this.this$0.altDown || this.this$0.drawingPanel.isFixedScale$() ) {
return;
}dx=(this.this$0.mouseLoc.x - e.getX$()) / this.this$0.plot.getXPixPerUnit$();
min=this.this$0.plot.getXMin$() + dx;
max=this.this$0.plot.getXMax$() + dx;
dx=0;
this.this$0.plot.setPreferredMinMaxX$D$D(min, max);
dy=(e.getY$() - this.this$0.mouseLoc.y) / this.this$0.plot.getYPixPerUnit$();
min=this.this$0.plot.getYMin$() + dy;
max=this.this$0.plot.getYMax$() + dy;
break;
case 5:
dx=(this.this$0.mouseLoc.x - e.getX$()) / this.this$0.plot.getXPixPerUnit$();
min=this.this$0.plot.getXMin$() + dx;
max=this.this$0.plot.getXMax$() + dx;
break;
case 6:
dx=2 * (this.this$0.mouseLoc.x - e.getX$()) / this.this$0.plot.getXPixPerUnit$();
min=this.this$0.plot.getXMin$() + dx;
max=this.this$0.plot.isAutoscaleXMax$() ? NaN : this.this$0.plot.getXMax$();
break;
case 7:
dx=2 * (this.this$0.mouseLoc.x - e.getX$()) / this.this$0.plot.getXPixPerUnit$();
min=this.this$0.plot.isAutoscaleXMin$() ? NaN : this.this$0.plot.getXMin$();
max=this.this$0.plot.getXMax$() + dx;
break;
case 8:
dy=(e.getY$() - this.this$0.mouseLoc.y) / this.this$0.plot.getYPixPerUnit$();
min=this.this$0.plot.getYMin$() + dy;
max=this.this$0.plot.getYMax$() + dy;
break;
case 9:
dy=2 * (e.getY$() - this.this$0.mouseLoc.y) / this.this$0.plot.getYPixPerUnit$();
min=this.this$0.plot.getYMin$() + dy;
max=this.this$0.plot.isAutoscaleYMax$() ? NaN : this.this$0.plot.getYMax$();
break;
case 10:
dy=2 * (e.getY$() - this.this$0.mouseLoc.y) / this.this$0.plot.getYPixPerUnit$();
min=this.this$0.plot.isAutoscaleYMin$() ? NaN : this.this$0.plot.getYMin$();
max=this.this$0.plot.getYMax$() + dy;
break;
}
if (dx != 0 ) {
this.this$0.plot.setPreferredMinMaxX$D$D(min, max);
} else if (dy != 0 ) {
this.this$0.plot.setPreferredMinMaxY$D$D(min, max);
}for (var listener, $listener = this.this$0.axisListeners.iterator$(); $listener.hasNext$()&&((listener=($listener.next$())),1);) listener.actionPerformed$java_awt_event_ActionEvent(Clazz.new_([this.this$0, e.getID$(), "axis dragged"],$I$(9,1).c$$O$I$S));

this.this$0.plot.invalidateImage$();
this.this$0.plot.repaint$();
this.this$0.mouseLoc=e.getPoint$();
});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
if (!this.this$0.enabled) return;
this.this$0.plot.requestFocusInWindow$();
this.this$0.altDown=e.isAltDown$();
this.this$0.mouseLoc=e.getPoint$();
this.this$0.mouseX=this.this$0.plot.pixToX$I(this.this$0.plot.getMouseIntX$());
this.this$0.mouseY=this.this$0.plot.pixToY$I(this.this$0.plot.getMouseIntY$());
this.this$0.mouseRegion=this.this$0.findRegion$java_awt_Point.apply(this.this$0, [this.this$0.mouseLoc]);
if (this.this$0.scaleSetter == null ) {
return;
}if ((this.this$0.mouseRegion > 0) && (this.this$0.mouseRegion < 5) && !this.this$0.drawingPanel.isFixedScale$()  ) {
this.this$0.scaleSetter.setVisible$Z(true);
return;
}this.this$0.hideScaleSetter$.apply(this.this$0, []);
if (this.this$0.mouseRegion == 11) {
this.this$0.drawHitRect=false;
this.this$0.getHorzVariablesPopup$.apply(this.this$0, []).show$java_awt_Component$I$I(this.this$0.plot, this.this$0.mouseLoc.x - 20, this.this$0.mouseLoc.y - 12);
} else if (this.this$0.mouseRegion == 12) {
this.this$0.drawHitRect=false;
this.this$0.getVertVariablesPopup$.apply(this.this$0, []).show$java_awt_Component$I$I(this.this$0.plot, this.this$0.mouseLoc.x - 20, this.this$0.mouseLoc.y - 12);
}this.this$0.plot.repaint$();
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
if (!this.this$0.enabled) return;
this.this$0.mouseX=NaN;
this.this$0.mouseY=NaN;
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
if (!this.this$0.enabled) return;
var p=e.getPoint$();
if (!Clazz.new_([this.this$0.plot.getSize$()],$I$(10,1).c$$java_awt_Dimension).contains$java_awt_Point(p) && (this.this$0.scaleSetter != null ) && "".equals$O($I$(11,"getModifiersExText$I",[e.getModifiersEx$()]))  ) {
this.this$0.hideScaleSetter$.apply(this.this$0, []);
}});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-01 19:14:13 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
