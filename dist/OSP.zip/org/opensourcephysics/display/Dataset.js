(function(){var P$=Clazz.newPackage("org.opensourcephysics.display"),p$1={},I$=[[0,'org.opensourcephysics.display.Dataset','java.util.ArrayList',['java.awt.geom.Rectangle2D','.Double'],'java.awt.geom.AffineTransform','java.awt.Color','java.awt.geom.GeneralPath','java.util.Arrays','org.opensourcephysics.display.TeXParser',['org.opensourcephysics.display.Dataset','.ErrorBar'],'java.io.BufferedReader','java.io.FileReader','java.util.StringTokenizer','java.io.PrintWriter','java.io.BufferedWriter','java.io.FileWriter','StringBuffer',['java.awt.geom.Ellipse2D','.Double'],['org.opensourcephysics.display.Dataset','.Loader']]],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Dataset", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.table.AbstractTableModel', ['org.opensourcephysics.display.Measurable', 'org.opensourcephysics.display.LogMeasurable', 'org.opensourcephysics.display.Data']);
C$.$classes$=[['ErrorBar',0],['Loader',12]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.datasetID=this.hashCode$();
this.columnID=0;
this.sorted=false;
this.markerSize=2;
this.markerShape=2;
this.name=null;
this.colVisible=Clazz.array(Boolean.TYPE, [2]);
this.visible=true;
this.stride=1;
this.maxPoints=C$.defaultMaxPoints;
this.errorBars=Clazz.new_($I$(2,1));
this.customMarker=Clazz.new_([(-this.markerSize/2|0), (-this.markerSize/2|0), this.markerSize, this.markerSize],$I$(3,1).c$$D$D$D$D);
this.trD=Clazz.new_($I$(4,1));
},1);

C$.$fields$=[['Z',['sorted','connected','visible'],'D',['xmax','ymax','xmin','ymin','xmaxLogscale','ymaxLogscale','xminLogscale','yminLogscale'],'I',['datasetID','columnID','index','initialSize','markerSize','markerShape','stride','maxPoints'],'S',['name','xColumnName','yColumnName','xColumnDescription','yColumnDescription'],'O',['xpoints','double[]','+ypoints','generalPath','java.awt.geom.GeneralPath','lineColor','java.awt.Color','+fillColor','+edgeColor','+errorBarColor','colVisible','boolean[]','errorBars','java.util.ArrayList','customMarker','java.awt.Shape','+myShape','trD','java.awt.geom.AffineTransform']]
,['D',['maxPointsMultiplier'],'I',['defaultMaxPoints']]]

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_awt_Color$java_awt_Color$Z.apply(this, [$I$(5).black, $I$(5).black, false]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Color', function (_markerColor) {
C$.c$$java_awt_Color$java_awt_Color$Z.apply(this, [_markerColor, $I$(5).black, false]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Color$java_awt_Color$Z', function (markerColor, _lineColor, _connected) {
Clazz.super_(C$, this);
this.fillColor=markerColor;
this.edgeColor=markerColor;
this.errorBarColor=markerColor;
this.lineColor=_lineColor;
this.connected=_connected;
this.markerSize=2;
this.initialSize=10;
this.xColumnName="x";
this.yColumnName="y";
this.generalPath=Clazz.new_($I$(6,1));
this.index=0;
$I$(7).fill$ZA$Z(this.colVisible, true);
this.clear$();
}, 1);

Clazz.newMeth(C$, 'setID$I', function (id) {
this.datasetID=id;
});

Clazz.newMeth(C$, 'getID$', function () {
return this.datasetID;
});

Clazz.newMeth(C$, 'setColumnID$I', function (id) {
this.columnID=id;
});

Clazz.newMeth(C$, 'getColumnID$', function () {
return this.columnID;
});

Clazz.newMeth(C$, 'setSorted$Z', function (_sorted) {
this.sorted=_sorted;
if (this.sorted) {
this.insertionSort$();
}});

Clazz.newMeth(C$, 'setConnected$Z', function (_connected) {
this.connected=_connected;
if (this.connected) {
this.recalculatePath$();
}});

Clazz.newMeth(C$, 'setMarkerColor$java_awt_Color', function (markerColor) {
this.fillColor=markerColor;
this.edgeColor=markerColor;
this.errorBarColor=markerColor;
});

Clazz.newMeth(C$, 'setMarkerColor$java_awt_Color$java_awt_Color', function (_fillColor, _edgeColor) {
this.fillColor=_fillColor;
this.edgeColor=_edgeColor;
this.errorBarColor=_edgeColor;
});

Clazz.newMeth(C$, 'setMarkerColor$java_awt_Color$java_awt_Color$java_awt_Color', function (_fillColor, _edgeColor, _errorBarColor) {
this.fillColor=_fillColor;
this.edgeColor=_edgeColor;
this.errorBarColor=_errorBarColor;
});

Clazz.newMeth(C$, 'getFillColor$', function () {
return this.fillColor;
});

Clazz.newMeth(C$, 'getFillColors$', function () {
return Clazz.array($I$(5), -1, [$I$(5).BLACK, this.fillColor]);
});

Clazz.newMeth(C$, 'getEdgeColor$', function () {
return this.edgeColor;
});

Clazz.newMeth(C$, 'getLineColor$', function () {
return this.lineColor;
});

Clazz.newMeth(C$, 'getLineColors$', function () {
return Clazz.array($I$(5), -1, [$I$(5).BLACK, this.lineColor]);
});

Clazz.newMeth(C$, 'setCustomMarker$java_awt_Shape', function (marker) {
this.customMarker=marker;
if (this.customMarker == null ) {
this.markerShape=2;
this.customMarker=Clazz.new_([(-this.markerSize/2|0), (-this.markerSize/2|0), this.markerSize, this.markerSize],$I$(3,1).c$$D$D$D$D);
} else {
this.markerShape=-1;
}});

Clazz.newMeth(C$, 'setMarkerShape$I', function (_markerShape) {
this.markerShape=_markerShape;
});

Clazz.newMeth(C$, 'getMarkerShape$', function () {
return this.markerShape;
});

Clazz.newMeth(C$, 'setMarkerSize$I', function (_markerSize) {
this.markerSize=_markerSize;
});

Clazz.newMeth(C$, 'setMaximumPoints$I', function (maxPoints) {
this.maxPoints=maxPoints;
});

Clazz.newMeth(C$, 'getMarkerSize$', function () {
return this.markerSize;
});

Clazz.newMeth(C$, 'setLineColor$java_awt_Color', function (_lineColor) {
this.lineColor=_lineColor;
});

Clazz.newMeth(C$, 'setXYColumnNames$S$S', function (_xColumnName, _yColumnName) {
this.xColumnName=$I$(8).parseTeX$S(_xColumnName);
this.yColumnName=$I$(8).parseTeX$S(_yColumnName);
});

Clazz.newMeth(C$, 'setXYColumnNames$S$S$S', function (xColumnName, yColumnName, name) {
this.setXYColumnNames$S$S(xColumnName, yColumnName);
this.name=$I$(8).parseTeX$S(name);
});

Clazz.newMeth(C$, 'getXColumnName$', function () {
return this.xColumnName;
});

Clazz.newMeth(C$, 'getYColumnName$', function () {
return this.yColumnName;
});

Clazz.newMeth(C$, 'getXColumnDescription$', function () {
return this.xColumnDescription;
});

Clazz.newMeth(C$, 'setXColumnDescription$S', function (desc) {
this.xColumnDescription=desc;
});

Clazz.newMeth(C$, 'getYColumnDescription$', function () {
return this.yColumnDescription;
});

Clazz.newMeth(C$, 'setYColumnDescription$S', function (desc) {
this.yColumnDescription=desc;
});

Clazz.newMeth(C$, 'setName$S', function (name) {
this.name=name;
});

Clazz.newMeth(C$, 'getName$', function () {
return this.name;
});

Clazz.newMeth(C$, 'getDataList$', function () {
return null;
});

Clazz.newMeth(C$, 'getColumnNames$', function () {
return Clazz.array(String, -1, [this.xColumnName, this.yColumnName]);
});

Clazz.newMeth(C$, 'isMeasured$', function () {
if (this.visible) {
return this.ymin < 1.7976931348623157E308 ;
}return false;
});

Clazz.newMeth(C$, 'getXMin$', function () {
return this.xmin;
});

Clazz.newMeth(C$, 'getXMax$', function () {
return this.xmax;
});

Clazz.newMeth(C$, 'getYMin$', function () {
return this.ymin;
});

Clazz.newMeth(C$, 'getYMax$', function () {
return this.ymax;
});

Clazz.newMeth(C$, 'getXMinLogscale$', function () {
return this.xminLogscale;
});

Clazz.newMeth(C$, 'getXMaxLogscale$', function () {
return this.xmaxLogscale;
});

Clazz.newMeth(C$, 'getYMinLogscale$', function () {
return this.yminLogscale;
});

Clazz.newMeth(C$, 'getYMaxLogscale$', function () {
return this.ymaxLogscale;
});

Clazz.newMeth(C$, 'getPoints$', function () {
var temp=Clazz.array(Double.TYPE, [this.index, 2]);
var xValues=this.getXPoints$();
var yValues=this.getYPoints$();
for (var i=0; i < this.index; i++) {
temp[i]=Clazz.array(Double.TYPE, -1, [xValues[i], yValues[i]]);
}
return temp;
});

Clazz.newMeth(C$, 'getData2D$', function () {
var data=Clazz.array(Double.TYPE, [2, this.index]);
data[0]=this.getXPoints$();
data[1]=this.getYPoints$();
return data;
});

Clazz.newMeth(C$, 'getData3D$', function () {
return null;
});

Clazz.newMeth(C$, 'getDatasets$', function () {
var list=Clazz.new_($I$(2,1));
list.add$O(this);
return list;
});

Clazz.newMeth(C$, 'getXPoints$', function () {
var temp=Clazz.array(Double.TYPE, [this.index]);
System.arraycopy$O$I$O$I$I(this.xpoints, 0, temp, 0, this.index);
return temp;
});

Clazz.newMeth(C$, 'getYPoints$', function () {
var temp=Clazz.array(Double.TYPE, [this.index]);
System.arraycopy$O$I$O$I$I(this.ypoints, 0, temp, 0, this.index);
return temp;
});

Clazz.newMeth(C$, 'getValidXPoints$', function () {
return p$1.getValidPoints$DA.apply(this, [this.getXPoints$()]);
});

Clazz.newMeth(C$, 'getValidYPoints$', function () {
return p$1.getValidPoints$DA.apply(this, [this.getYPoints$()]);
});

Clazz.newMeth(C$, 'isSorted$', function () {
return this.sorted;
});

Clazz.newMeth(C$, 'isConnected$', function () {
return this.connected;
});

Clazz.newMeth(C$, 'getColumnCount$', function () {
return C$.countColumnsVisible$ZA(this.colVisible);
});

Clazz.newMeth(C$, 'getIndex$', function () {
return this.index;
});

Clazz.newMeth(C$, 'getRowCount$', function () {
return ((this.index + this.stride - 1)/this.stride|0);
});

Clazz.newMeth(C$, 'getColumnName$I', function (columnIndex) {
columnIndex=C$.convertTableColumnIndex$ZA$I(this.colVisible, columnIndex);
if (columnIndex == 0) {
return this.xColumnName;
}return this.yColumnName;
});

Clazz.newMeth(C$, 'getValueAt$I$I', function (rowIndex, columnIndex) {
columnIndex=C$.convertTableColumnIndex$ZA$I(this.colVisible, columnIndex);
rowIndex=rowIndex * this.stride;
var xValues=this.getXPoints$();
var yValues=this.getYPoints$();
if (columnIndex == 0) {
return  new Double(xValues[rowIndex]);
}if (Double.isNaN$D(yValues[rowIndex])) {
return null;
}return  new Double(yValues[rowIndex]);
});

Clazz.newMeth(C$, 'getColumnClass$I', function (columnIndex) {
return Clazz.getClass(Double);
});

Clazz.newMeth(C$, 'append$D$D$D$D', function (x, y, delx, dely) {
this.errorBars.add$O(Clazz.new_($I$(9,1).c$$D$D$D$D,[this, null, x, y, delx, dely]));
this.append$D$D(x, y);
});

Clazz.newMeth(C$, 'append$D$D', function (x, y) {
if (Double.isNaN$D(x) || Double.isInfinite$D(x) || Double.isInfinite$D(y)  ) {
return;
}this.myShape=null;
if (this.index >= this.xpoints.length) {
p$1.increaseCapacity$I.apply(this, [this.xpoints.length * 2]);
}this.xpoints[this.index]=x;
this.ypoints[this.index]=y;
if (!Double.isNaN$D(y)) {
var curPt=this.generalPath.getCurrentPoint$();
if (curPt == null ) {
this.generalPath.moveTo$F$F(x, y);
} else {
this.generalPath.lineTo$F$F(x, y);
}this.ymax=Math.max(y, this.ymax);
this.ymin=Math.min(y, this.ymin);
if (y > 0 ) {
this.ymaxLogscale=Math.max(y, this.ymaxLogscale);
this.yminLogscale=Math.min(y, this.yminLogscale);
}}this.xmax=Math.max(x, this.xmax);
this.xmin=Math.min(x, this.xmin);
if (x > 0 ) {
this.xmaxLogscale=Math.max(x, this.xmaxLogscale);
this.xminLogscale=Math.min(x, this.xminLogscale);
}this.index++;
if (this.sorted && (this.index > 1) && (x < this.xpoints[this.index - 2] )  ) {
this.moveDatum$I(this.index - 1);
this.recalculatePath$();
}});

Clazz.newMeth(C$, 'append$DA$DA$DA$DA', function (xpoints, ypoints, delx, dely) {
for (var i=0, n=xpoints.length; i < n; i++) {
this.errorBars.add$O(Clazz.new_($I$(9,1).c$$D$D$D$D,[this, null, xpoints[i], ypoints[i], delx[i], dely[i]]));
}
this.append$DA$DA(xpoints, ypoints);
});

Clazz.newMeth(C$, 'append$DA$DA', function (_xpoints, _ypoints) {
var badData=false;
this.myShape=null;
for (var i=0; i < _xpoints.length; i++) {
var xp=_xpoints[i];
var yp=_ypoints[i];
if (Double.isNaN$D(xp) || Double.isInfinite$D(xp) || Double.isInfinite$D(yp)  ) {
badData=true;
continue;
}this.xmax=Math.max(xp, this.xmax);
this.xmin=Math.min(xp, this.xmin);
if (xp > 0 ) {
this.xmaxLogscale=Math.max(xp, this.xmaxLogscale);
this.xminLogscale=Math.min(xp, this.xminLogscale);
}if (!Double.isNaN$D(yp)) {
this.ymax=Math.max(yp, this.ymax);
this.ymin=Math.min(yp, this.ymin);
if (yp > 0 ) {
this.ymaxLogscale=Math.max(yp, this.ymaxLogscale);
this.yminLogscale=Math.min(yp, this.yminLogscale);
}var curPt=this.generalPath.getCurrentPoint$();
if (curPt == null ) {
this.generalPath.moveTo$F$F(xp, yp);
} else {
this.generalPath.lineTo$F$F(xp, yp);
}}}
var pointsAdded=_xpoints.length;
var availableSpots=this.xpoints.length - this.index;
var increasedCapacity=false;
if (pointsAdded > availableSpots) {
p$1.increaseCapacity$I.apply(this, [this.xpoints.length + pointsAdded]);
increasedCapacity=true;
}var maxPts=this.maxPoints == C$.defaultMaxPoints ? ((this.maxPoints * C$.maxPointsMultiplier)|0) : this.maxPoints;
pointsAdded=Math.min(pointsAdded, maxPts);
System.arraycopy$O$I$O$I$I(_xpoints, Math.max(0, _xpoints.length - pointsAdded), this.xpoints, this.index, pointsAdded);
System.arraycopy$O$I$O$I$I(_ypoints, Math.max(0, _xpoints.length - pointsAdded), this.ypoints, this.index, pointsAdded);
this.index+=pointsAdded;
if (badData) {
p$1.removeBadData.apply(this, []);
}if (this.sorted) {
this.insertionSort$();
}if (increasedCapacity) {
p$1.resetXYMinMax.apply(this, []);
}});

Clazz.newMeth(C$, 'read$S', function (inputFile) {
try {
var reader=Clazz.new_([Clazz.new_($I$(11,1).c$$S,[inputFile])],$I$(10,1).c$$java_io_Reader);
var s;
while ((s=reader.readLine$()) != null ){
s=s.trim$();
if ((s.length$() == 0) || (s.charAt$I(0) == "#") ) {
continue;
}var st=Clazz.new_($I$(12,1).c$$S$S,[s, "\t"]);
switch (st.countTokens$()) {
case 0:
continue;
case 2:
this.append$D$D(Double.parseDouble$S(st.nextToken$()), Double.parseDouble$S(st.nextToken$()));
break;
default:
throw Clazz.new_(Clazz.load('java.io.IOException'));
}
}
reader.close$();
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.io.FileNotFoundException")){
var fnfe = e$$;
{
System.err.println$S("File " + inputFile + " not found." );
}
} else if (Clazz.exceptionOf(e$$,"java.io.IOException")){
var ioe = e$$;
{
System.err.println$S("Error reading file " + inputFile);
}
} else if (Clazz.exceptionOf(e$$,"NumberFormatException")){
var nfe = e$$;
{
System.err.println$S("Error reading file " + inputFile);
}
} else {
throw e$$;
}
}
});

Clazz.newMeth(C$, 'write$S', function (outputFile) {
try {
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(15,1).c$$S,[outputFile])],$I$(14,1).c$$java_io_Writer)],$I$(13,1).c$$java_io_Writer);
for (var i=0; i < this.index; i++) {
writer.println$S(new Double(this.xpoints[i]).toString() + "\t" + new Double(this.ypoints[i]).toString() );
}
writer.close$();
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.io.FileNotFoundException")){
var fnfe = e$$;
{
System.err.println$S("File " + outputFile + " not found." );
}
} else if (Clazz.exceptionOf(e$$,"java.io.IOException")){
var ioe = e$$;
{
System.err.println$S("Error writing file " + outputFile);
}
} else {
throw e$$;
}
}
});

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (drawingPanel, g) {
if (!this.visible) {
return;
}try {
var g2=g;
if (this.markerShape != 0) {
this.drawScatterPlot$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics2D(drawingPanel, g2);
}if (this.connected) {
this.drawLinePlot$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics2D(drawingPanel, g2);
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'clear$', function () {
this.index=0;
this.xpoints=Clazz.array(Double.TYPE, [this.initialSize]);
this.ypoints=Clazz.array(Double.TYPE, [this.initialSize]);
this.generalPath.reset$();
this.errorBars.clear$();
p$1.resetXYMinMax.apply(this, []);
this.myShape=null;
});

Clazz.newMeth(C$, 'toString', function () {
if (this.index == 0) {
return "No data in dataset.";
}var s=new Double(this.xpoints[0]).toString() + " " + new Double(this.ypoints[0]).toString() + "\n" ;
var b=Clazz.new_([this.index * s.length$()],$I$(16,1).c$$I);
for (var i=0; i < this.index; i++) {
b.append$D(this.xpoints[i]);
var eol="\n";
try {
eol=System.getProperty$S$S("line.separator", "\n");
} catch (ex) {
if (Clazz.exceptionOf(ex,"SecurityException")){
} else {
throw ex;
}
}
b.append$S(" ");
if (Double.isNaN$D(this.ypoints[i])) {
b.append$S("null");
} else {
b.append$D(this.ypoints[i]);
}b.append$S(eol);
}
return b.toString();
});

Clazz.newMeth(C$, 'countColumnsVisible$ZA', function (visible) {
var count=0;
for (var i=0; i < visible.length; i++) {
if (visible[i]) {
count++;
}}
return count;
}, 1);

Clazz.newMeth(C$, 'convertTableColumnIndex$ZA$I', function (visible, columnIndex) {
if ((columnIndex == 0) && !visible[0] ) {
columnIndex++;
} else if ((columnIndex == 1) && !visible[1] ) {
columnIndex--;
}return columnIndex;
}, 1);

Clazz.newMeth(C$, 'setXColumnVisible$Z', function (b) {
this.colVisible[0]=b;
});

Clazz.newMeth(C$, 'setYColumnVisible$Z', function (b) {
this.colVisible[1]=b;
});

Clazz.newMeth(C$, 'setVisible$Z', function (b) {
this.visible=b;
});

Clazz.newMeth(C$, 'getVisible$', function () {
return this.visible;
});

Clazz.newMeth(C$, 'setStride$I', function (_stride) {
this.stride=_stride;
});

Clazz.newMeth(C$, 'isXColumnVisible$', function () {
return this.colVisible[0];
});

Clazz.newMeth(C$, 'isYColumnVisible$', function () {
return this.colVisible[1];
});

Clazz.newMeth(C$, 'insertionSort$', function () {
var dataChanged=false;
if (this.index < 2) {
return;
}for (var i=1; i < this.index; i++) {
if (this.xpoints[i] < this.xpoints[i - 1] ) {
dataChanged=true;
this.moveDatum$I(i);
}}
if (dataChanged) {
this.recalculatePath$();
}});

Clazz.newMeth(C$, 'recalculatePath$', function () {
this.myShape=null;
this.generalPath.reset$();
if (this.index < 1) {
return;
}var i=0;
var xValues=this.getXPoints$();
var yValues=this.getYPoints$();
for (; i < this.index; i++) {
if (!Double.isNaN$D(yValues[i])) {
this.generalPath.moveTo$F$F(xValues[i], yValues[i]);
break;
}}
for (var j=i + 1; j < this.index; j++) {
if (!Double.isNaN$D(yValues[j])) {
this.generalPath.lineTo$F$F(xValues[j], yValues[j]);
}}
});

Clazz.newMeth(C$, 'moveDatum$I', function (loc) {
if (loc < 1) {
return;
}var x=this.xpoints[loc];
var y=this.ypoints[loc];
for (var i=0; i < this.index; i++) {
if (this.xpoints[i] > x ) {
System.arraycopy$O$I$O$I$I(this.xpoints, i, this.xpoints, i + 1, loc - i);
this.xpoints[i]=x;
System.arraycopy$O$I$O$I$I(this.ypoints, i, this.ypoints, i + 1, loc - i);
this.ypoints[i]=y;
return;
}}
});

Clazz.newMeth(C$, 'drawLinePlot$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics2D', function (drawingPanel, g2) {
var noNumbers=true;
for (var i=0; i < this.index; i++) {
noNumbers=Double.isNaN$D(this.ypoints[i]);
if (!noNumbers) {
break;
}}
if (noNumbers) {
return;
}g2.setColor$java_awt_Color(this.lineColor);
if (this.myShape == null ) this.myShape=drawingPanel.transformPath2$java_awt_geom_GeneralPath(this.generalPath);
g2.draw$java_awt_Shape(this.myShape);
});

Clazz.newMeth(C$, 'drawFilledPlot$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics2D', function (drawingPanel, g2) {
var noNumbers=true;
for (var i=0; i < this.index; i++) {
noNumbers=Double.isNaN$D(this.ypoints[i]);
if (!noNumbers) {
break;
}}
if (noNumbers) {
return;
}if (this.myShape == null ) this.myShape=drawingPanel.transformPath2$java_awt_geom_GeneralPath(this.generalPath);
g2.setColor$java_awt_Color(this.fillColor);
g2.fill$java_awt_Shape(this.myShape);
g2.setColor$java_awt_Color(this.edgeColor);
g2.draw$java_awt_Shape(this.myShape);
});

Clazz.newMeth(C$, 'drawScatterPlot$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics2D', function (drawingPanel, g2) {
if (this.markerShape == 5) {
this.drawFilledPlot$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics2D(drawingPanel, g2);
return;
}var xp=0;
var yp=0;
var shape=null;
var size=this.markerSize * 2 + 1;
g2=g2.create$();
g2.setClip$I$I$I$I(drawingPanel.leftGutter - this.markerSize - 1 , drawingPanel.topGutter - this.markerSize - 1 , drawingPanel.getWidth$() - drawingPanel.leftGutter - drawingPanel.rightGutter  + 2 + 2 * this.markerSize, drawingPanel.getHeight$() - drawingPanel.bottomGutter - drawingPanel.topGutter  + 2 + 2 * this.markerSize);
var viewRect=drawingPanel.getViewRect$();
if (viewRect != null ) {
g2.clipRect$I$I$I$I(viewRect.x, viewRect.y, viewRect.x + viewRect.width, viewRect.y + viewRect.height);
}var tempX=this.getXPoints$();
var tempY=this.getYPoints$();
for (var i=0; i < this.index; i++) {
if (Double.isNaN$D(tempY[i])) {
continue;
}if (drawingPanel.isLogScaleX$() && (tempX[i] <= 0 ) ) {
continue;
}if (drawingPanel.isLogScaleY$() && (tempY[i] <= 0 ) ) {
continue;
}xp=drawingPanel.xToPix$D(tempX[i]);
yp=drawingPanel.yToPix$D(tempY[i]);
switch (this.markerShape) {
case 7:
var bottom=Math.min(drawingPanel.yToPix$D(0), drawingPanel.yToPix$D(drawingPanel.getYMin$()));
var barHeight=bottom - yp;
if (barHeight > 0 ) {
shape=Clazz.new_($I$(3,1).c$$D$D$D$D,[xp - this.markerSize, yp, size, barHeight]);
} else {
shape=Clazz.new_($I$(3,1).c$$D$D$D$D,[xp - this.markerSize, bottom, size, -barHeight]);
}g2.setColor$java_awt_Color(this.fillColor);
g2.fill$java_awt_Shape(shape);
if (this.edgeColor !== this.fillColor ) {
g2.setColor$java_awt_Color(this.edgeColor);
g2.draw$java_awt_Shape(shape);
}break;
case 8:
bottom=Math.min(drawingPanel.yToPix$D(0), drawingPanel.yToPix$D(drawingPanel.getYMin$()));
shape=Clazz.new_($I$(3,1).c$$D$D$D$D,[xp - this.markerSize, yp - this.markerSize, size, size]);
g2.setColor$java_awt_Color(this.edgeColor);
g2.drawLine$I$I$I$I((xp|0), (yp|0), (xp|0), (bottom|0));
g2.setColor$java_awt_Color(this.fillColor);
g2.fill$java_awt_Shape(shape);
if (this.edgeColor !== this.fillColor ) {
g2.setColor$java_awt_Color(this.edgeColor);
g2.draw$java_awt_Shape(shape);
}break;
case 2:
shape=Clazz.new_($I$(3,1).c$$D$D$D$D,[xp - this.markerSize, yp - this.markerSize, size, size]);
g2.setColor$java_awt_Color(this.fillColor);
g2.fill$java_awt_Shape(shape);
if (this.edgeColor !== this.fillColor ) {
g2.setColor$java_awt_Color(this.edgeColor);
g2.draw$java_awt_Shape(shape);
}break;
case 1:
shape=Clazz.new_($I$(17,1).c$$D$D$D$D,[xp - this.markerSize, yp - this.markerSize, size, size]);
g2.setColor$java_awt_Color(this.fillColor);
g2.fill$java_awt_Shape(shape);
if (this.edgeColor !== this.fillColor ) {
g2.setColor$java_awt_Color(this.edgeColor);
g2.draw$java_awt_Shape(shape);
}break;
case 6:
shape=Clazz.new_($I$(3,1).c$$D$D$D$D,[xp, yp, 1, 1]);
g2.setColor$java_awt_Color(this.edgeColor);
g2.draw$java_awt_Shape(shape);
break;
case -1:
var temp=this.getTranslateInstance$D$D(xp, yp).createTransformedShape$java_awt_Shape(this.customMarker);
g2.setColor$java_awt_Color(this.fillColor);
g2.fill$java_awt_Shape(temp);
if (this.edgeColor !== this.fillColor ) {
g2.setColor$java_awt_Color(this.edgeColor);
g2.draw$java_awt_Shape(temp);
}break;
default:
shape=Clazz.new_($I$(3,1).c$$D$D$D$D,[xp - this.markerSize, yp - this.markerSize, size, size]);
g2.setColor$java_awt_Color(this.fillColor);
g2.fill$java_awt_Shape(shape);
if (this.edgeColor !== this.fillColor ) {
g2.setColor$java_awt_Color(this.edgeColor);
g2.draw$java_awt_Shape(shape);
}break;
}
}
var it=this.errorBars.iterator$();
while (it.hasNext$()){
(it.next$()).draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics(drawingPanel, g2);
}
g2.dispose$();
});

Clazz.newMeth(C$, 'getTranslateInstance$D$D', function (tx, ty) {
this.trD.setToTranslation$D$D(tx, ty);
return this.trD;
});

Clazz.newMeth(C$, 'removeBadData', function () {
for (var i=0; i < this.index; i++) {
if (Double.isNaN$D(this.xpoints[i]) || Double.isInfinite$D(this.xpoints[i]) || Double.isInfinite$D(this.ypoints[i])  ) {
if ((this.index == 1) || (i == this.index - 1) ) {
this.index--;
break;
}System.arraycopy$O$I$O$I$I(this.xpoints, i + 1, this.xpoints, i, this.index - i - 1 );
System.arraycopy$O$I$O$I$I(this.ypoints, i + 1, this.ypoints, i, this.index - i - 1 );
this.index--;
i--;
}}
}, p$1);

Clazz.newMeth(C$, 'increaseCapacity$I', function (newCapacity) {
var pointsAdded=newCapacity - this.xpoints.length;
var maxPts=this.maxPoints == C$.defaultMaxPoints ? ((this.maxPoints * C$.maxPointsMultiplier)|0) : this.maxPoints;
newCapacity=Math.min(newCapacity, maxPts);
var newIndex=Math.min(this.index, ((3 * newCapacity)/4|0));
newIndex=Math.min(newIndex, newCapacity - pointsAdded);
if (newIndex < 0) {
newIndex=0;
}var tempx=this.xpoints;
this.xpoints=Clazz.array(Double.TYPE, [newCapacity]);
System.arraycopy$O$I$O$I$I(tempx, this.index - newIndex, this.xpoints, 0, newIndex);
var tempy=this.ypoints;
this.ypoints=Clazz.array(Double.TYPE, [newCapacity]);
System.arraycopy$O$I$O$I$I(tempy, this.index - newIndex, this.ypoints, 0, newIndex);
if (this.index != newIndex) {
this.index=newIndex;
p$1.resetXYMinMax.apply(this, []);
this.recalculatePath$();
}this.index=newIndex;
}, p$1);

Clazz.newMeth(C$, 'resetXYMinMax', function () {
this.xmax=this.xmaxLogscale=-1.7976931348623157E308;
this.ymax=this.ymaxLogscale=-1.7976931348623157E308;
this.xmin=this.xminLogscale=1.7976931348623157E308;
this.ymin=this.yminLogscale=1.7976931348623157E308;
var xValues=this.getXPoints$();
var yValues=this.getYPoints$();
for (var i=0; i < this.index; i++) {
if (Double.isNaN$D(xValues[i]) || Double.isInfinite$D(xValues[i]) || Double.isInfinite$D(yValues[i])  ) {
continue;
}var xp=xValues[i];
this.xmax=Math.max(xp, this.xmax);
this.xmin=Math.min(xp, this.xmin);
if (xp > 0 ) {
this.xmaxLogscale=Math.max(xp, this.xmaxLogscale);
this.xminLogscale=Math.min(xp, this.xminLogscale);
}var yp=yValues[i];
if (!Double.isNaN$D(yp)) {
this.ymax=Math.max(yp, this.ymax);
this.ymin=Math.min(yp, this.ymin);
if (yp > 0 ) {
this.ymaxLogscale=Math.max(yp, this.ymaxLogscale);
this.yminLogscale=Math.min(yp, this.yminLogscale);
}}}
}, p$1);

Clazz.newMeth(C$, 'getValidPoints$DA', function (pts) {
var nans=0;
for (var i=0; i < pts.length; i++) {
if (nans > 0) {
pts[i - nans]=pts[i];
}if (Double.isNaN$D(this.ypoints[i])) {
nans++;
}}
if (nans == 0) {
return pts;
}var temp=Clazz.array(Double.TYPE, [this.index - nans]);
System.arraycopy$O$I$O$I$I(pts, 0, temp, 0, this.index - nans);
return temp;
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(18,1));
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.maxPointsMultiplier=1.0;
C$.defaultMaxPoints=16384;
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.Dataset, "ErrorBar", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'org.opensourcephysics.display.Drawable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.tick=3;
},1);

C$.$fields$=[['D',['x','y','delx','dely'],'I',['tick']]]

Clazz.newMeth(C$, 'c$$D$D$D$D', function (_x, _y, _delx, _dely) {
;C$.$init$.apply(this);
this.x=_x;
this.y=_y;
this.delx=_delx;
this.dely=_dely;
}, 1);

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
if (Double.isNaN$D(this.y)) {
return;
}var xpix=panel.xToPix$D(this.x);
var xpix1=panel.xToPix$D(this.x - this.delx);
var xpix2=panel.xToPix$D(this.x + this.delx);
var ypix=panel.yToPix$D(this.y);
var ypix1=panel.yToPix$D(this.y - this.dely);
var ypix2=panel.yToPix$D(this.y + this.dely);
g.setColor$java_awt_Color(this.this$0.errorBarColor);
g.drawLine$I$I$I$I(xpix1, ypix, xpix2, ypix);
g.drawLine$I$I$I$I(xpix, ypix1, xpix, ypix2);
g.drawLine$I$I$I$I(xpix1, ypix - this.tick, xpix1, ypix + this.tick);
g.drawLine$I$I$I$I(xpix2, ypix - this.tick, xpix2, ypix + this.tick);
g.drawLine$I$I$I$I(xpix - this.tick, ypix1, xpix + this.tick, ypix1);
g.drawLine$I$I$I$I(xpix - this.tick, ypix2, xpix + this.tick, ypix2);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.Dataset, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'org.opensourcephysics.controls.XMLLoader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var data=obj;
control.setValue$S$O("points", data.getPoints$());
control.setValue$S$I("index", data.index);
control.setValue$S$I("marker_shape", data.getMarkerShape$());
control.setValue$S$I("marker_size", data.getMarkerSize$());
control.setValue$S$Z("sorted", data.isSorted$());
control.setValue$S$Z("connected", data.isConnected$());
control.setValue$S$O("name", data.name);
control.setValue$S$O("x_name", data.xColumnName);
control.setValue$S$O("y_name", data.yColumnName);
control.setValue$S$O("x_description", data.xColumnDescription);
control.setValue$S$O("y_description", data.yColumnDescription);
control.setValue$S$O("line_color", data.lineColor);
control.setValue$S$O("fill_color", data.fillColor);
control.setValue$S$O("edge_color", data.edgeColor);
control.setValue$S$O("errorbar_color", data.errorBarColor);
control.setValue$S$I("datasetID", data.datasetID);
control.setValue$S$O("visible", data.colVisible);
});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
var type=control.getObjectClass$();
if (Clazz.getClass($I$(1)).isAssignableFrom$Class(type) && !Clazz.getClass($I$(1)).equals$O(type) ) {
try {
return type.newInstance$();
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"InstantiationException")){
var ex = e$$;
{
}
} else if (Clazz.exceptionOf(e$$,"IllegalAccessException")){
var ex = e$$;
{
}
} else {
throw e$$;
}
}
}return Clazz.new_($I$(1,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var data=obj;
var points=control.getObject$S("points");
if ((points != null ) && (points.length > 0) && (points[0] != null )  ) {
data.clear$();
for (var i=0; i < points.length; i++) {
data.append$D$D(points[i][0], points[i][1]);
}
}var xPoints=control.getObject$S("x_points");
var yPoints=control.getObject$S("y_points");
if ((xPoints != null ) && (yPoints != null ) ) {
data.clear$();
data.append$DA$DA(xPoints, yPoints);
}data.index=control.getInt$S("index");
if (control.getPropertyNames$().contains$O("marker_shape")) {
data.setMarkerShape$I(control.getInt$S("marker_shape"));
}if (control.getPropertyNames$().contains$O("marker_size")) {
data.setMarkerSize$I(control.getInt$S("marker_size"));
}data.setSorted$Z(control.getBoolean$S("sorted"));
data.setConnected$Z(control.getBoolean$S("connected"));
data.name=control.getString$S("name");
data.xColumnName=control.getString$S("x_name");
data.yColumnName=control.getString$S("y_name");
data.xColumnDescription=control.getString$S("x_description");
data.yColumnDescription=control.getString$S("y_description");
var color=control.getObject$S("line_color");
if (color != null ) {
data.lineColor=color;
}color=control.getObject$S("fill_color");
if (color != null ) {
data.fillColor=color;
}color=control.getObject$S("edge_color");
if (color != null ) {
data.edgeColor=color;
}color=control.getObject$S("errorbar_color");
if (color != null ) {
data.errorBarColor=color;
}data.setID$I(control.getInt$S("datasetID"));
var colVisible=control.getObject$S("visible");
if (colVisible != null ) {
data.colVisible=colVisible;
}return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-01 19:14:12 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
