(function(){var P$=Clazz.newPackage("org.opensourcephysics.ejs"),I$=[[0,'java.util.Locale','org.opensourcephysics.display.OSPRuntime','java.util.ResourceBundle']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "EjsRes");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['res','java.util.ResourceBundle']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setLocale$java_util_Locale', function (locale) {
C$.res=$I$(3).getBundle$S$java_util_Locale("org.opensourcephysics.resources.ejs.ejs_res", locale);
}, 1);

Clazz.newMeth(C$, 'getString$S', function (key) {
try {
return C$.res.getString$S(key);
} catch (e) {
if (Clazz.exceptionOf(e,"java.util.MissingResourceException")){
return '!' + key + '!' ;
} else {
throw e;
}
}
}, 1);

C$.$static$=function(){C$.$static$=0;
{
var language=$I$(1).getDefault$().getLanguage$();
var resourceLocale=$I$(1).ENGLISH;
for (var locale, $locale = 0, $$locale = $I$(2).getInstalledLocales$(); $locale<$$locale.length&&((locale=($$locale[$locale])),1);$locale++) {
if (locale.getLanguage$().equals$O(language)) {
resourceLocale=locale;
break;
}}
C$.res=$I$(3).getBundle$S$java_util_Locale("org.opensourcephysics.resources.ejs.ejs_res", resourceLocale);
};
};
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-31 17:30:10 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
