(function(){var P$=Clazz.newPackage("org.opensourcephysics.display.axes"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PolarAxes", null, null, 'org.opensourcephysics.display.axes.DrawableAxes');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 10:07:38 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
