(function(){var P$=Clazz.newPackage("org.opensourcephysics.display2d"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ICarpet");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:24 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
