(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ScientificField", null, 'org.opensourcephysics.media.core.NumberField');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.zeroLimit=1.0E-10;
},1);

C$.$fields$=[['D',['zeroLimit']]]

Clazz.newMeth(C$, 'c$$I', function (columns) {
C$.c$$I$I.apply(this, [columns, 4]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (columns, sigfigs) {
;C$.superclazz.c$$I$I.apply(this,[columns, sigfigs]);C$.$init$.apply(this);
var d=".";
this.fixedPattern=this.fixedPatternByDefault=true;
var s="";
for (var i=0; i < this.sigfigs - 1; i++) {
s += "0";
}
this.format.applyPattern$S("0" + d + s + "E0" );
}, 1);

Clazz.newMeth(C$, 'setValue$D', function (value) {
if (Math.abs(value) < this.zeroLimit ) {
value=0;
}C$.superclazz.prototype.setValue$D.apply(this, [value]);
});

Clazz.newMeth(C$, 'setSigFigs$I', function (sigfigs) {
if (this.sigfigs == sigfigs) {
return;
}sigfigs=Math.max(sigfigs, 2);
this.sigfigs=Math.min(sigfigs, 6);
});

Clazz.newMeth(C$, 'setExpectedRange$D$D', function (lower, upper) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-26 10:07:41 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
