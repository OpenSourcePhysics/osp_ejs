(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.ImageVideo','java.util.ArrayList','javax.swing.JOptionPane','org.opensourcephysics.media.core.MediaRes','java.util.Collection','org.opensourcephysics.controls.XML','org.opensourcephysics.media.core.VideoIO','javax.swing.JPanel','java.awt.image.BufferedImage','java.awt.Image','java.awt.Dimension','org.opensourcephysics.media.core.ImageVideoRecorder','org.opensourcephysics.tools.ResourceLoader','org.opensourcephysics.media.core.ImageCoordSystem','org.opensourcephysics.media.core.DoubleArray',['org.opensourcephysics.media.core.ImageVideo','.Loader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImageVideo", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.VideoAdapter');
C$.$classes$=[['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.observer=Clazz.new_($I$(8,1));
this.images=Clazz.array($I$(9), [0]);
this.paths=Clazz.array(String, [0]);
this.readOnly=false;
this.deltaT=100;
},1);

C$.$fields$=[['Z',['readOnly'],'D',['deltaT'],'O',['observer','java.awt.Component','images','java.awt.image.BufferedImage[]','paths','String[]']]]

Clazz.newMeth(C$, 'c$$S', function (imageName) {
Clazz.super_(C$, this);
this.readOnly=true;
this.append$S(imageName);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z', function (imageName, sequence) {
C$.c$$S$Z$Z.apply(this, [imageName, sequence, true]);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z$Z', function (imageName, sequence, fileBased) {
Clazz.super_(C$, this);
this.readOnly=fileBased;
this.append$S$Z(imageName, sequence);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Image', function (image) {
Clazz.super_(C$, this);
if (image != null ) {
this.insert$java_awt_ImageA$I$SA(Clazz.array($I$(10), -1, [image]), 0, null);
}}, 1);

Clazz.newMeth(C$, 'c$$java_awt_ImageA', function (images) {
Clazz.super_(C$, this);
if ((images != null ) && (images.length > 0) && (images[0] != null )  ) {
this.insert$java_awt_ImageA$I$SA(images, 0, null);
}}, 1);

Clazz.newMeth(C$, 'setFrameNumber$I', function (n) {
C$.superclazz.prototype.setFrameNumber$I.apply(this, [n]);
this.rawImage=p$1.getImageAtFrame$I$java_awt_Image.apply(this, [this.getFrameNumber$(), this.rawImage]);
this.isValidImage=false;
this.isValidFilteredImage=false;
this.firePropertyChange$S$O$O("framenumber", null,  new Integer(this.getFrameNumber$()));
});

Clazz.newMeth(C$, 'getTime$', function () {
return this.getFrameNumber$() * this.deltaT;
});

Clazz.newMeth(C$, 'setFrameDuration$D', function (millis) {
this.deltaT=millis;
});

Clazz.newMeth(C$, 'setTime$D', function (millis) {
var frameNum=((millis / this.deltaT)|0);
frameNum=Math.max(frameNum, 0);
frameNum=Math.min(frameNum, this.getFrameCount$() - 1);
this.setFrameNumber$I(frameNum);
});

Clazz.newMeth(C$, 'getStartTime$', function () {
return 0;
});

Clazz.newMeth(C$, 'setStartTime$D', function (millis) {
});

Clazz.newMeth(C$, 'getEndTime$', function () {
return this.getDuration$();
});

Clazz.newMeth(C$, 'setEndTime$D', function (millis) {
});

Clazz.newMeth(C$, 'getDuration$', function () {
return p$1.length.apply(this, []) * this.deltaT;
});

Clazz.newMeth(C$, 'getFrameTime$I', function (n) {
return n * this.deltaT;
});

Clazz.newMeth(C$, 'getImages$', function () {
return this.images;
});

Clazz.newMeth(C$, 'append$S', function (imageName) {
this.insert$S$I(imageName, p$1.length.apply(this, []));
});

Clazz.newMeth(C$, 'append$S$Z', function (imageName, sequence) {
this.insert$S$I$Z(imageName, p$1.length.apply(this, []), sequence);
});

Clazz.newMeth(C$, 'insert$S$I', function (imageName, index) {
var array=p$1.loadImages$S$Z$Z.apply(this, [imageName, true, true]);
var images=array[0];
if (images.length > 0) {
var paths=array[1];
this.insert$java_awt_ImageA$I$SA(images, index, paths);
}});

Clazz.newMeth(C$, 'insert$S$I$Z', function (imageName, index, sequence) {
var array=p$1.loadImages$S$Z$Z.apply(this, [imageName, false, sequence]);
var images=array[0];
if (images.length > 0) {
var paths=array[1];
this.insert$java_awt_ImageA$I$SA(images, index, paths);
}});

Clazz.newMeth(C$, 'insert$java_awt_Image$I', function (image, index) {
if (image == null ) {
return;
}this.insert$java_awt_ImageA$I$SA(Clazz.array($I$(10), -1, [image]), index, null);
});

Clazz.newMeth(C$, 'remove$I', function (index) {
if (this.readOnly) return null;
var len=this.images.length;
if ((len == 1) || (len <= index) ) {
return null;
}var removed=this.paths[index];
var newArray=Clazz.array($I$(9), [len - 1]);
System.arraycopy$O$I$O$I$I(this.images, 0, newArray, 0, index);
System.arraycopy$O$I$O$I$I(this.images, index + 1, newArray, index, len - 1 - index );
this.images=newArray;
var newPaths=Clazz.array(String, [len - 1]);
System.arraycopy$O$I$O$I$I(this.paths, 0, newPaths, 0, index);
System.arraycopy$O$I$O$I$I(this.paths, index + 1, newPaths, index, len - 1 - index );
this.paths=newPaths;
if (index < len - 1) {
this.rawImage=p$1.getImageAtFrame$I$java_awt_Image.apply(this, [index, this.rawImage]);
} else {
this.rawImage=p$1.getImageAtFrame$I$java_awt_Image.apply(this, [index - 1, this.rawImage]);
}this.frameCount=this.images.length;
this.endFrameNumber=this.frameCount - 1;
var newDim=this.getSize$();
if ((newDim.height != this.size.height) || (newDim.width != this.size.width) ) {
this.firePropertyChange$S$O$O("size", this.size, newDim);
this.size=newDim;
this.refreshBufferedImage$();
}return removed;
});

Clazz.newMeth(C$, 'getSize$', function () {
var w=this.images[0].getWidth$java_awt_image_ImageObserver(this.observer);
var h=this.images[0].getHeight$java_awt_image_ImageObserver(this.observer);
for (var i=1; i < this.images.length; i++) {
w=Math.max(w, this.images[i].getWidth$java_awt_image_ImageObserver(this.observer));
h=Math.max(h, this.images[i].getHeight$java_awt_image_ImageObserver(this.observer));
}
return Clazz.new_($I$(11,1).c$$I$I,[w, h]);
});

Clazz.newMeth(C$, 'isFileBased$', function () {
return this.getValidPaths$().length == this.paths.length;
});

Clazz.newMeth(C$, 'isEditable$', function () {
return !this.readOnly;
});

Clazz.newMeth(C$, 'setEditable$Z', function (edit) {
if (edit && this.isEditable$() ) return;
if (!edit && !this.isEditable$() ) return;
var imagePath=this.paths[0];
this.readOnly=!edit;
if (this.readOnly) this.paths=Clazz.array(String, [0]);
this.images=Clazz.array($I$(9), [0]);
System.gc$();
this.append$S$Z(imagePath, true);
});

Clazz.newMeth(C$, 'saveInvalidImages$', function () {
var pathList=Clazz.new_($I$(2,1));
var imageList=Clazz.new_($I$(2,1));
for (var i=0; i < this.paths.length; i++) {
if (this.paths[i].equals$O("")) {
pathList.add$O(this.paths[i]);
imageList.add$O(this.images[i]);
}}
if (pathList.isEmpty$()) {
return true;
}var approved=$I$(3,"showConfirmDialog$java_awt_Component$O$S$I$I",[null, $I$(4).getString$S("ImageVideo.Dialog.UnsavedImages.Message1") + $I$(6).NEW_LINE + $I$(4).getString$S("ImageVideo.Dialog.UnsavedImages.Message2") , $I$(4).getString$S("ImageVideo.Dialog.UnsavedImages.Title"), 0, 2]);
if (approved == 0) {
try {
var recorder=Clazz.new_($I$(12,1));
recorder.setExpectedFrameCount$I(imageList.size$());
var file=recorder.selectFile$();
if (file == null ) {
return false;
}var fileName=file.getAbsolutePath$();
var imagesToSave=imageList.toArray$OA(Clazz.array($I$(9), [0]));
var pathArray=$I$(12).saveImages$S$java_awt_image_BufferedImageA(fileName, imagesToSave);
var j=0;
for (var i=0; i < this.paths.length; i++) {
if (this.paths[i].equals$O("")) {
this.paths[i]=pathArray[j++];
}}
if (this.getProperty$S("name") == null ) {
this.setProperty$S$O("name", $I$(6).getName$S(fileName));
this.setProperty$S$O("path", fileName);
this.setProperty$S$O("absolutePath", fileName);
}return true;
} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
ex.printStackTrace$();
} else {
throw ex;
}
}
}return false;
});

Clazz.newMeth(C$, 'getImageAtFrame$I$java_awt_Image', function (frameNumber, defaultImage) {
if (this.readOnly && frameNumber < this.paths.length ) {
if (!this.paths[frameNumber].equals$O("")) {
var image=$I$(13).getImage$S(this.paths[frameNumber]);
if (image != null ) return image;
}} else if (frameNumber < this.images.length && this.images[frameNumber] != null  ) {
return this.images[frameNumber];
}return defaultImage;
}, p$1);

Clazz.newMeth(C$, 'length', function () {
if (this.readOnly) return this.paths.length;
return this.images.length;
}, p$1);

Clazz.newMeth(C$, 'loadImages$S$Z$Z', function (imagePath, alwaysAsk, sequence) {
var res=$I$(13).getResource$S(imagePath);
if (res == null ) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["Image " + imagePath + " not found" ]);
}var image=res.getImage$();
if (image == null ) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["\"" + imagePath + "\" is not an image" ]);
}if (this.getProperty$S("name") == null ) {
this.setProperty$S$O("name", $I$(6).getName$S(imagePath));
this.setProperty$S$O("path", imagePath);
this.setProperty$S$O("absolutePath", res.getAbsolutePath$());
}if (!alwaysAsk && !sequence ) {
var images=Clazz.array($I$(10), -1, [image]);
var paths=Clazz.array(String, -1, [imagePath]);
return Clazz.array(java.lang.Object, -1, [images, paths]);
}var pathList=Clazz.new_($I$(2,1));
pathList.add$O(imagePath);
var name=$I$(6).getName$S(imagePath);
var extension="";
var i=imagePath.lastIndexOf$I(".");
if ((i > 0) && (i < imagePath.length$() - 1) ) {
extension=imagePath.substring$I(i).toLowerCase$();
imagePath=imagePath.substring$I$I(0, i);
}var len=imagePath.length$();
var n=0;
var digits=1;
for (; digits < len; digits++) {
try {
n=Integer.parseInt$S(imagePath.substring$I(len - digits));
} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
break;
} else {
throw ex;
}
}
}
digits--;
if (digits == 0) {
var images=Clazz.array($I$(10), -1, [image]);
var paths=Clazz.array(String, -1, [imagePath + extension]);
return Clazz.array(java.lang.Object, -1, [images, paths]);
}var imageList=Clazz.new_($I$(2,1));
imageList.add$O(image);
var limit=10;
digits=Math.min(digits, 4);
switch (digits) {
case 1:
limit=10;
break;
case 2:
limit=100;
break;
case 3:
limit=1000;
break;
case 4:
limit=10000;
}
var root=imagePath.substring$I$I(0, len - digits);
try {
var asked=false;
while (n < limit - 1){
n++;
var num=String.valueOf$I(n);
var zeros=digits - num.length$();
for (var k=0; k < zeros; k++) {
num="0" + num;
}
imagePath=root + num + extension ;
if (!this.readOnly || imageList.isEmpty$() ) {
image=$I$(13).getImage$S(imagePath);
if (image == null ) {
break;
}} else if ($I$(13).getResource$S(imagePath) == null ) break;
if (!asked && alwaysAsk ) {
asked=true;
var response=$I$(3,"showOptionDialog$java_awt_Component$O$S$I$I$javax_swing_Icon$OA$O",[null, "\"" + name + "\" " + $I$(4).getString$S("ImageVideo.Dialog.LoadSequence.Message") + $I$(6).NEW_LINE + $I$(4).getString$S("ImageVideo.Dialog.LoadSequence.Query") , $I$(4).getString$S("ImageVideo.Dialog.LoadSequence.Title"), 0, 3, null, Clazz.array(String, -1, [$I$(4).getString$S("ImageVideo.Dialog.LoadSequence.Button.SingleImage"), $I$(4).getString$S("ImageVideo.Dialog.LoadSequence.Button.AllImages")]), $I$(4).getString$S("ImageVideo.Dialog.LoadSequence.Button.AllImages")]);
if (response == 0) {
break;
}}if (!this.readOnly || imageList.isEmpty$() ) {
imageList.add$O(image);
}pathList.add$O(imagePath);
}
} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
ex.printStackTrace$();
} else {
throw ex;
}
}
var images=imageList.toArray$OA(Clazz.array($I$(10), [0]));
var paths=pathList.toArray$OA(Clazz.array(String, [0]));
return Clazz.array(java.lang.Object, -1, [images, paths]);
}, p$1);

Clazz.newMeth(C$, 'getValidPaths$', function () {
var pathList=Clazz.new_($I$(2,1));
for (var i=0; i < this.paths.length; i++) {
if (!this.paths[i].equals$O("")) {
pathList.add$O(this.paths[i]);
}}
return pathList.toArray$OA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'getValidPathsRelativeTo$S', function (base) {
var pathList=Clazz.new_($I$(2,1));
for (var i=0; i < this.paths.length; i++) {
if (!this.paths[i].equals$O("")) {
pathList.add$O($I$(6).getPathRelativeTo$S$S(this.paths[i], base));
}}
return pathList.toArray$OA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'insert$java_awt_ImageA$I$SA', function (newImages, index, imagePaths) {
if (this.readOnly && imagePaths == null  ) return;
var len=p$1.length.apply(this, []);
index=Math.min(index, len);
var n=newImages.length;
var buf=Clazz.array($I$(9), [n]);
for (var i=0; i < newImages.length; i++) {
var im=newImages[i];
if (Clazz.instanceOf(im, "java.awt.image.BufferedImage")) {
buf[i]=im;
} else {
var w=im.getWidth$java_awt_image_ImageObserver(null);
var h=im.getHeight$java_awt_image_ImageObserver(null);
buf[i]=Clazz.new_($I$(9,1).c$$I$I$I,[w, h, 1]);
buf[i].createGraphics$().drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(im, 0, 0, null);
}}
var newArray=Clazz.array($I$(9), [len + n]);
System.arraycopy$O$I$O$I$I(this.images, 0, newArray, 0, index);
System.arraycopy$O$I$O$I$I(buf, 0, newArray, index, n);
System.arraycopy$O$I$O$I$I(this.images, index, newArray, index + n, len - index);
this.images=newArray;
if (imagePaths == null ) {
imagePaths=Clazz.array(String, [newImages.length]);
for (var i=0; i < imagePaths.length; i++) {
imagePaths[i]="";
}
}n=imagePaths.length;
var newPaths=Clazz.array(String, [len + n]);
System.arraycopy$O$I$O$I$I(this.paths, 0, newPaths, 0, index);
System.arraycopy$O$I$O$I$I(imagePaths, 0, newPaths, index, n);
System.arraycopy$O$I$O$I$I(this.paths, index, newPaths, index + n, len - index);
this.paths=newPaths;
this.rawImage=p$1.getImageAtFrame$I$java_awt_Image.apply(this, [index, this.rawImage]);
this.frameCount=p$1.length.apply(this, []);
this.endFrameNumber=this.frameCount - 1;
if (this.coords == null ) {
this.size=Clazz.new_([this.rawImage.getWidth$java_awt_image_ImageObserver(this.observer), this.rawImage.getHeight$java_awt_image_ImageObserver(this.observer)],$I$(11,1).c$$I$I);
this.refreshBufferedImage$();
this.coords=Clazz.new_($I$(14,1).c$$I,[this.frameCount]);
this.coords.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.aspects=Clazz.new_($I$(15,1).c$$I$D,[this.frameCount, 1]);
} else {
this.coords.setLength$I(this.frameCount);
this.aspects.setLength$I(this.frameCount);
}var newDim=this.getSize$();
if ((newDim.height != this.size.height) || (newDim.width != this.size.width) ) {
this.firePropertyChange$S$O$O("size", this.size, newDim);
this.size=newDim;
this.refreshBufferedImage$();
}});

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(16,1));
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ImageVideo, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var video=obj;
var base=video.getProperty$S("base");
var paths=video.getValidPathsRelativeTo$S(base);
if (paths.length > 0) {
control.setValue$S$O("paths", paths);
control.setValue$S$O("path", paths[0]);
}if (!video.getFilterStack$().isEmpty$()) {
control.setValue$S$O("filters", video.getFilterStack$().getFilters$());
}control.setValue$S$D("delta_t", video.deltaT);
});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
var paths=control.getObject$S("paths");
if (paths == null ) {
try {
var path=control.getString$S("path");
var seq=control.getBoolean$S("sequence");
if (path != null ) {
var vid=Clazz.new_($I$(1,1).c$$S$Z,[path, seq]);
return vid;
}} catch (ex) {
if (Clazz.exceptionOf(ex,"java.io.IOException")){
ex.printStackTrace$();
return null;
} else {
throw ex;
}
}
}var sequences=control.getObject$S("sequences");
if (sequences != null ) {
try {
var vid=Clazz.new_($I$(1,1).c$$S$Z,[paths[0], sequences[0]]);
for (var i=1; i < paths.length; i++) {
vid.append$S$Z(paths[i], sequences[i]);
}
return vid;
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
ex.printStackTrace$();
return null;
} else {
throw ex;
}
}
}if (paths.length == 0) {
return null;
}var vid=null;
var badPaths=null;
for (var i=0; i < paths.length; i++) {
try {
if (vid == null ) {
vid=Clazz.new_($I$(1,1).c$$S$Z,[paths[i], false]);
} else {
vid.append$S$Z(paths[i], false);
}} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
if (badPaths == null ) {
badPaths=Clazz.new_($I$(2,1));
}badPaths.add$O("\"" + paths[i] + "\"" );
} else {
throw ex;
}
}
}
if (badPaths != null ) {
var s=badPaths.get$I(0);
for (var i=1; i < badPaths.size$(); i++) {
s += ", " + badPaths.get$I(i);
}
$I$(3,"showMessageDialog$java_awt_Component$O$S$I",[null, $I$(4).getString$S("ImageVideo.Dialog.MissingImages.Message") + ":\n" + s , $I$(4).getString$S("ImageVideo.Dialog.MissingImages.Title"), 2]);
}if (vid == null ) {
return null;
}vid.rawImage=vid.images[0];
var filters=Clazz.getClass($I$(5),['add$O','addAll$java_util_Collection','clear$','contains$O','containsAll$java_util_Collection','equals$O','hashCode$','isEmpty$','iterator$','parallelStream$','remove$O','removeAll$java_util_Collection','removeIf$java_util_function_Predicate','retainAll$java_util_Collection','size$','spliterator$','stream$','toArray$','toArray$OA']).cast$O(control.getObject$S("filters"));
if (filters != null ) {
vid.getFilterStack$().clear$();
var it=filters.iterator$();
while (it.hasNext$()){
var filter=it.next$();
vid.getFilterStack$().addFilter$org_opensourcephysics_media_core_Filter(filter);
}
}var path=paths[0];
var ext=$I$(6).getExtension$S(path);
var type=$I$(7).getVideoType$S$S("image", ext);
if (type != null ) vid.setProperty$S$O("video_type", type);
vid.deltaT=control.getDouble$S("delta_t");
return vid;
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
return obj;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-28 10:19:01 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
