(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "VideoType");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-28 10:19:01 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
