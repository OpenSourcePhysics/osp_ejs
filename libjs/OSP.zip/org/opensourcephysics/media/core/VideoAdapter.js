(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),I$=[[0,'java.util.HashMap','org.opensourcephysics.media.core.FilterStack','org.opensourcephysics.controls.OSPLog','javax.swing.event.SwingPropertyChangeSupport','java.awt.image.BufferedImage','java.awt.Color',['java.awt.geom.Point2D','.Double']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VideoAdapter", null, null, 'org.opensourcephysics.media.core.Video');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.rate=1;
this.playing=false;
this.looping=false;
this.mouseEnabled=false;
this.visible=true;
this.isMeasured=false;
this.isValidMeasure=false;
this.widthDominates=true;
this.isValidImage=false;
this.isValidFilteredImage=false;
this.properties=Clazz.new_($I$(1,1));
this.filterStack=Clazz.new_($I$(2,1));
},1);

C$.$fields$=[['Z',['playing','looping','mouseEnabled','visible','isMeasured','isValidMeasure','widthDominates','isValidImage','isValidFilteredImage'],'D',['rate','minX','maxX','minY','maxY'],'I',['frameCount','frameNumber','startFrameNumber','endFrameNumber'],'O',['rawImage','java.awt.Image','size','java.awt.Dimension','bufferedImage','java.awt.image.BufferedImage','+filteredImage','coords','org.opensourcephysics.media.core.ImageCoordSystem','aspects','org.opensourcephysics.media.core.DoubleArray','support','java.beans.PropertyChangeSupport','properties','java.util.HashMap','filterStack','org.opensourcephysics.media.core.FilterStack','clearRaster','java.awt.image.Raster']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
this.initialize$();
}, 1);

Clazz.newMeth(C$, 'draw$org_opensourcephysics_display_DrawingPanel$java_awt_Graphics', function (panel, g) {
if (!this.visible) {
return;
}var g2=g;
if (((Clazz.instanceOf(panel, "org.opensourcephysics.media.core.VideoPanel")) && (panel).isDrawingInImageSpace$() ) || this.isMeasured ) {
g2=g2.create$();
g2.transform$java_awt_geom_AffineTransform(panel.getPixelTransform$());
if (Clazz.instanceOf(panel, "org.opensourcephysics.media.core.VideoPanel")) {
var vidPanel=panel;
if (!vidPanel.isDrawingInImageSpace$()) {
var coords=vidPanel.getCoords$();
g2.transform$java_awt_geom_AffineTransform(coords.getToWorldTransform$I(this.frameNumber));
}} else {
g2.transform$java_awt_geom_AffineTransform(this.coords.getToWorldTransform$I(this.frameNumber));
}if (this.filterStack.isEmpty$() || !this.filterStack.isEnabled$() ) {
g2.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.rawImage, 0, 0, panel);
} else {
g2.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.getImage$(), 0, 0, panel);
}g2.dispose$();
} else {
var centerX=(panel.getXMax$() + panel.getXMin$()) / 2;
var centerY=(panel.getYMax$() + panel.getYMin$()) / 2;
var xoffset=panel.xToPix$D(centerX) - (this.size.width/2|0);
var yoffset=panel.yToPix$D(centerY) - (this.size.height/2|0);
if (this.filterStack.isEmpty$() || !this.filterStack.isEnabled$() ) {
g2.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.rawImage, xoffset, yoffset, panel);
} else {
g2.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.getImage$(), xoffset, yoffset, panel);
}}});

Clazz.newMeth(C$, 'setVisible$Z', function (visible) {
this.visible=visible;
this.firePropertyChange$S$O$O("videoVisible", null,  Boolean.from(visible));
});

Clazz.newMeth(C$, 'isVisible$', function () {
return this.visible;
});

Clazz.newMeth(C$, 'getXMin$', function () {
if (!this.isValidMeasure) {
this.findMinMaxValues$();
}return this.minX;
});

Clazz.newMeth(C$, 'getXMax$', function () {
if (!this.isValidMeasure) {
this.findMinMaxValues$();
}return this.maxX;
});

Clazz.newMeth(C$, 'getYMin$', function () {
if (!this.isValidMeasure) {
this.findMinMaxValues$();
}return this.minY;
});

Clazz.newMeth(C$, 'getYMax$', function () {
if (!this.isValidMeasure) {
this.findMinMaxValues$();
}return this.maxY;
});

Clazz.newMeth(C$, 'isMeasured$', function () {
return this.isMeasured;
});

Clazz.newMeth(C$, 'getImage$', function () {
if (!this.isValidImage) {
this.isValidImage=true;
var g=this.bufferedImage.createGraphics$();
this.bufferedImage.setData$java_awt_image_Raster(this.clearRaster);
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.rawImage, 0, 0, null);
}if (this.filterStack.isEmpty$() || !this.filterStack.isEnabled$() ) {
return this.bufferedImage;
} else if (!this.isValidFilteredImage) {
this.isValidFilteredImage=true;
this.filteredImage=this.filterStack.getFilteredImage$java_awt_image_BufferedImage(this.bufferedImage);
}return this.filteredImage;
});

Clazz.newMeth(C$, 'findInteractive$org_opensourcephysics_display_DrawingPanel$I$I', function (panel, xpix, ypix) {
if (!this.mouseEnabled) {
return null;
}return this;
});

Clazz.newMeth(C$, 'setEnabled$Z', function (enabled) {
this.mouseEnabled=enabled;
});

Clazz.newMeth(C$, 'isEnabled$', function () {
return this.mouseEnabled;
});

Clazz.newMeth(C$, 'setFrameX$I$D', function (n, x) {
this.setFrameXY$I$D$D(n, x, this.coords.imageToWorldY$I$D$D(n, 0, 0));
});

Clazz.newMeth(C$, 'setX$D', function (x) {
for (var n=0; n < this.frameCount; n++) {
this.setFrameX$I$D(n, x);
}
});

Clazz.newMeth(C$, 'setFrameY$I$D', function (n, y) {
this.setFrameXY$I$D$D(n, this.coords.imageToWorldX$I$D$D(n, 0, 0), y);
});

Clazz.newMeth(C$, 'setY$D', function (y) {
for (var n=0; n < this.frameCount; n++) {
this.setFrameY$I$D(n, y);
}
});

Clazz.newMeth(C$, 'getX$', function () {
return this.coords.imageToWorldX$I$D$D(this.frameNumber, 0, 0);
});

Clazz.newMeth(C$, 'getY$', function () {
return this.coords.imageToWorldY$I$D$D(this.frameNumber, 0, 0);
});

Clazz.newMeth(C$, 'setFrameXY$I$D$D', function (n, x, y) {
var sin=this.coords.getSine$I(n);
var cos=this.coords.getCosine$I(n);
var tx=this.coords.getScaleX$I(n) * (y * sin - x * cos);
var ty=this.coords.getScaleY$I(n) * (y * cos + x * sin);
this.coords.setOriginXY$I$D$D(n, tx, ty);
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
for (var n=0; n < this.frameCount; n++) {
this.setFrameXY$I$D$D(n, x, y);
}
});

Clazz.newMeth(C$, 'setFrameRelativeAspect$I$D', function (n, relativeAspect) {
if ((relativeAspect < 0.001 ) || (relativeAspect > 1000 ) ) {
return;
}this.aspects.set$I$D(n, Math.abs(relativeAspect));
if (this.isMeasured) {
if (this.widthDominates) {
this.setFrameWidth$I$D(n, this.size.width / this.coords.getScaleX$I(n));
} else {
this.setFrameHeight$I$D(n, this.size.height / this.coords.getScaleY$I(n));
}}});

Clazz.newMeth(C$, 'setRelativeAspect$D', function (relativeAspect) {
for (var n=0; n < this.frameCount; n++) {
this.setFrameRelativeAspect$I$D(n, relativeAspect);
}
});

Clazz.newMeth(C$, 'getRelativeAspect$', function () {
return this.aspects.get$I(this.frameNumber);
});

Clazz.newMeth(C$, 'setFrameWidth$I$D', function (n, width) {
if (width == 0 ) {
return;
}width=Math.abs(width);
var x=this.coords.imageToWorldX$I$D$D(n, 0, 0);
var y=this.coords.imageToWorldY$I$D$D(n, 0, 0);
var scaleX=this.size.width / width;
this.coords.setScaleX$I$D(n, scaleX);
this.coords.setScaleY$I$D(n, scaleX * this.aspects.get$I(n));
this.widthDominates=true;
this.setFrameXY$I$D$D(n, x, y);
});

Clazz.newMeth(C$, 'setWidth$D', function (width) {
for (var n=0; n < this.frameCount; n++) {
this.setFrameWidth$I$D(n, width);
}
});

Clazz.newMeth(C$, 'getWidth$', function () {
return this.size.width / this.coords.getScaleX$I(this.frameNumber);
});

Clazz.newMeth(C$, 'setFrameHeight$I$D', function (n, height) {
if (height == 0 ) {
return;
}height=Math.abs(height);
var x=this.coords.imageToWorldX$I$D$D(n, 0, 0);
var y=this.coords.imageToWorldY$I$D$D(n, 0, 0);
var scaleY=this.size.height / height;
this.coords.setScaleY$I$D(n, scaleY);
this.coords.setScaleX$I$D(n, scaleY / this.aspects.get$I(n));
this.widthDominates=false;
this.setFrameXY$I$D$D(n, x, y);
});

Clazz.newMeth(C$, 'setHeight$D', function (height) {
for (var n=0; n < this.frameCount; n++) {
this.setFrameHeight$I$D(n, height);
}
});

Clazz.newMeth(C$, 'getHeight$', function () {
return this.size.height / this.coords.getScaleY$I(this.frameNumber);
});

Clazz.newMeth(C$, 'setFrameAngle$I$D', function (n, theta) {
var x=this.coords.imageToWorldX$I$D$D(n, 0, 0);
var y=this.coords.imageToWorldY$I$D$D(n, 0, 0);
var cos=Math.cos(theta);
var sin=Math.sin(theta);
this.coords.setCosineSine$I$D$D(n, cos, -sin);
this.setFrameXY$I$D$D(n, x, y);
});

Clazz.newMeth(C$, 'setAngle$D', function (theta) {
for (var n=0; n < this.frameCount; n++) {
this.setFrameAngle$I$D(n, theta);
}
});

Clazz.newMeth(C$, 'getAngle$', function () {
return -this.coords.getAngle$I(this.frameNumber);
});

Clazz.newMeth(C$, 'step$', function () {
this.stop$();
this.setFrameNumber$I(this.frameNumber + 1);
});

Clazz.newMeth(C$, 'back$', function () {
this.stop$();
this.setFrameNumber$I(this.frameNumber - 1);
});

Clazz.newMeth(C$, 'getFrameCount$', function () {
return this.frameCount;
});

Clazz.newMeth(C$, 'getFrameNumber$', function () {
return this.frameNumber;
});

Clazz.newMeth(C$, 'setFrameNumber$I', function (n) {
if (n == this.frameNumber) {
return;
}n=Math.min(n, this.endFrameNumber);
n=Math.max(n, this.startFrameNumber);
this.firePropertyChange$S$O$O("nextframe", null, new Integer(n));
this.frameNumber=n;
});

Clazz.newMeth(C$, 'getStartFrameNumber$', function () {
return this.startFrameNumber;
});

Clazz.newMeth(C$, 'setStartFrameNumber$I', function (n) {
if (n == this.startFrameNumber) {
return;
}n=Math.max(0, n);
this.startFrameNumber=Math.min(this.endFrameNumber, n);
this.firePropertyChange$S$O$O("startframe", null, Integer.valueOf$I(this.startFrameNumber));
});

Clazz.newMeth(C$, 'getEndFrameNumber$', function () {
return this.endFrameNumber;
});

Clazz.newMeth(C$, 'setEndFrameNumber$I', function (n) {
if (n == this.endFrameNumber) {
return;
}if (this.frameCount > 1) {
n=Math.min(this.frameCount - 1, n);
}this.endFrameNumber=Math.max(this.startFrameNumber, n);
this.firePropertyChange$S$O$O("endframe", null, Integer.valueOf$I(this.endFrameNumber));
});

Clazz.newMeth(C$, 'getFrameTime$I', function (n) {
return -1;
});

Clazz.newMeth(C$, 'getFrameDuration$I', function (n) {
if (this.frameCount == 1) {
return this.getDuration$();
}if (n == this.frameCount - 1) {
return this.getDuration$() - this.getFrameTime$I(n);
}return this.getFrameTime$I(n + 1) - this.getFrameTime$I(n);
});

Clazz.newMeth(C$, 'play$', function () {
this.playing=true;
});

Clazz.newMeth(C$, 'stop$', function () {
this.playing=false;
});

Clazz.newMeth(C$, 'reset$', function () {
this.stop$();
this.setFrameNumber$I(this.startFrameNumber);
});

Clazz.newMeth(C$, 'getTime$', function () {
return -1;
});

Clazz.newMeth(C$, 'setTime$D', function (millis) {
});

Clazz.newMeth(C$, 'getStartTime$', function () {
return -1;
});

Clazz.newMeth(C$, 'setStartTime$D', function (millis) {
});

Clazz.newMeth(C$, 'getEndTime$', function () {
return -1;
});

Clazz.newMeth(C$, 'setEndTime$D', function (millis) {
});

Clazz.newMeth(C$, 'getDuration$', function () {
return -1;
});

Clazz.newMeth(C$, 'goToStart$', function () {
this.setFrameNumber$I(this.startFrameNumber);
});

Clazz.newMeth(C$, 'goToEnd$', function () {
this.setFrameNumber$I(this.endFrameNumber);
});

Clazz.newMeth(C$, 'setPlaying$Z', function (playing) {
if (playing) {
this.play$();
} else {
this.stop$();
}});

Clazz.newMeth(C$, 'isPlaying$', function () {
return this.playing;
});

Clazz.newMeth(C$, 'setLooping$Z', function (loops) {
if (this.looping == loops ) {
return;
}this.looping=loops;
this.firePropertyChange$S$O$O("looping", null,  Boolean.from(this.looping));
});

Clazz.newMeth(C$, 'isLooping$', function () {
return this.looping;
});

Clazz.newMeth(C$, 'setRate$D', function (rate) {
rate=Math.abs(rate);
if ((rate == this.rate ) || (rate == 0 ) ) {
return;
}this.rate=rate;
});

Clazz.newMeth(C$, 'getRate$', function () {
return this.rate;
});

Clazz.newMeth(C$, 'setCoords$org_opensourcephysics_media_core_ImageCoordSystem', function (coords) {
if (coords === this.coords ) {
return;
}this.coords.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
coords.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.coords=coords;
this.isMeasured=true;
this.isValidMeasure=false;
this.firePropertyChange$S$O$O("coords", null, coords);
});

Clazz.newMeth(C$, 'getCoords$', function () {
return this.coords;
});

Clazz.newMeth(C$, 'setFilterStack$org_opensourcephysics_media_core_FilterStack', function (stack) {
this.filterStack.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
this.filterStack=stack;
this.filterStack.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
});

Clazz.newMeth(C$, 'getFilterStack$', function () {
return this.filterStack;
});

Clazz.newMeth(C$, 'setProperty$S$O', function (name, value) {
if (name.equals$O("measure")) {
this.isValidMeasure=false;
} else {
this.properties.put$O$O(name, value);
}});

Clazz.newMeth(C$, 'getProperty$S', function (name) {
return this.properties.get$O(name);
});

Clazz.newMeth(C$, 'getPropertyNames$', function () {
return this.properties.keySet$();
});

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
this.support.addPropertyChangeListener$java_beans_PropertyChangeListener(listener);
});

Clazz.newMeth(C$, 'addPropertyChangeListener$S$java_beans_PropertyChangeListener', function (property, listener) {
this.support.addPropertyChangeListener$S$java_beans_PropertyChangeListener(property, listener);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
this.support.removePropertyChangeListener$java_beans_PropertyChangeListener(listener);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$S$java_beans_PropertyChangeListener', function (property, listener) {
this.support.removePropertyChangeListener$S$java_beans_PropertyChangeListener(property, listener);
});

Clazz.newMeth(C$, 'dispose$', function () {
if (this.coords != null ) this.coords.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
this.getFilterStack$().setInspectorsVisible$Z(false);
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
if (e.getSource$() === this.coords ) {
this.isMeasured=true;
this.isValidMeasure=false;
} else if (e.getSource$() === this.filterStack ) {
this.isValidFilteredImage=false;
this.support.firePropertyChange$java_beans_PropertyChangeEvent(e);
}});

Clazz.newMeth(C$, 'firePropertyChange$S$O$O', function (property, oldVal, newVal) {
this.support.firePropertyChange$S$O$O(property, oldVal, newVal);
});

Clazz.newMeth(C$, 'finalize$', function () {
$I$(3,"finer$S",[this.getClass$().getSimpleName$() + " resources released by garbage collector"]);
});

Clazz.newMeth(C$, 'initialize$', function () {
this.support=Clazz.new_($I$(4,1).c$$O,[this]);
this.filterStack.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
});

Clazz.newMeth(C$, 'refreshBufferedImage$', function () {
if ((this.bufferedImage == null ) || (this.bufferedImage.getWidth$() != this.size.width) || (this.bufferedImage.getHeight$() != this.size.height)  ) {
this.bufferedImage=Clazz.new_($I$(5,1).c$$I$I$I,[this.size.width, this.size.height, 1]);
var clear=Clazz.new_($I$(6,1).c$$I$I$I$I,[0, 0, 0, 0]).getRGB$();
var rgb=Clazz.array(Integer.TYPE, [this.size.width * this.size.height]);
for (var i=0; i < rgb.length; i++) {
rgb[i]=clear;
}
this.bufferedImage.setRGB$I$I$I$I$IA$I$I(0, 0, this.size.width, this.size.height, rgb, 0, this.size.width);
this.clearRaster=this.bufferedImage.getData$();
this.isValidImage=false;
}});

Clazz.newMeth(C$, 'findMinMaxValues$', function () {
var clip=this.getProperty$S("videoclip");
var corner=Clazz.new_($I$(7,1).c$$D$D,[0, 0]);
var start=0;
if (clip != null ) {
start=clip.getStartFrameNumber$();
}var at=this.coords.getToWorldTransform$I(start);
at.transform$java_awt_geom_Point2D$java_awt_geom_Point2D(corner, corner);
this.maxX=this.minX=corner.getX$();
this.maxY=this.minY=corner.getY$();
var stepCount=this.frameCount;
if (clip != null ) {
stepCount=clip.getStepCount$();
}for (var n=0; n < stepCount; n++) {
if (clip == null ) {
at=this.coords.getToWorldTransform$I(n);
} else {
at=this.coords.getToWorldTransform$I(clip.stepToFrame$I(n));
}for (var i=0; i < 4; i++) {
switch (i) {
case 0:
corner.setLocation$D$D(0, 0);
break;
case 1:
corner.setLocation$D$D(this.size.width, 0);
break;
case 2:
corner.setLocation$D$D(0, this.size.height);
break;
case 3:
corner.setLocation$D$D(this.size.width, this.size.height);
}
at.transform$java_awt_geom_Point2D$java_awt_geom_Point2D(corner, corner);
this.minX=Math.min(corner.getX$(), this.minX);
this.maxX=Math.max(corner.getX$(), this.maxX);
this.minY=Math.min(corner.getY$(), this.minY);
this.maxY=Math.max(corner.getY$(), this.maxY);
}
}
this.isValidMeasure=true;
});
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:28 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
