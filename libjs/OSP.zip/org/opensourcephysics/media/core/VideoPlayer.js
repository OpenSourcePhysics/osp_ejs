(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},p$2={},I$=[[0,'java.awt.event.MouseAdapter','java.util.HashMap','java.awt.Color','javax.swing.JOptionPane','javax.swing.JPanel','java.awt.BorderLayout','javax.swing.JButton','org.opensourcephysics.display.DisplayRes','java.awt.event.KeyAdapter','java.awt.event.FocusAdapter','javax.swing.JTextField','javax.swing.JLabel','javax.swing.Box','org.opensourcephysics.media.core.MediaRes','java.util.ArrayList','java.awt.font.FontRenderContext','java.awt.Dimension','javax.swing.BorderFactory','org.opensourcephysics.media.core.VideoPlayer','org.opensourcephysics.tools.FontSizer','java.text.NumberFormat','org.opensourcephysics.tools.ResourceLoader','java.awt.event.ComponentAdapter','org.opensourcephysics.media.core.ClipControl','org.opensourcephysics.media.core.VideoClip','java.util.TreeMap','java.awt.EventQueue','javax.swing.JToolBar',['org.opensourcephysics.media.core.VideoPlayer','.PlayerButton'],'javax.swing.SpinnerNumberModel','javax.swing.JSpinner',['javax.swing.JSpinner','.NumberEditor'],'java.awt.Font','Boolean','javax.swing.JSlider','java.util.Hashtable','org.opensourcephysics.display.OSPRuntime','javax.swing.JPopupMenu','javax.swing.JMenuItem','java.awt.Frame','java.awt.Toolkit','java.awt.Cursor','javax.swing.event.MouseInputAdapter','javax.swing.SwingUtilities','javax.swing.KeyStroke','javax.swing.JMenu','javax.swing.JCheckBoxMenuItem',['org.opensourcephysics.media.core.VideoPlayer','.GoToDialog']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VideoPlayer", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JLabel', 'java.beans.PropertyChangeListener');
C$.$classes$=[['PlayerButton',4],['GoToDialog',12]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.inspectorButtonVisible=true;
this.$height=54;
this.disabled=false;
},1);

C$.$fields$=[['Z',['inspectorButtonVisible','disabled'],'I',['$height'],'S',['readoutType','active'],'O',['vidPanel','org.opensourcephysics.media.core.VideoPanel','clipControl','org.opensourcephysics.media.core.ClipControl','readoutTypes','String[]','toolbar','javax.swing.JToolBar','readout','javax.swing.JButton','+playButton','+resetButton','rateSpinner','javax.swing.JSpinner','stepButton','javax.swing.JButton','+stepSizeButton','+backButton','+loopButton','+inspectorButton','slider','javax.swing.JSlider','sliderLabels','java.util.Hashtable','inLabel','javax.swing.JLabel','+outLabel','readoutListener','java.awt.event.ActionListener','+timeSetListener','+goToListener']]
,['O',['inOutIcon','javax.swing.Icon','+playIcon','+grayPlayIcon','+pauseIcon','+resetIcon','+loopIcon','+noloopIcon','+videoClipIcon','+stepIcon','+grayStepIcon','+backIcon','+grayBackIcon','goToDialog','org.opensourcephysics.media.core.VideoPlayer.GoToDialog','timeFormat','java.text.NumberFormat']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_VideoPanel$org_opensourcephysics_media_core_VideoClip', function (panel, clip) {
C$.c$$org_opensourcephysics_media_core_VideoPanel.apply(this, [panel]);
this.setVideoClip$org_opensourcephysics_media_core_VideoClip(clip);
}, 1);

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_VideoPanel', function (panel) {
Clazz.super_(C$, this);
this.vidPanel=panel;
this.vidPanel.addComponentListener$java_awt_event_ComponentListener(((P$.VideoPlayer$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.ComponentAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'componentResized$java_awt_event_ComponentEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.isPlayerVisible$()) {
p$2.setBounds.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.repaint$();
}});
})()
), Clazz.new_($I$(23,1),[this, null],P$.VideoPlayer$1)));
C$.timeFormat.setMinimumIntegerDigits$I(1);
C$.timeFormat.setMaximumFractionDigits$I(3);
C$.timeFormat.setMinimumFractionDigits$I(3);
p$2.createGUI.apply(this, []);
this.clipControl=$I$(24,"getControl$org_opensourcephysics_media_core_VideoClip",[Clazz.new_($I$(25,1).c$$org_opensourcephysics_media_core_Video,[null])]);
this.clipControl.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.getVideoClip$().addPropertyChangeListener$java_beans_PropertyChangeListener(this);
p$2.updatePlayButtons$Z.apply(this, [false]);
p$2.updateSlider.apply(this, []);
this.setReadoutTypes$S$S("frame time step", "frame");
this.refresh$();
}, 1);

Clazz.newMeth(C$, 'setVideoClip$org_opensourcephysics_media_core_VideoClip', function (clip) {
var playing=this.clipControl.isPlaying$();
this.stop$();
if (this.getVideoClip$() === clip ) {
var looping=this.clipControl.isLooping$();
var rate=this.clipControl.getRate$();
var duration=this.clipControl.getMeanFrameDuration$();
this.clipControl.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
this.clipControl.dispose$();
this.clipControl=$I$(24).getControl$org_opensourcephysics_media_core_VideoClip(clip);
this.clipControl.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.clipControl.setLooping$Z(looping);
this.clipControl.setRate$D(rate);
this.clipControl.setFrameDuration$D(duration);
if (playing) {
this.clipControl.play$();
}var inspector=this.getVideoClip$().inspector;
if (inspector != null ) {
inspector.clipControl=this.clipControl;
}} else {
var oldClip=this.getVideoClip$();
oldClip.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
oldClip.hideClipInspector$();
var video=oldClip.getVideo$();
if (video != null ) {
video.dispose$();
}oldClip.video=null;
if (clip == null ) {
clip=Clazz.new_($I$(25,1).c$$org_opensourcephysics_media_core_Video,[null]);
}clip.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.clipControl.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
this.clipControl.dispose$();
this.clipControl=$I$(24).getControl$org_opensourcephysics_media_core_VideoClip(clip);
this.clipControl.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.setReadoutTypes$S$S("frame time step", clip.readoutType);
p$2.updatePlayButtons$Z.apply(this, [this.clipControl.isPlaying$()]);
p$2.updateLoopButton$Z.apply(this, [this.clipControl.isLooping$()]);
p$2.updateReadout.apply(this, []);
p$2.updateSlider.apply(this, []);
this.firePropertyChange$S$O$O("videoclip", oldClip, clip);
System.gc$();
}});

Clazz.newMeth(C$, 'getVideoClip$', function () {
return this.clipControl.getVideoClip$();
});

Clazz.newMeth(C$, 'getClipControl$', function () {
return this.clipControl;
});

Clazz.newMeth(C$, 'setReadoutTypes$S$S', function (types, typeToSelect) {
var map=Clazz.new_($I$(26,1));
var list=types.toLowerCase$();
var i=list.indexOf$S("time");
if (i >= 0) {
map.put$O$O(Integer.valueOf$I(i), "time");
}i=list.indexOf$S("step");
if (i >= 0) {
map.put$O$O(Integer.valueOf$I(i), "step");
}i=list.indexOf$S("frame");
if (i >= 0) {
map.put$O$O(Integer.valueOf$I(i), "frame");
}if (map.isEmpty$()) {
return;
}this.readoutTypes=map.values$().toArray$OA(Clazz.array(String, [0]));
if (typeToSelect == null ) typeToSelect=this.readoutTypes[0];
this.setReadoutType$S(typeToSelect);
});

Clazz.newMeth(C$, 'setReadoutType$S', function (type) {
var name=type.toLowerCase$();
var tip=" " + $I$(14).getString$S("VideoPlayer.Readout.ToolTip");
if (name.indexOf$S("time") >= 0) {
this.readoutType="time";
this.readout.setToolTipText$S($I$(14).getString$S("VideoPlayer.Readout.ToolTip.Time") + tip);
} else if (name.indexOf$S("step") >= 0) {
this.readoutType="step";
this.readout.setToolTipText$S($I$(14).getString$S("VideoPlayer.Readout.ToolTip.Step") + tip);
} else if (name.indexOf$S("frame") >= 0) {
this.readoutType="frame";
this.readout.setToolTipText$S($I$(14).getString$S("VideoPlayer.Readout.ToolTip.Frame") + tip);
}var isListed=false;
for (var i=0; i < this.readoutTypes.length; i++) {
isListed=isListed || (this.readoutTypes[i].equals$O(this.readoutType)) ;
}
if (!isListed) {
var newList=Clazz.array(String, [this.readoutTypes.length + 1]);
newList[0]=this.readoutType;
for (var i=0; i < this.readoutTypes.length; i++) {
newList[i + 1]=this.readoutTypes[i];
}
this.readoutTypes=newList;
}this.getVideoClip$().readoutType=this.readoutType;
p$2.updateReadout.apply(this, []);
});

Clazz.newMeth(C$, 'play$', function () {
this.clipControl.play$();
});

Clazz.newMeth(C$, 'stop$', function () {
this.clipControl.stop$();
});

Clazz.newMeth(C$, 'step$', function () {
this.stop$();
this.clipControl.step$();
});

Clazz.newMeth(C$, 'back$', function () {
this.stop$();
this.clipControl.back$();
});

Clazz.newMeth(C$, 'setRate$D', function (rate) {
this.clipControl.setRate$D(rate);
});

Clazz.newMeth(C$, 'getRate$', function () {
return this.clipControl.getRate$();
});

Clazz.newMeth(C$, 'setLooping$Z', function (looping) {
this.clipControl.setLooping$Z(looping);
});

Clazz.newMeth(C$, 'isLooping$', function () {
return this.clipControl.isLooping$();
});

Clazz.newMeth(C$, 'setStepNumber$I', function (n) {
this.clipControl.setStepNumber$I(n);
});

Clazz.newMeth(C$, 'getStepNumber$', function () {
return this.clipControl.getStepNumber$();
});

Clazz.newMeth(C$, 'getFrameNumber$', function () {
return this.clipControl.getFrameNumber$();
});

Clazz.newMeth(C$, 'getTime$', function () {
return this.clipControl.getTime$() + this.clipControl.clip.getStartTime$();
});

Clazz.newMeth(C$, 'getStepTime$I', function (stepNumber) {
if (stepNumber < 0 || stepNumber >= this.clipControl.clip.getStepCount$() ) return NaN;
return this.clipControl.getStepTime$I(stepNumber) + this.clipControl.clip.getStartTime$();
});

Clazz.newMeth(C$, 'getFrameTime$I', function (frameNumber) {
return this.clipControl.clip.getStartTime$() + (frameNumber - this.clipControl.clip.getStartFrameNumber$()) * this.clipControl.getMeanFrameDuration$();
});

Clazz.newMeth(C$, 'getMeanStepDuration$', function () {
var duration=this.getClipControl$().getMeanFrameDuration$() * this.getVideoClip$().getStepSize$();
return duration;
});

Clazz.newMeth(C$, 'setInspectorButtonVisible$Z', function (visible) {
if (visible == this.inspectorButtonVisible ) {
return;
}var runner=((P$.VideoPlayer$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].inspectorButtonVisible=this.$finals$.visible;
if (this.$finals$.visible) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].toolbar.add$java_awt_Component(this.b$['org.opensourcephysics.media.core.VideoPlayer'].inspectorButton);
} else {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].toolbar.remove$java_awt_Component(this.b$['org.opensourcephysics.media.core.VideoPlayer'].inspectorButton);
}this.b$['org.opensourcephysics.media.core.VideoPlayer'].toolbar.revalidate$();
});
})()
), Clazz.new_(P$.VideoPlayer$2.$init$,[this, {visible:visible}]));
$I$(27).invokeLater$Runnable(runner);
});

Clazz.newMeth(C$, 'setLoopingButtonVisible$Z', function (visible) {
var runner=((P$.VideoPlayer$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
if (this.$finals$.visible) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].toolbar.add$java_awt_Component(this.b$['org.opensourcephysics.media.core.VideoPlayer'].loopButton);
} else {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].toolbar.remove$java_awt_Component(this.b$['org.opensourcephysics.media.core.VideoPlayer'].loopButton);
}this.b$['org.opensourcephysics.media.core.VideoPlayer'].toolbar.revalidate$();
});
})()
), Clazz.new_(P$.VideoPlayer$3.$init$,[this, {visible:visible}]));
$I$(27).invokeLater$Runnable(runner);
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var name=e.getPropertyName$();
if (name.equals$O("stepnumber")) {
p$2.updateReadout.apply(this, []);
p$2.updatePlayButtons$Z.apply(this, [this.clipControl.isPlaying$()]);
this.firePropertyChange$S$O$O("stepnumber", null, e.getNewValue$());
} else if (name.equals$O("frameduration")) {
p$2.updateReadout.apply(this, []);
this.firePropertyChange$S$O$O("frameduration", null, e.getNewValue$());
} else if (name.equals$O("playing")) {
var playing=(e.getNewValue$()).booleanValue$();
p$2.updatePlayButtons$Z.apply(this, [playing]);
this.firePropertyChange$S$O$O("playing", null, e.getNewValue$());
} else if (name.equals$O("looping")) {
var looping=(e.getNewValue$()).booleanValue$();
p$2.updateLoopButton$Z.apply(this, [looping]);
} else if (name.equals$O("rate")) {
this.rateSpinner.setValue$O( new Double(this.getRate$()));
} else if (name.equals$O("stepcount")) {
p$2.updatePlayButtons$Z.apply(this, [this.clipControl.isPlaying$()]);
p$2.updateReadout.apply(this, []);
p$2.updateSlider.apply(this, []);
} else if (name.equals$O("framecount")) {
p$2.updateSlider.apply(this, []);
} else if (name.equals$O("stepsize")) {
p$2.updateReadout.apply(this, []);
p$2.updateSlider.apply(this, []);
} else if (name.equals$O("startframe")) {
p$2.updateReadout.apply(this, []);
p$2.updateSlider.apply(this, []);
} else if (name.equals$O("starttime")) {
p$2.updateReadout.apply(this, []);
}});

Clazz.newMeth(C$, 'refresh$', function () {
this.stepButton.setToolTipText$S($I$(14).getString$S("VideoPlayer.Button.StepForward.ToolTip"));
this.backButton.setToolTipText$S($I$(14).getString$S("VideoPlayer.Button.StepBack.ToolTip"));
this.resetButton.setToolTipText$S($I$(14).getString$S("VideoPlayer.Button.Reset.ToolTip"));
this.inspectorButton.setToolTipText$S($I$(14).getString$S("VideoPlayer.Button.ClipSettings.ToolTip"));
this.loopButton.setToolTipText$S($I$(14).getString$S("VideoPlayer.Button.Looping.ToolTip"));
this.setReadoutType$S(this.readoutType);
p$2.updatePlayButtons$Z.apply(this, [this.clipControl.isPlaying$()]);
p$2.updateLoopButton$Z.apply(this, [this.clipControl.isLooping$()]);
if (this.getVideoClip$().inspector != null ) {
this.getVideoClip$().inspector.refresh$();
}});

Clazz.newMeth(C$, 'setLocale$java_util_Locale', function (locale) {
C$.timeFormat=$I$(21).getNumberInstance$java_util_Locale(locale);
});

Clazz.newMeth(C$, 'setEnabled$Z', function (enabled) {
C$.superclazz.prototype.setEnabled$Z.apply(this, [enabled]);
this.disabled=!enabled;
});

Clazz.newMeth(C$, 'setBounds', function () {
this.toolbar.revalidate$();
this.$height=this.playButton.getPreferredSize$().height + 8;
var y=this.vidPanel.getHeight$() - this.$height;
var w=this.vidPanel.getWidth$();
this.setBounds$I$I$I$I(0, y, w, this.$height);
this.toolbar.revalidate$();
}, p$2);

Clazz.newMeth(C$, 'createGUI', function () {
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(6,1)));
this.toolbar=Clazz.new_($I$(28,1));
this.toolbar.setFloatable$Z(false);
this.add$java_awt_Component$O(this.toolbar, "South");
this.setBorder$javax_swing_border_Border($I$(18).createEtchedBorder$());
this.playButton=Clazz.new_($I$(29,1).c$$javax_swing_Icon$javax_swing_Icon,[this, null, C$.playIcon, C$.pauseIcon]);
this.playButton.setDisabledIcon$javax_swing_Icon(C$.grayPlayIcon);
this.playButton.addMouseListener$java_awt_event_MouseListener(((P$.VideoPlayer$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled || !this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.isEnabled$() ) return;
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.isSelected$()) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].stop$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
} else {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].play$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
}});
})()
), Clazz.new_($I$(1,1),[this, null],P$.VideoPlayer$4)));
this.playButton.addKeyListener$java_awt_event_KeyListener(((P$.VideoPlayer$5||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled || !this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.isEnabled$() ) return;
if (e.getKeyCode$() == 32) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.isSelected$()) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].stop$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
} else {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].play$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
}}});
})()
), Clazz.new_($I$(9,1),[this, null],P$.VideoPlayer$5)));
this.resetButton=Clazz.new_($I$(29,1).c$$javax_swing_Icon,[this, null, C$.resetIcon]);
this.resetButton.setPressedIcon$javax_swing_Icon(C$.resetIcon);
this.resetButton.addMouseListener$java_awt_event_MouseListener(((P$.VideoPlayer$6||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
this.b$['org.opensourcephysics.media.core.VideoPlayer'].stop$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.setStepNumber$I(0);
p$2.updatePlayButtons$Z.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [false]);
});
})()
), Clazz.new_($I$(1,1),[this, null],P$.VideoPlayer$6)));
var minRate=0.01;
var maxRate=10;
var model=Clazz.new_($I$(30,1).c$$D$D$D$D,[1, 0.01, 10.0, 0.1]);
this.rateSpinner=((P$.VideoPlayer$7||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.JSpinner'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return this.getMinimumSize$();
});

Clazz.newMeth(C$, 'getMinimumSize$', function () {
var dim=C$.superclazz.prototype.getMinimumSize$.apply(this, []);
dim.height=Math.max(this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.getPreferredSize$().height, dim.height);
dim.width=5 * this.getFont$().getSize$() - 10 * $I$(20).getLevel$();
return dim;
});

Clazz.newMeth(C$, 'getMaximumSize$', function () {
return this.getMinimumSize$();
});
})()
), Clazz.new_($I$(31,1).c$$javax_swing_SpinnerModel,[this, null, model],P$.VideoPlayer$7));
var editor=Clazz.new_($I$(32,1).c$$javax_swing_JSpinner$S,[this.rateSpinner, "0%"]);
editor.getTextField$().setHorizontalAlignment$I(2);
editor.getTextField$().setFont$java_awt_Font(Clazz.new_($I$(33,1).c$$S$I$I,["Dialog", 0, 12]));
this.rateSpinner.setEditor$javax_swing_JComponent(editor);
this.rateSpinner.addChangeListener$javax_swing_event_ChangeListener(((P$.VideoPlayer$8||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.ChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
var rate=this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.getValue$();
this.b$['org.opensourcephysics.media.core.VideoPlayer'].setRate$D.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [(rate).valueOf()]);
this.$finals$.model.setStepSize$Number(new Double((rate).valueOf() >= 2  ? 0.5 : (rate).valueOf() >= 0.2  ? 0.1 : 0.01));
});
})()
), Clazz.new_(P$.VideoPlayer$8.$init$,[this, {model:model}])));
editor.getTextField$().addKeyListener$java_awt_event_KeyListener(((P$.VideoPlayer$9||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (e.getKeyCode$() == 10) {
var prev=(this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.getValue$()).doubleValue$();
try {
var s=this.$finals$.editor.getTextField$().getText$();
if (s.endsWith$S("%")) s=s.substring$I$I(0, s.length$() - 1);
var i=Integer.parseInt$S(s);
var rate=Math.max(i / 100.0, 0.01);
rate=Math.min(rate, 10.0);
if (rate != prev ) this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.setValue$O( new Double(rate));
 else {
var r=((prev * 100)|0);
this.$finals$.editor.getTextField$().setText$S(String.valueOf$I(r) + "%");
}} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
var r=((prev * 100)|0);
this.$finals$.editor.getTextField$().setText$S(String.valueOf$I(r) + "%");
} else {
throw ex;
}
}
this.$finals$.editor.getTextField$().selectAll$();
}});
})()
), Clazz.new_($I$(9,1),[this, {editor:editor}],P$.VideoPlayer$9)));
this.stepButton=Clazz.new_($I$(29,1).c$$javax_swing_Icon,[this, null, C$.stepIcon]);
this.stepButton.setDisabledIcon$javax_swing_Icon(C$.grayStepIcon);
this.stepButton.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$10||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
if ((e.getModifiers$() & 1) == 1) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].stop$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
this.b$['org.opensourcephysics.media.core.VideoPlayer'].setStepNumber$I.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [this.b$['org.opensourcephysics.media.core.VideoPlayer'].getStepNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) + 5]);
} else this.b$['org.opensourcephysics.media.core.VideoPlayer'].step$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
});
})()
), Clazz.new_(P$.VideoPlayer$10.$init$,[this, null])));
this.backButton=Clazz.new_($I$(29,1).c$$javax_swing_Icon,[this, null, C$.backIcon]);
this.backButton.setDisabledIcon$javax_swing_Icon(C$.grayBackIcon);
this.backButton.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$11||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
if ((e.getModifiers$() & 1) == 1) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].stop$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
this.b$['org.opensourcephysics.media.core.VideoPlayer'].setStepNumber$I.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [this.b$['org.opensourcephysics.media.core.VideoPlayer'].getStepNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) - 5]);
} else this.b$['org.opensourcephysics.media.core.VideoPlayer'].back$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
});
})()
), Clazz.new_(P$.VideoPlayer$11.$init$,[this, null])));
var stepListener=((P$.VideoPlayer$12||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$12", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
if (e.getSource$() === this.b$['org.opensourcephysics.media.core.VideoPlayer'].stepButton ) {
this.b$['java.awt.Component'].firePropertyChange$S$O$O.apply(this.b$['java.awt.Component'], ["stepbutton", null, $I$(34).TRUE]);
} else {
this.b$['java.awt.Component'].firePropertyChange$S$O$O.apply(this.b$['java.awt.Component'], ["backbutton", null, $I$(34).TRUE]);
}});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
if (e.getSource$() === this.b$['org.opensourcephysics.media.core.VideoPlayer'].stepButton ) {
this.b$['java.awt.Component'].firePropertyChange$S$O$O.apply(this.b$['java.awt.Component'], ["stepbutton", null, $I$(34).FALSE]);
} else {
this.b$['java.awt.Component'].firePropertyChange$S$O$O.apply(this.b$['java.awt.Component'], ["backbutton", null, $I$(34).FALSE]);
}});
})()
), Clazz.new_($I$(1,1),[this, null],P$.VideoPlayer$12));
this.stepButton.addMouseListener$java_awt_event_MouseListener(stepListener);
this.backButton.addMouseListener$java_awt_event_MouseListener(stepListener);
this.readoutListener=((P$.VideoPlayer$13||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$13", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].setReadoutType$S.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [e.getActionCommand$()]);
});
})()
), Clazz.new_(P$.VideoPlayer$13.$init$,[this, null]));
this.goToListener=((P$.VideoPlayer$14||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$14", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].showGoToDialog$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
});
})()
), Clazz.new_(P$.VideoPlayer$14.$init$,[this, null]));
this.timeSetListener=((P$.VideoPlayer$15||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$15", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var clip=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
var response=$I$(4,"showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O",[this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel, $I$(14).getString$S("VideoPlayer.Dialog.SetTime.Message"), $I$(14).getString$S("VideoPlayer.Dialog.SetTime.Title") + " " + this.b$['org.opensourcephysics.media.core.VideoPlayer'].getFrameNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) , -1, null, null, new Double(this.b$['org.opensourcephysics.media.core.VideoPlayer'].getTime$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) / 1000)]);
if (response != null ) {
if (response.equals$O("")) clip.setStartTime$D(NaN);
 else try {
var t=Double.parseDouble$S(response.toString());
var t0=t * 1000 - this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.getTime$();
clip.setStartTime$D(t0);
} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
} else {
throw ex;
}
}
}var inspector=clip.inspector;
if (inspector != null  && inspector.isVisible$() ) {
inspector.t0Field.setValue$D(clip.getStartTime$() / 1000);
}});
})()
), Clazz.new_(P$.VideoPlayer$15.$init$,[this, null]));
this.slider=Clazz.new_($I$(35,1).c$$I$I$I,[0, 0, 0]);
this.slider.setOpaque$Z(false);
this.slider.setMinorTickSpacing$I(1);
this.slider.setSnapToTicks$Z(true);
this.slider.setBorder$javax_swing_border_Border($I$(18).createEmptyBorder$I$I$I$I(0, 2, 0, 2));
this.slider.addChangeListener$javax_swing_event_ChangeListener(((P$.VideoPlayer$16||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$16", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.ChangeListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
var clip=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
var i=this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.getValue$();
if (i < clip.getStartFrameNumber$()) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.setValue$I(clip.getStartFrameNumber$());
} else if (i > clip.getEndFrameNumber$()) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.setValue$I(clip.getEndFrameNumber$());
} else {
var n=clip.frameToStep$I(i);
if (n != this.b$['org.opensourcephysics.media.core.VideoPlayer'].getStepNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) && !this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled ) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].setStepNumber$I.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [n]);
} else if (!clip.includesFrame$I(i)) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.setValue$I(clip.stepToFrame$I(n));
}}});
})()
), Clazz.new_(P$.VideoPlayer$16.$init$,[this, null])));
this.inLabel=Clazz.new_($I$(12,1).c$$javax_swing_Icon,[C$.inOutIcon]);
this.outLabel=Clazz.new_($I$(12,1).c$$javax_swing_Icon,[C$.inOutIcon]);
this.sliderLabels=Clazz.new_($I$(36,1));
this.sliderLabels.put$O$O(Integer.valueOf$I(0), this.inLabel);
this.sliderLabels.put$O$O(Integer.valueOf$I(9), this.outLabel);
this.slider.setLabelTable$java_util_Dictionary(this.sliderLabels);
this.slider.setPaintLabels$Z(true);
var slideMouseListener=this.slider.getMouseListeners$()[0];
this.slider.removeMouseListener$java_awt_event_MouseListener(slideMouseListener);
var slideMouseMotionListener=this.slider.getMouseMotionListeners$()[0];
this.slider.removeMouseMotionListener$java_awt_event_MouseMotionListener(slideMouseMotionListener);
var inOutSetter=((P$.VideoPlayer$17||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$17", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('javax.swing.event.MouseInputAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.inset=0;
},1);

C$.$fields$=[['F',['inset'],'I',['x','maxEndFrame']]]

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
this.b$['org.opensourcephysics.media.core.VideoPlayer'].stop$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
this.maxEndFrame=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getEndFrameNumber$();
if ($I$(37).isPopupTrigger$java_awt_event_InputEvent(e)) {
var listener=((P$.VideoPlayer$17$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$17$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var clip=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
var val=this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.getFrameNumber$();
if ("in".equals$O(e.getActionCommand$())) {
clip.setStartFrameNumber$I$I(val, this.b$['org.opensourcephysics.media.core.VideoPlayer$17'].maxEndFrame);
if (clip.inspector != null  && clip.inspector.isVisible$() ) {
clip.inspector.startField.setValue$D(clip.getStartFrameNumber$());
}} else {
clip.setEndFrameNumber$I(val);
if (clip.inspector != null  && clip.inspector.isVisible$() ) {
clip.inspector.endField.setValue$D(clip.getEndFrameNumber$());
}}this.b$['org.opensourcephysics.media.core.VideoPlayer'].refresh$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
});
})()
), Clazz.new_(P$.VideoPlayer$17$1.$init$,[this, null]));
var popup=Clazz.new_($I$(38,1));
var item=Clazz.new_([$I$(14).getString$S("ClipInspector.Title") + "..."],$I$(39,1).c$$S);
item.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$17$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$17$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
var frame=null;
var c=this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.getTopLevelAncestor$();
if (Clazz.instanceOf(c, "java.awt.Frame")) {
frame=c;
}var inspector=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getClipInspector$org_opensourcephysics_media_core_ClipControl$java_awt_Frame(this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl, frame);
if (inspector.isVisible$()) {
return;
}var p0=Clazz.new_($I$(40,1)).getLocation$();
var loc=inspector.getLocation$();
if ((loc.x == p0.x) && (loc.y == p0.y) ) {
var dim=$I$(41).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - inspector.getBounds$().width)/2|0);
var y=((dim.height - inspector.getBounds$().height)/2|0);
inspector.setLocation$I$I(x, y);
}inspector.initialize$();
inspector.setVisible$Z(true);
});
})()
), Clazz.new_(P$.VideoPlayer$17$2.$init$,[this, null])));
popup.add$javax_swing_JMenuItem(item);
popup.addSeparator$();
var showTrim=false;
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getVideo$() == null  || this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getVideo$().getFrameCount$() == 1 ) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getFrameCount$() > this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getEndFrameNumber$() + 1) {
showTrim=true;
}}if (showTrim) {
var s=$I$(14).getString$S("VideoPlayer.Slider.Popup.Menu.TrimFrames");
item=Clazz.new_($I$(39,1).c$$S,[s]);
item.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$17$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$17$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).trimFrameCount$();
});
})()
), Clazz.new_(P$.VideoPlayer$17$3.$init$,[this, null])));
popup.add$javax_swing_JMenuItem(item);
popup.addSeparator$();
}var frameNum=this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.getFrameNumber$();
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active == null  || this.b$['org.opensourcephysics.media.core.VideoPlayer'].active.equals$O("in") ) {
var s=$I$(14).getString$S("VideoPlayer.Slider.Popup.Menu.SetIn");
s += " (" + frameNum + ")" ;
item=Clazz.new_($I$(39,1).c$$S,[s]);
item.setActionCommand$S("in");
item.addActionListener$java_awt_event_ActionListener(listener);
popup.add$javax_swing_JMenuItem(item);
}if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active == null  || this.b$['org.opensourcephysics.media.core.VideoPlayer'].active.equals$O("out") ) {
var s=$I$(14).getString$S("VideoPlayer.Slider.Popup.Menu.SetOut");
s += " (" + frameNum + ")" ;
item=Clazz.new_($I$(39,1).c$$S,[s]);
item.setActionCommand$S("out");
item.addActionListener$java_awt_event_ActionListener(listener);
popup.add$javax_swing_JMenuItem(item);
}this.b$['org.opensourcephysics.media.core.VideoPlayer'].active=null;
var includeTimeItems=false;
for (var type, $type = 0, $$type = this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutTypes; $type<$$type.length&&((type=($$type[$type])),1);$type++) {
if (type.equals$O("time")) includeTimeItems=true;
}
if (includeTimeItems) {
popup.addSeparator$();
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].getTime$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) != 0 ) {
var s=$I$(14).getString$S("VideoPlayer.Popup.Menu.SetTimeToZero");
item=Clazz.new_($I$(39,1).c$$S,[s]);
item.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$17$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$17$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
var t0=-this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.getTime$();
this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).setStartTime$D(t0);
});
})()
), Clazz.new_(P$.VideoPlayer$17$4.$init$,[this, null])));
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutListener);
popup.add$javax_swing_JMenuItem(item);
}item=Clazz.new_([$I$(14).getString$S("VideoPlayer.Readout.Menu.SetTime")],$I$(39,1).c$$S);
item.setActionCommand$S("time");
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].timeSetListener);
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutListener);
popup.add$javax_swing_JMenuItem(item);
}popup.show$java_awt_Component$I$I(this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider, e.getX$(), e.getY$());
} else if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active == null ) {
this.$finals$.slideMouseListener.mousePressed$java_awt_event_MouseEvent(e);
} else {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].stop$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
this.x=e.getX$();
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active === "in" ) {
var start=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getStartFrameNumber$();
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.setMessage$S($I$(14).getString$S("VideoPlayer.InMarker.ToolTip") + ": " + start );
} else if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active === "out" ) {
var end=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getEndFrameNumber$();
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.setMessage$S($I$(14).getString$S("VideoPlayer.OutMarker.ToolTip") + ": " + end );
}}});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
var clip=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active == null ) this.$finals$.slideMouseListener.mouseReleased$java_awt_event_MouseEvent(e);
 else {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.setMessage$S(null);
}clip.setAdjusting$Z(false);
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.setMouseCursor$java_awt_Cursor($I$(42).getDefaultCursor$());
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
this.$finals$.slideMouseListener.mouseExited$java_awt_event_MouseEvent(e);
this.b$['java.awt.Component'].firePropertyChange$S$O$O.apply(this.b$['java.awt.Component'], ["slider", null, $I$(34).FALSE]);
});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].active=null;
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
var yMin=this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.getHeight$() - this.b$['org.opensourcephysics.media.core.VideoPlayer'].inLabel.getHeight$() - 2 ;
if (this.inset == 0 ) this.inset=this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.getInsets$().left + 7;
var offset=Math.min(0, this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getFrameShift$());
if (e.getY$() > yMin) {
var clip=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
var pixPerFrame=(this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.getWidth$() - 2 * this.inset) / (clip.getFrameCount$() - 1);
var start=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getStartFrameNumber$();
var x=((this.inset + (start + offset) * pixPerFrame)|0);
var hint=" " + $I$(14).getString$S("VideoPlayer.InOutMarker.ToolTip");
if (e.getX$() < x + 8 && e.getX$() > x - 8 ) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].active="in";
this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.setToolTipText$S($I$(14).getString$S("VideoPlayer.InMarker.ToolTip") + ": " + start + hint );
} else {
var end=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getEndFrameNumber$();
x=((this.inset + (end + offset) * pixPerFrame)|0);
if (e.getX$() < x + 8 && e.getX$() > x - 8 ) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].active="out";
this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.setToolTipText$S($I$(14).getString$S("VideoPlayer.OutMarker.ToolTip") + ": " + end + hint );
}}}if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active == null ) {
this.$finals$.slideMouseMotionListener.mouseMoved$java_awt_event_MouseEvent(e);
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.setMouseCursor$java_awt_Cursor($I$(42).getDefaultCursor$());
this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.setToolTipText$S($I$(14).getString$S("VideoPlayer.Slider.ToolTip"));
} else {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.setMouseCursor$java_awt_Cursor($I$(42).getPredefinedCursor$I(12));
}});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active == null ) {
this.$finals$.slideMouseMotionListener.mouseDragged$java_awt_event_MouseEvent(e);
return;
}var clip=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
clip.setAdjusting$Z(true);
var increasing=e.getX$() > this.x;
this.x=e.getX$();
var offset=Math.min(0, this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getFrameShift$());
var val=Math.round((clip.getFrameCount$() - 1) * (e.getX$() - this.inset) / (this.b$['org.opensourcephysics.media.core.VideoPlayer'].slider.getWidth$() - 2 * this.inset));
if (increasing) val=Math.min(val, clip.getFrameCount$() - 1 + this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getStepSize$());
 else val=Math.min(val, clip.getFrameCount$() - 1);
val=Math.max(val - offset, 0);
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active.equals$O("in")) {
var prevStart=clip.getStartFrameNumber$();
if (clip.setStartFrameNumber$I$I(val, this.maxEndFrame)) {
var newStart=clip.getStartFrameNumber$();
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.setMessage$S($I$(14).getString$S("VideoPlayer.InMarker.ToolTip") + ": " + newStart );
if (!clip.isDefaultStartTime) {
var startTime=clip.getStartTime$();
startTime += (newStart - prevStart) * this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.getMeanFrameDuration$();
clip.setStartTime$D(startTime);
}this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.setStepNumber$I(0);
if (clip.inspector != null  && clip.inspector.isVisible$() ) {
clip.inspector.startField.setValue$D(newStart);
clip.inspector.t0Field.setValue$D(clip.getStartTime$() / 1000);
}p$2.updateReadout.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
}} else if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].active.equals$O("out")) {
if (clip.setEndFrameNumber$I(val)) {
var end=clip.getEndFrameNumber$();
this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.setMessage$S($I$(14).getString$S("VideoPlayer.OutMarker.ToolTip") + ": " + end );
this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.setStepNumber$I(clip.getStepCount$() - 1);
if (clip.inspector != null  && clip.inspector.isVisible$() ) {
clip.inspector.endField.setValue$D(clip.getEndFrameNumber$());
}}}});
})()
), Clazz.new_($I$(43,1),[this, {slideMouseListener:slideMouseListener,slideMouseMotionListener:slideMouseMotionListener}],P$.VideoPlayer$17));
this.slider.addMouseListener$java_awt_event_MouseListener(inOutSetter);
this.slider.addMouseMotionListener$java_awt_event_MouseMotionListener(inOutSetter);
var im=this.slider.getInputMap$I(0);
var am=$I$(44).getUIActionMap$javax_swing_JComponent(this.slider);
if (am != null ) {
am.put$O$javax_swing_Action(im.get$javax_swing_KeyStroke($I$(45).getKeyStroke$I$I(33, 0)), null);
am.put$O$javax_swing_Action(im.get$javax_swing_KeyStroke($I$(45).getKeyStroke$I$I(34, 0)), null);
}this.slider.addKeyListener$java_awt_event_KeyListener(((P$.VideoPlayer$18||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$18", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
switch (e.getKeyCode$()) {
case 33:
this.b$['org.opensourcephysics.media.core.VideoPlayer'].back$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
break;
case 34:
this.b$['org.opensourcephysics.media.core.VideoPlayer'].step$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
break;
}
});
})()
), Clazz.new_($I$(9,1),[this, null],P$.VideoPlayer$18)));
this.readout=((P$.VideoPlayer$19||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$19", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load(['org.opensourcephysics.media.core.VideoPlayer','.PlayerButton']), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
var dim=C$.superclazz.prototype.getPreferredSize$.apply(this, []);
dim.height=this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.getPreferredSize$().height;
return dim;
});

Clazz.newMeth(C$, 'getMinimumSize$', function () {
var dim=C$.superclazz.prototype.getMinimumSize$.apply(this, []);
dim.height=this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.getPreferredSize$().height;
return dim;
});

Clazz.newMeth(C$, 'getMaximumSize$', function () {
var dim=C$.superclazz.prototype.getMaximumSize$.apply(this, []);
dim.height=this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.getPreferredSize$().height;
return dim;
});
})()
), Clazz.new_($I$(29,1),[this, null],P$.VideoPlayer$19));
this.readout.setForeground$java_awt_Color(Clazz.new_($I$(3,1).c$$I$I$I,[204, 51, 51]));
this.readout.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$20||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$20", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutTypes.length < 2) {
return;
}var popup=Clazz.new_($I$(38,1));
var displayMenu=Clazz.new_([$I$(14).getString$S("VideoPlayer.Readout.Menu.Display")],$I$(46,1).c$$S);
popup.add$javax_swing_JMenuItem(displayMenu);
var item;
for (var i=0; i < this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutTypes.length; i++) {
var type=this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutTypes[i];
if (type.equals$O("step")) {
item=Clazz.new_([$I$(14).getString$S("VideoPlayer.Readout.MenuItem.Step")],$I$(47,1).c$$S);
item.setSelected$Z(type.equals$O(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutType));
item.setActionCommand$S(type);
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutListener);
displayMenu.add$javax_swing_JMenuItem(item);
} else if (type.equals$O("time")) {
item=Clazz.new_([$I$(14).getString$S("VideoPlayer.Readout.MenuItem.Time")],$I$(47,1).c$$S);
item.setSelected$Z(type.equals$O(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutType));
item.setActionCommand$S(type);
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutListener);
displayMenu.add$javax_swing_JMenuItem(item);
popup.addSeparator$();
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].getTime$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) != 0 ) {
var s=$I$(14).getString$S("VideoPlayer.Popup.Menu.SetTimeToZero");
item=Clazz.new_($I$(39,1).c$$S,[s]);
item.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$20$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$20$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
var t0=-this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl.getTime$();
this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).setStartTime$D(t0);
});
})()
), Clazz.new_(P$.VideoPlayer$20$1.$init$,[this, null])));
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutListener);
popup.add$javax_swing_JMenuItem(item);
}item=Clazz.new_([$I$(14).getString$S("VideoPlayer.Readout.Menu.SetTime")],$I$(39,1).c$$S);
item.setActionCommand$S(type);
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].timeSetListener);
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutListener);
popup.add$javax_swing_JMenuItem(item);
item=Clazz.new_([$I$(14).getString$S("VideoPlayer.Readout.Menu.GoTo") + "..."],$I$(39,1).c$$S);
item.setActionCommand$S(type);
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].goToListener);
popup.add$javax_swing_JMenuItem(item);
} else {
item=Clazz.new_([$I$(14).getString$S("VideoPlayer.Readout.MenuItem.Frame")],$I$(47,1).c$$S);
item.setSelected$Z(type.equals$O(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutType));
item.setActionCommand$S(type);
item.addActionListener$java_awt_event_ActionListener(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readoutListener);
displayMenu.add$javax_swing_JMenuItem(item);
}}
popup.show$java_awt_Component$I$I(this.b$['org.opensourcephysics.media.core.VideoPlayer'].readout, 0, this.b$['org.opensourcephysics.media.core.VideoPlayer'].readout.getHeight$());
});
})()
), Clazz.new_(P$.VideoPlayer$20.$init$,[this, null])));
this.readout.addMouseListener$java_awt_event_MouseListener(((P$.VideoPlayer$21||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$21", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
if ($I$(37).isPopupTrigger$java_awt_event_InputEvent(e)) this.b$['org.opensourcephysics.media.core.VideoPlayer'].readout.doClick$I(0);
});
})()
), Clazz.new_($I$(1,1),[this, null],P$.VideoPlayer$21)));
this.stepSizeButton=((P$.VideoPlayer$22||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$22", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load(['org.opensourcephysics.media.core.VideoPlayer','.PlayerButton']), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getPreferredSize$', function () {
var dim=C$.superclazz.prototype.getPreferredSize$.apply(this, []);
dim.height=this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.getPreferredSize$().height;
return dim;
});

Clazz.newMeth(C$, 'getMinimumSize$', function () {
var dim=C$.superclazz.prototype.getMinimumSize$.apply(this, []);
dim.height=this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.getPreferredSize$().height;
return dim;
});

Clazz.newMeth(C$, 'getMaximumSize$', function () {
var dim=C$.superclazz.prototype.getMaximumSize$.apply(this, []);
dim.height=this.b$['org.opensourcephysics.media.core.VideoPlayer'].rateSpinner.getPreferredSize$().height;
return dim;
});
})()
), Clazz.new_($I$(29,1),[this, null],P$.VideoPlayer$22));
this.stepSizeButton.setForeground$java_awt_Color(Clazz.new_($I$(3,1).c$$I$I$I,[204, 51, 51]));
this.stepSizeButton.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$23||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$23", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
var listener=((P$.VideoPlayer$23$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$23$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var frameNumber=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getFrameNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
var clip=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []);
try {
var n=Integer.parseInt$S(e.getActionCommand$());
clip.setStepSize$I(n);
} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
var cur=String.valueOf$I(this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getStepSize$());
var input=$I$(4,"showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O",[this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel, $I$(14).getString$S("VideoPlayer.Dialog.StepSize.Message"), $I$(14).getString$S("VideoPlayer.Dialog.StepSize.Title"), -1, null, null, cur]);
if (input != null ) {
var n=Integer.parseInt$S(input.toString());
clip.setStepSize$I(n);
}} else {
throw ex;
}
}
this.b$['org.opensourcephysics.media.core.VideoPlayer'].setStepNumber$I.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [clip.frameToStep$I(frameNumber)]);
if (clip.inspector != null  && clip.inspector.isVisible$() ) {
clip.inspector.stepSizeField.setValue$D(clip.getStepSize$());
}});
})()
), Clazz.new_(P$.VideoPlayer$23$1.$init$,[this, null]));
var popup=Clazz.new_($I$(38,1));
for (var i=1; i < 6; i++) {
var item=Clazz.new_([String.valueOf$I(i)],$I$(39,1).c$$S);
item.addActionListener$java_awt_event_ActionListener(listener);
popup.add$javax_swing_JMenuItem(item);
}
popup.addSeparator$();
var item=Clazz.new_([$I$(14).getString$S("VideoPlayer.Button.StepSize.Other")],$I$(39,1).c$$S);
item.addActionListener$java_awt_event_ActionListener(listener);
popup.add$javax_swing_JMenuItem(item);
popup.show$java_awt_Component$I$I(this.b$['org.opensourcephysics.media.core.VideoPlayer'].stepSizeButton, 0, this.b$['org.opensourcephysics.media.core.VideoPlayer'].stepSizeButton.getHeight$());
});
})()
), Clazz.new_(P$.VideoPlayer$23.$init$,[this, null])));
this.stepSizeButton.addMouseListener$java_awt_event_MouseListener(((P$.VideoPlayer$24||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$24", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
if ($I$(37).isPopupTrigger$java_awt_event_InputEvent(e)) this.b$['org.opensourcephysics.media.core.VideoPlayer'].stepSizeButton.doClick$I(0);
});
})()
), Clazz.new_($I$(1,1),[this, null],P$.VideoPlayer$24)));
this.inspectorButton=Clazz.new_($I$(29,1).c$$javax_swing_Icon,[this, null, C$.videoClipIcon]);
this.inspectorButton.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$25||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$25", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['org.opensourcephysics.media.core.VideoPlayer'].disabled) return;
var frame=null;
var c=this.b$['org.opensourcephysics.media.core.VideoPlayer'].vidPanel.getTopLevelAncestor$();
if (Clazz.instanceOf(c, "java.awt.Frame")) {
frame=c;
}var inspector=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getClipInspector$org_opensourcephysics_media_core_ClipControl$java_awt_Frame(this.b$['org.opensourcephysics.media.core.VideoPlayer'].clipControl, frame);
if (inspector.isVisible$()) {
return;
}var p0=Clazz.new_($I$(40,1)).getLocation$();
var loc=inspector.getLocation$();
if ((loc.x == p0.x) && (loc.y == p0.y) ) {
var dim=$I$(41).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - inspector.getBounds$().width)/2|0);
var y=((dim.height - inspector.getBounds$().height)/2|0);
inspector.setLocation$I$I(x, y);
}inspector.initialize$();
inspector.setVisible$Z(true);
});
})()
), Clazz.new_(P$.VideoPlayer$25.$init$,[this, null])));
this.loopButton=Clazz.new_($I$(29,1).c$$javax_swing_Icon$javax_swing_Icon,[this, null, C$.noloopIcon, C$.loopIcon]);
this.loopButton.addMouseListener$java_awt_event_MouseListener(((P$.VideoPlayer$26||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$26", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].setLooping$Z.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [!this.b$['org.opensourcephysics.media.core.VideoPlayer'].loopButton.isSelected$()]);
});
})()
), Clazz.new_($I$(1,1),[this, null],P$.VideoPlayer$26)));
this.loopButton.addKeyListener$java_awt_event_KeyListener(((P$.VideoPlayer$27||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$27", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
if (e.getKeyCode$() == 32) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].setLooping$Z.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], [!this.b$['org.opensourcephysics.media.core.VideoPlayer'].loopButton.isSelected$()]);
}});
})()
), Clazz.new_($I$(9,1),[this, null],P$.VideoPlayer$27)));
this.toolbar.add$java_awt_Component(this.readout);
this.toolbar.add$java_awt_Component(this.rateSpinner);
this.toolbar.add$java_awt_Component(this.resetButton);
this.toolbar.add$java_awt_Component(this.playButton);
this.toolbar.add$java_awt_Component(this.slider);
this.toolbar.add$java_awt_Component(this.backButton);
this.toolbar.add$java_awt_Component(this.stepSizeButton);
this.toolbar.add$java_awt_Component(this.stepButton);
this.toolbar.add$java_awt_Component(this.loopButton);
if (this.inspectorButtonVisible) {
this.toolbar.add$java_awt_Component(this.inspectorButton);
}}, p$2);

Clazz.newMeth(C$, 'updatePlayButtons$Z', function (playing) {
var runner=((P$.VideoPlayer$28||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$28", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
var stepCount=this.b$['org.opensourcephysics.media.core.VideoPlayer'].getVideoClip$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []).getStepCount$();
var canPlay=stepCount > 1;
this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.setEnabled$Z(canPlay && (this.$finals$.playing || this.b$['org.opensourcephysics.media.core.VideoPlayer'].getStepNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) < stepCount - 1 ) );
this.b$['org.opensourcephysics.media.core.VideoPlayer'].stepButton.setEnabled$Z(canPlay && (this.$finals$.playing || this.b$['org.opensourcephysics.media.core.VideoPlayer'].getStepNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) < stepCount - 1 ) );
this.b$['org.opensourcephysics.media.core.VideoPlayer'].backButton.setEnabled$Z(canPlay && (this.$finals$.playing || this.b$['org.opensourcephysics.media.core.VideoPlayer'].getStepNumber$.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer'], []) > 0 ) );
this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.setSelected$Z(this.$finals$.playing);
if (this.$finals$.playing) {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.setToolTipText$S($I$(14).getString$S("VideoPlayer.Button.Pause.ToolTip"));
this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.setPressedIcon$javax_swing_Icon($I$(19).pauseIcon);
this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.setIcon$javax_swing_Icon($I$(19).pauseIcon);
} else {
this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.setToolTipText$S($I$(14).getString$S("VideoPlayer.Button.Play.ToolTip"));
this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.setPressedIcon$javax_swing_Icon($I$(19).playIcon);
this.b$['org.opensourcephysics.media.core.VideoPlayer'].playButton.setIcon$javax_swing_Icon($I$(19).playIcon);
}});
})()
), Clazz.new_(P$.VideoPlayer$28.$init$,[this, {playing:playing}]));
if ($I$(44).isEventDispatchThread$()) runner.run$();
 else $I$(44).invokeLater$Runnable(runner);
}, p$2);

Clazz.newMeth(C$, 'updateLoopButton$Z', function (looping) {
if (looping == this.loopButton.isSelected$() ) {
return;
}this.loopButton.setSelected$Z(looping);
if (looping) {
this.loopButton.setPressedIcon$javax_swing_Icon(C$.loopIcon);
this.loopButton.setIcon$javax_swing_Icon(C$.loopIcon);
} else {
this.loopButton.setPressedIcon$javax_swing_Icon(C$.noloopIcon);
this.loopButton.setIcon$javax_swing_Icon(C$.noloopIcon);
}}, p$2);

Clazz.newMeth(C$, 'updateReadout', function () {
var frameNumber=this.clipControl.getFrameNumber$();
var startFrame=this.getVideoClip$().getStartFrameNumber$();
var endFrame=this.getVideoClip$().getEndFrameNumber$();
if (frameNumber < startFrame) this.clipControl.setStepNumber$I(0);
 else if (frameNumber > endFrame) this.clipControl.setStepNumber$I(this.getVideoClip$().getStepCount$());
this.slider.setValue$I(this.clipControl.getFrameNumber$());
var stepNumber=this.clipControl.getStepNumber$();
var display;
if (this.readoutType.equals$O("step")) {
if (stepNumber < 10) {
display="00" + stepNumber;
} else if (stepNumber < 100) {
display="0" + stepNumber;
} else {
display="" + stepNumber;
}} else if (this.readoutType.equals$O("frame")) {
var n=this.clipControl.getFrameNumber$();
if (n < 10) {
display="00" + n;
} else if (n < 100) {
display="0" + n;
} else {
display="" + n;
}} else {
if (Clazz.instanceOf(C$.timeFormat, "java.text.DecimalFormat")) {
var format=C$.timeFormat;
var dur=this.getMeanStepDuration$();
if (dur < 10 ) {
format.applyPattern$S("0.00E0");
} else if (dur < 100 ) {
format.applyPattern$S("0.000");
} else if (dur < 1000 ) {
format.applyPattern$S("0.00");
} else if (dur < 10000 ) {
format.applyPattern$S("0.0");
} else {
format.applyPattern$S("0.00E0");
}}display=C$.timeFormat.format$D(this.getTime$() / 1000.0);
}this.readout.setText$S(display);
this.rateSpinner.setValue$O(new Double(this.getRate$()));
this.stepSizeButton.setText$S("" + this.getVideoClip$().getStepSize$());
$I$(20,"setFonts$O$I",[this.readout, $I$(20).getLevel$()]);
$I$(20,"setFonts$O$I",[this.rateSpinner, $I$(20).getLevel$()]);
$I$(20,"setFonts$O$I",[this.stepSizeButton, $I$(20).getLevel$()]);
this.stepSizeButton.setToolTipText$S($I$(14).getString$S("VideoPlayer.Button.StepSize.ToolTip"));
this.rateSpinner.setToolTipText$S($I$(14).getString$S("VideoPlayer.Spinner.Rate.ToolTip"));
if (stepNumber == this.getVideoClip$().getStepCount$() - 1) p$2.updatePlayButtons$Z.apply(this, [this.clipControl.isPlaying$()]);
}, p$2);

Clazz.newMeth(C$, 'updateSlider', function () {
var clip=this.getVideoClip$();
this.slider.setMinimum$I(Math.max(0, -clip.getFrameShift$()));
this.slider.setMaximum$I(this.slider.getMinimum$() + clip.getFrameCount$() - 1);
this.sliderLabels.clear$();
this.sliderLabels.put$O$O(Integer.valueOf$I(clip.getStartFrameNumber$()), this.inLabel);
this.sliderLabels.put$O$O(Integer.valueOf$I(clip.getEndFrameNumber$()), this.outLabel);
this.slider.repaint$();
}, p$2);

Clazz.newMeth(C$, 'showGoToDialog$', function () {
if (C$.goToDialog == null ) {
C$.goToDialog=Clazz.new_($I$(48,1).c$$org_opensourcephysics_media_core_VideoPlayer,[this]);
var c=this.getParent$();
while (c != null ){
if (Clazz.instanceOf(c, "javax.swing.JSplitPane")) {
var dim=c.getSize$();
var p=c.getLocationOnScreen$();
var x=((dim.width - C$.goToDialog.getBounds$().width)/2|0);
var y=((dim.height - C$.goToDialog.getBounds$().height)/2|0);
C$.goToDialog.setLocation$I$I(p.x + x, p.y + y);
break;
}c=c.getParent$();
}
} else {
C$.goToDialog.setPlayer$org_opensourcephysics_media_core_VideoPlayer(this);
}C$.goToDialog.setVisible$Z(true);
});

C$.$static$=function(){C$.$static$=0;
C$.timeFormat=$I$(21).getNumberInstance$();
{
var path="/org/opensourcephysics/resources/media/images/in_out.gif";
C$.inOutIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/play.gif";
C$.playIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/play_gray.gif";
C$.grayPlayIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/pause.gif";
C$.pauseIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/reset.gif";
C$.resetIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/looping_on.gif";
C$.loopIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/looping_off.gif";
C$.noloopIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/video_clip.gif";
C$.videoClipIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/step.gif";
C$.stepIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/step_gray.gif";
C$.grayStepIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/back.gif";
C$.backIcon=$I$(22).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/back_gray.gif";
C$.grayBackIcon=$I$(22).getIcon$S(path);
};
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.VideoPlayer, "PlayerButton", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JButton');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.setOpaque$Z(false);
this.setBorderPainted$Z(false);
this.addMouseListener$java_awt_event_MouseListener(((P$.VideoPlayer$PlayerButton$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$PlayerButton$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
this.b$['javax.swing.AbstractButton'].setBorderPainted$Z.apply(this.b$['javax.swing.AbstractButton'], [true]);
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
this.b$['javax.swing.AbstractButton'].setBorderPainted$Z.apply(this.b$['javax.swing.AbstractButton'], [false]);
});
})()
), Clazz.new_($I$(1,1),[this, null],P$.VideoPlayer$PlayerButton$1)));
}, 1);

Clazz.newMeth(C$, 'c$$javax_swing_Icon', function (icon) {
C$.c$.apply(this, []);
this.setIcon$javax_swing_Icon(icon);
}, 1);

Clazz.newMeth(C$, 'c$$javax_swing_Icon$javax_swing_Icon', function (off, on) {
C$.c$.apply(this, []);
this.setIcon$javax_swing_Icon(off);
this.setSelectedIcon$javax_swing_Icon(on);
}, 1);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.VideoPlayer, "GoToDialog", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.error_red=Clazz.new_($I$(3,1).c$$I$I$I,[255, 140, 160]);
},1);

C$.$fields$=[['S',['prevFrame','prevTime','prevStep'],'O',['player','org.opensourcephysics.media.core.VideoPlayer','okButton','javax.swing.JButton','+cancelButton','frameLabel','javax.swing.JLabel','+timeLabel','+stepLabel','frameField','javax.swing.JTextField','+timeField','+stepField','$keyListener','java.awt.event.KeyAdapter','$focusListener','java.awt.event.FocusAdapter','error_red','java.awt.Color']]
,['O',['prev','java.util.HashMap']]]

Clazz.newMeth(C$, 'c$$org_opensourcephysics_media_core_VideoPlayer', function (vidPlayer) {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[$I$(4).getFrameForComponent$java_awt_Component(vidPlayer.vidPanel), true]);C$.$init$.apply(this);
this.setPlayer$org_opensourcephysics_media_core_VideoPlayer(vidPlayer);
var contentPane=Clazz.new_([Clazz.new_($I$(6,1))],$I$(5,1).c$$java_awt_LayoutManager);
this.setContentPane$java_awt_Container(contentPane);
this.okButton=Clazz.new_([$I$(8).getString$S("GUIUtils.Ok")],$I$(7,1).c$$S);
this.okButton.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$GoToDialog$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$GoToDialog$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var input=this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'].stepField.getText$();
if (input != null  && !input.equals$O("") ) try {
var n=Integer.parseInt$S(input);
this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'].player.clipControl.setStepNumber$I(n);
this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'].player.refresh$();
} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
} else {
throw ex;
}
}
this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'].setVisible$Z.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'], [false]);
});
})()
), Clazz.new_(P$.VideoPlayer$GoToDialog$1.$init$,[this, null])));
this.cancelButton=Clazz.new_([$I$(8).getString$S("GUIUtils.Cancel")],$I$(7,1).c$$S);
this.cancelButton.addActionListener$java_awt_event_ActionListener(((P$.VideoPlayer$GoToDialog$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$GoToDialog$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'].setVisible$Z.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'], [false]);
});
})()
), Clazz.new_(P$.VideoPlayer$GoToDialog$2.$init$,[this, null])));
this.$keyListener=((P$.VideoPlayer$GoToDialog$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$GoToDialog$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
var field=e.getSource$();
if (e.getKeyCode$() == 10) {
this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'].okButton.doClick$I(0);
} else {
field.setBackground$java_awt_Color($I$(3).white);
}});

Clazz.newMeth(C$, 'keyReleased$java_awt_event_KeyEvent', function (e) {
var field=e.getSource$();
if (e.getKeyCode$() != 10) {
p$1.setValues$javax_swing_JTextField.apply(this.b$['org.opensourcephysics.media.core.VideoPlayer.GoToDialog'], [field]);
}});
})()
), Clazz.new_($I$(9,1),[this, null],P$.VideoPlayer$GoToDialog$3));
this.$focusListener=((P$.VideoPlayer$GoToDialog$4||
(function(){/*a*/var C$=Clazz.newClass(P$, "VideoPlayer$GoToDialog$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.FocusAdapter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
var field=e.getSource$();
field.setBackground$java_awt_Color($I$(3).white);
});
})()
), Clazz.new_($I$(10,1),[this, null],P$.VideoPlayer$GoToDialog$4));
this.frameField=Clazz.new_($I$(11,1).c$$I,[6]);
this.frameField.addKeyListener$java_awt_event_KeyListener(this.$keyListener);
this.frameField.addFocusListener$java_awt_event_FocusListener(this.$focusListener);
this.timeField=Clazz.new_($I$(11,1).c$$I,[6]);
this.timeField.addKeyListener$java_awt_event_KeyListener(this.$keyListener);
this.timeField.addFocusListener$java_awt_event_FocusListener(this.$focusListener);
this.stepField=Clazz.new_($I$(11,1).c$$I,[6]);
this.stepField.addKeyListener$java_awt_event_KeyListener(this.$keyListener);
this.stepField.addFocusListener$java_awt_event_FocusListener(this.$focusListener);
this.frameLabel=Clazz.new_($I$(12,1));
this.timeLabel=Clazz.new_($I$(12,1));
this.stepLabel=Clazz.new_($I$(12,1));
var box=$I$(13).createVerticalBox$();
var framePanel=Clazz.new_($I$(5,1));
framePanel.add$java_awt_Component(this.frameLabel);
framePanel.add$java_awt_Component(this.frameField);
box.add$java_awt_Component(framePanel);
var timePanel=Clazz.new_($I$(5,1));
timePanel.add$java_awt_Component(this.timeLabel);
timePanel.add$java_awt_Component(this.timeField);
box.add$java_awt_Component(timePanel);
var stepPanel=Clazz.new_($I$(5,1));
stepPanel.add$java_awt_Component(this.stepLabel);
stepPanel.add$java_awt_Component(this.stepField);
box.add$java_awt_Component(stepPanel);
contentPane.add$java_awt_Component$O(box, "Center");
var buttonPanel=Clazz.new_($I$(5,1));
buttonPanel.add$java_awt_Component(this.okButton);
buttonPanel.add$java_awt_Component(this.cancelButton);
contentPane.add$java_awt_Component$O(buttonPanel, "South");
this.refreshGUI$();
this.pack$();
}, 1);

Clazz.newMeth(C$, 'refreshGUI$', function () {
this.setTitle$S($I$(14).getString$S("VideoPlayer.GoToDialog.Title"));
this.okButton.setText$S($I$(8).getString$S("GUIUtils.Ok"));
this.cancelButton.setText$S($I$(8).getString$S("GUIUtils.Cancel"));
this.frameLabel.setText$S($I$(14).getString$S("VideoPlayer.Readout.MenuItem.Frame") + ":");
this.timeLabel.setText$S($I$(14).getString$S("VideoPlayer.Readout.MenuItem.Time") + " (s):");
this.stepLabel.setText$S($I$(14).getString$S("VideoPlayer.Readout.MenuItem.Step") + ":");
var labels=Clazz.new_($I$(15,1));
labels.add$O(this.frameLabel);
labels.add$O(this.timeLabel);
labels.add$O(this.stepLabel);
var frc=Clazz.new_($I$(16,1).c$$java_awt_geom_AffineTransform$Z$Z,[null, false, false]);
var font=this.frameLabel.getFont$();
var w=0;
for (var it=labels.iterator$(); it.hasNext$(); ) {
var next=it.next$();
var rect=font.getStringBounds$S$java_awt_font_FontRenderContext(next.getText$() + " ", frc);
w=Math.max(w, (rect.getWidth$()|0) + 1);
}
var labelSize=Clazz.new_($I$(17,1).c$$I$I,[w, 20]);
for (var it=labels.iterator$(); it.hasNext$(); ) {
var next=it.next$();
next.setBorder$javax_swing_border_Border($I$(18).createEmptyBorder$I$I$I$I(0, 0, 0, 2));
next.setPreferredSize$java_awt_Dimension(labelSize);
next.setHorizontalAlignment$I(11);
}
});

Clazz.newMeth(C$, 'setPlayer$org_opensourcephysics_media_core_VideoPlayer', function (vidPlayer) {
if (this.player != null  && this.player !== vidPlayer  ) {
C$.prev.put$O$O(this.player, Clazz.array(String, -1, [this.prevFrame, this.prevTime, this.prevStep]));
var former=C$.prev.get$O(vidPlayer);
if (former != null ) {
this.prevFrame=former[0];
this.prevTime=former[1];
this.prevStep=former[2];
this.frameField.setText$S(this.prevFrame);
this.timeField.setText$S(this.prevTime);
this.stepField.setText$S(this.prevStep);
}}this.player=vidPlayer;
});

Clazz.newMeth(C$, 'setValues$javax_swing_JTextField', function (inputField) {
var input=inputField.getText$();
if ("".equals$O(input)) {
this.prevFrame="";
this.prevTime="";
this.prevStep="";
} else {
var clip=this.player.getVideoClip$();
if (inputField === this.frameField ) {
this.prevFrame=input;
try {
var frameNum=Integer.parseInt$S(input);
var entered=frameNum;
frameNum=Math.max(clip.getFirstFrameNumber$(), frameNum);
frameNum=Math.min(clip.getEndFrameNumber$(), frameNum);
var stepNum=clip.frameToStep$I(frameNum);
frameNum=clip.stepToFrame$I(stepNum);
var t=this.player.getStepTime$I(stepNum) / 1000;
this.prevTime=$I$(19).timeFormat.format$D(t);
this.prevStep=String.valueOf$I(stepNum);
if (frameNum != entered) {
this.frameField.setBackground$java_awt_Color(this.error_red);
}} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
this.prevTime="";
this.prevStep="";
this.frameField.setBackground$java_awt_Color(this.error_red);
} else {
throw ex;
}
}
} else if (inputField === this.timeField ) {
this.prevTime=input;
try {
input=input.replaceAll$S$S(",", ".");
var t=(Double.valueOf$S(input)).valueOf() * 1000;
var dt=this.player.getMeanStepDuration$();
var n=(((t - clip.getStartTime$()) / dt)|0);
var stepNum=Math.max(0, n);
stepNum=Math.min(stepNum, clip.getStepCount$() - 1);
var frameNum=clip.stepToFrame$I(stepNum);
var tmin=this.player.getFrameTime$I(clip.getFirstFrameNumber$());
var tmax=this.player.getFrameTime$I(clip.getLastFrameNumber$());
if (t < tmin  || t > tmax  ) {
this.timeField.setBackground$java_awt_Color(this.error_red);
}this.prevFrame=String.valueOf$I(frameNum);
this.prevStep=String.valueOf$I(stepNum);
} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
this.prevFrame="";
this.prevStep="";
this.timeField.setBackground$java_awt_Color(this.error_red);
} else {
throw ex;
}
}
} else {
try {
var stepNum=Integer.parseInt$S(input);
stepNum=Math.max(0, stepNum);
stepNum=Math.min(clip.getStepCount$() - 1, stepNum);
var frameNum=clip.stepToFrame$I(stepNum);
var t=this.player.getStepTime$I(stepNum) / 1000;
this.prevFrame=String.valueOf$I(frameNum);
this.prevTime=$I$(19).timeFormat.format$D(t);
this.prevStep=String.valueOf$I(stepNum);
} catch (ex) {
if (Clazz.exceptionOf(ex,"NumberFormatException")){
} else {
throw ex;
}
}
}}this.frameField.setText$S(this.prevFrame);
this.timeField.setText$S(this.prevTime);
this.stepField.setText$S(this.prevStep);
}, p$1);

Clazz.newMeth(C$, 'setVisible$Z', function (vis) {
if (vis) {
this.prevFrame="";
this.prevTime="";
this.prevStep="";
this.frameField.setText$S(this.prevFrame);
this.timeField.setText$S(this.prevTime);
this.stepField.setText$S(this.prevStep);
this.frameField.setBackground$java_awt_Color($I$(3).white);
this.timeField.setBackground$java_awt_Color($I$(3).white);
this.stepField.setBackground$java_awt_Color($I$(3).white);
$I$(20,"setFonts$O$I",[this, $I$(20).getLevel$()]);
this.refreshGUI$();
this.pack$();
}C$.superclazz.prototype.setVisible$Z.apply(this, [vis]);
});

C$.$static$=function(){C$.$static$=0;
C$.prev=Clazz.new_($I$(2,1));
};

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
