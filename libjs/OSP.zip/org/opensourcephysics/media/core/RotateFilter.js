(function(){var P$=Clazz.newPackage("org.opensourcephysics.media.core"),p$1={},I$=[[0,'org.opensourcephysics.media.core.MediaRes','java.awt.Toolkit','javax.swing.Box','javax.swing.ButtonGroup','org.opensourcephysics.media.core.RotateFilter','javax.swing.JRadioButtonMenuItem','javax.swing.BorderFactory','javax.swing.JCheckBox','javax.swing.JPanel','java.awt.BorderLayout','java.awt.FlowLayout','org.opensourcephysics.tools.ResourceLoader',['org.opensourcephysics.media.core.RotateFilter','.Inspector'],'javax.swing.JOptionPane','java.awt.image.BufferedImage',['org.opensourcephysics.media.core.RotateFilter','.Loader']]],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RotateFilter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.opensourcephysics.media.core.Filter');
C$.$classes$=[['Inspector',2],['Loader',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.rotationType=-1;
this.buttons=Clazz.array($I$(6), [4]);
},1);

C$.$fields$=[['Z',['reverse'],'I',['rotationType'],'O',['pixelsIn','int[]','+pixelsOut','inspector','org.opensourcephysics.media.core.RotateFilter.Inspector','buttons','javax.swing.JRadioButtonMenuItem[]','buttonGroup','javax.swing.ButtonGroup','reverseCheckbox','javax.swing.JCheckBox','rotationPanel','javax.swing.JComponent','+reversePanel']]
,['O',['types','int[]','typeNames','String[]','cwIcon','javax.swing.Icon','+ccwIcon']]]

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this);
this.refresh$();
this.hasInspector=true;
}, 1);

Clazz.newMeth(C$, 'getFilteredImage$java_awt_image_BufferedImage', function (sourceImage) {
if (!this.isEnabled$()) {
return sourceImage;
}if (sourceImage !== this.source ) {
p$1.initialize$java_awt_image_BufferedImage.apply(this, [sourceImage]);
}if (sourceImage !== this.input ) {
this.gIn.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.source, 0, 0, null);
}p$1.setOutputToRotate$java_awt_image_BufferedImage.apply(this, [this.input]);
return this.output;
});

Clazz.newMeth(C$, 'setRotationType$I', function (type) {
if (type != this.rotationType) {
this.rotationType=type;
this.source=null;
this.support.firePropertyChange$S$O$O("rotate", null, null);
}}, p$1);

Clazz.newMeth(C$, 'getInspector$', function () {
var myInspector=this.inspector;
if (myInspector == null ) {
myInspector=Clazz.new_($I$(13,1),[this, null]);
}if (myInspector.isModal$() && this.vidPanel != null  ) {
this.frame=$I$(14).getFrameForComponent$java_awt_Component(this.vidPanel);
myInspector.setVisible$Z(false);
myInspector.dispose$();
myInspector=Clazz.new_($I$(13,1),[this, null]);
}this.inspector=myInspector;
this.inspector.initialize$();
return this.inspector;
});

Clazz.newMeth(C$, 'refresh$', function () {
C$.superclazz.prototype.refresh$.apply(this, []);
if (this.inspector != null ) {
this.inspector.setTitle$S($I$(1).getString$S("Filter.Rotate.Title"));
this.rotationPanel.setBorder$javax_swing_border_Border($I$(7,"createTitledBorder$S",[$I$(1).getString$S("Filter.Rotate.Label.Rotate")]));
for (var i=0; i < this.buttons.length; i++) {
this.buttons[i].setEnabled$Z(this.isEnabled$());
this.buttons[i].setText$S($I$(1).getString$S("Filter.Rotate.Button." + C$.typeNames[i]));
}
this.reverseCheckbox.setText$S($I$(1).getString$S("Filter.Rotate.Checkbox.Reverse"));
this.reverseCheckbox.setSelected$Z(this.reverse);
}});

Clazz.newMeth(C$, 'initialize$java_awt_image_BufferedImage', function (image) {
this.source=image;
this.w=this.source.getWidth$();
this.h=this.source.getHeight$();
this.pixelsIn=Clazz.array(Integer.TYPE, [this.w * this.h]);
this.pixelsOut=Clazz.array(Integer.TYPE, [this.w * this.h]);
if (this.rotationType == 1 || this.rotationType == 0 ) this.output=Clazz.new_($I$(15,1).c$$I$I$I,[this.h, this.w, 1]);
 else this.output=Clazz.new_($I$(15,1).c$$I$I$I,[this.w, this.h, 1]);
if (this.source.getType$() == 1) {
this.input=this.source;
} else {
this.input=Clazz.new_($I$(15,1).c$$I$I$I,[this.w, this.h, 1]);
this.gIn=this.input.createGraphics$();
}}, p$1);

Clazz.newMeth(C$, 'setOutputToRotate$java_awt_image_BufferedImage', function (image) {
image.getRaster$().getDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixelsIn);
var last=this.w * this.h - 1;
if (this.rotationType > -1 || this.reverse ) {
for (var i=0; i < this.pixelsIn.length; i++) {
if (this.rotationType == -1) {
var row=(i/this.w|0);
var col=this.w - (i % this.w) - 1 ;
this.pixelsOut[this.w * row + col]=this.pixelsIn[i];
} else if (this.rotationType == 1) {
if (this.reverse) {
var col=this.h - ((i/this.w|0)) - 1 ;
var row=this.w - (i % this.w) - 1 ;
this.pixelsOut[this.h * row + col]=this.pixelsIn[i];
} else {
var col=this.h - ((i/this.w|0)) - 1 ;
var row=i % this.w;
this.pixelsOut[this.h * row + col]=this.pixelsIn[i];
}} else if (this.rotationType == 0) {
if (this.reverse) {
var col=(i/this.w|0);
var row=i % this.w;
this.pixelsOut[this.h * row + col]=this.pixelsIn[i];
} else {
var col=(i/this.w|0);
var row=this.w - (i % this.w) - 1 ;
this.pixelsOut[this.h * row + col]=this.pixelsIn[i];
}} else {
if (this.reverse) {
var row=this.h - ((i/this.w|0)) - 1 ;
var col=i % this.w;
this.pixelsOut[this.w * row + col]=this.pixelsIn[i];
} else this.pixelsOut[last - i]=this.pixelsIn[i];
}}
}if (this.rotationType == -1 && !this.reverse ) this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixelsIn);
 else if (this.rotationType == 1 || this.rotationType == 0 ) this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.h, this.w, this.pixelsOut);
 else this.output.getRaster$().setDataElements$I$I$I$I$O(0, 0, this.w, this.h, this.pixelsOut);
}, p$1);

Clazz.newMeth(C$, 'getLoader$', function () {
return Clazz.new_($I$(16,1));
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.types=Clazz.array(Integer.TYPE, -1, [-1, 0, 1, 2]);
C$.typeNames=Clazz.array(String, -1, ["None", "CCW", "CW", "180"]);
{
var path="/org/opensourcephysics/resources/media/images/cw.gif";
C$.cwIcon=$I$(12).getIcon$S(path);
path="/org/opensourcephysics/resources/media/images/ccw.gif";
C$.ccwIcon=$I$(12).getIcon$S(path);
};
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.RotateFilter, "Inspector", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.JDialog');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_Frame$Z.apply(this,[this.this$0.frame, !(Clazz.instanceOf(this.this$0.frame, "org.opensourcephysics.display.OSPFrame"))]);C$.$init$.apply(this);
this.setResizable$Z(false);
this.createGUI$();
this.setTitle$S($I$(1).getString$S("Filter.Rotate.Title"));
this.this$0.refresh$.apply(this.this$0, []);
this.pack$();
var rect=this.getBounds$();
var dim=$I$(2).getDefaultToolkit$().getScreenSize$();
var x=((dim.width - rect.width)/2|0);
var y=((dim.height - rect.height)/2|0);
this.setLocation$I$I(x, y);
}, 1);

Clazz.newMeth(C$, 'createGUI$', function () {
var leftBorder=40;
this.this$0.rotationPanel=$I$(3).createVerticalBox$();
this.this$0.buttonGroup=Clazz.new_($I$(4,1));
var selector=((P$.RotateFilter$Inspector$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "RotateFilter$Inspector$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
for (var i=0; i < this.b$['org.opensourcephysics.media.core.RotateFilter'].buttons.length; i++) {
if (this.b$['org.opensourcephysics.media.core.RotateFilter'].buttons[i].isSelected$()) {
p$1.setRotationType$I.apply(this.b$['org.opensourcephysics.media.core.RotateFilter'], [$I$(5).types[i]]);
break;
}}
});
})()
), Clazz.new_(P$.RotateFilter$Inspector$1.$init$,[this, null]));
for (var i=0; i < this.this$0.buttons.length; i++) {
this.this$0.buttons[i]=Clazz.new_($I$(6,1));
this.this$0.buttons[i].setSelected$Z(this.this$0.rotationType == $I$(5).types[i]);
this.this$0.buttons[i].addActionListener$java_awt_event_ActionListener(selector);
this.this$0.buttons[i].setBorder$javax_swing_border_Border($I$(7).createEmptyBorder$I$I$I$I(2, leftBorder, 2, 2));
this.this$0.buttons[i].setHorizontalTextPosition$I(2);
if ($I$(5).types[i] == 1) this.this$0.buttons[i].setIcon$javax_swing_Icon($I$(5).cwIcon);
 else if ($I$(5).types[i] == 0) this.this$0.buttons[i].setIcon$javax_swing_Icon($I$(5).ccwIcon);
this.this$0.buttonGroup.add$javax_swing_AbstractButton(this.this$0.buttons[i]);
this.this$0.rotationPanel.add$java_awt_Component(this.this$0.buttons[i]);
}
this.this$0.reversePanel=$I$(3).createVerticalBox$();
this.this$0.reverseCheckbox=Clazz.new_($I$(8,1));
this.this$0.reverseCheckbox.addActionListener$java_awt_event_ActionListener(((P$.RotateFilter$Inspector$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "RotateFilter$Inspector$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.media.core.RotateFilter'].reverse=this.b$['org.opensourcephysics.media.core.RotateFilter'].reverseCheckbox.isSelected$();
this.b$['org.opensourcephysics.media.core.RotateFilter'].support.firePropertyChange$S$O$O("rotate", null, null);
});
})()
), Clazz.new_(P$.RotateFilter$Inspector$2.$init$,[this, null])));
this.this$0.reversePanel.add$java_awt_Component(this.this$0.reverseCheckbox);
this.this$0.reverseCheckbox.setBorder$javax_swing_border_Border($I$(7).createEmptyBorder$I$I$I$I(2, leftBorder + 7, 2, 2));
var contentPane=Clazz.new_([Clazz.new_($I$(10,1))],$I$(9,1).c$$java_awt_LayoutManager);
this.setContentPane$java_awt_Container(contentPane);
contentPane.add$java_awt_Component$O(this.this$0.rotationPanel, "North");
contentPane.add$java_awt_Component$O(this.this$0.reversePanel, "Center");
var buttonbar=Clazz.new_([Clazz.new_($I$(11,1))],$I$(9,1).c$$java_awt_LayoutManager);
buttonbar.add$java_awt_Component(this.this$0.ableButton);
buttonbar.add$java_awt_Component(this.this$0.closeButton);
contentPane.add$java_awt_Component$O(buttonbar, "South");
});

Clazz.newMeth(C$, 'initialize$', function () {
this.this$0.refresh$.apply(this.this$0, []);
this.updateDisplay$();
});

Clazz.newMeth(C$, 'updateDisplay$', function () {
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.RotateFilter, "Loader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['org.opensourcephysics.controls.XML','org.opensourcephysics.controls.XML.ObjectLoader']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'saveObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
if (filter.rotationType > -1) control.setValue$S$O("rotation", $I$(5).typeNames[filter.rotationType + 1]);
control.setValue$S$Z("reverse", filter.reverse);
if ((filter.frame != null ) && (filter.inspector != null ) && filter.inspector.isVisible$()  ) {
var x=filter.inspector.getLocation$().x - filter.frame.getLocation$().x;
var y=filter.inspector.getLocation$().y - filter.frame.getLocation$().y;
control.setValue$S$I("inspector_x", x);
control.setValue$S$I("inspector_y", y);
}});

Clazz.newMeth(C$, 'createObject$org_opensourcephysics_controls_XMLControl', function (control) {
return Clazz.new_($I$(5,1));
});

Clazz.newMeth(C$, 'loadObject$org_opensourcephysics_controls_XMLControl$O', function (control, obj) {
var filter=obj;
var typeName=control.getString$S("rotation");
for (var i=0; i < $I$(5).typeNames.length; i++) {
if ($I$(5).typeNames[i].equals$O(typeName)) filter.rotationType=$I$(5).types[i];
}
filter.reverse=control.getBoolean$S("reverse");
filter.inspectorX=control.getInt$S("inspector_x");
filter.inspectorY=control.getInt$S("inspector_y");
return obj;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-28 10:19:01 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
