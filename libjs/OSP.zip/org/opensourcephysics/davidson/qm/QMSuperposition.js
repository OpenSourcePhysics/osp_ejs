(function(){var P$=Clazz.newPackage("org.opensourcephysics.davidson.qm"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "QMSuperposition", null, null, 'davidson.qm.QMWavefunction');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-04 08:06:32 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
