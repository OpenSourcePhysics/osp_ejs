(function(){var P$=Clazz.newPackage("org.opensourcephysics.numerics"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ODESolver");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
