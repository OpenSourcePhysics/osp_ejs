(function(){var P$=Clazz.newPackage("org.opensourcephysics.frames"),I$=[[0,'org.opensourcephysics.display2d.VectorPlot','org.opensourcephysics.display.PlottingPanel','java.awt.Dimension','org.opensourcephysics.display.InteractivePanel','org.opensourcephysics.display.DisplayRes','javax.swing.JMenu','javax.swing.JMenuItem','javax.swing.KeyStroke','org.opensourcephysics.display.DrawingFrame','org.opensourcephysics.display2d.ArrayData','org.opensourcephysics.display2d.GridTableFrame']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Vector2DFrame", null, 'org.opensourcephysics.display.DrawingFrame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.plot=Clazz.new_($I$(1,1).c$$org_opensourcephysics_display2d_GridData,[null]);
},1);

C$.$fields$=[['O',['gridData','org.opensourcephysics.display2d.GridData','plot','org.opensourcephysics.display2d.VectorPlot','tableFrame','org.opensourcephysics.display2d.GridTableFrame']]]

Clazz.newMeth(C$, 'c$$S$S$S', function (xlabel, ylabel, frameTitle) {
;C$.superclazz.c$$org_opensourcephysics_display_DrawingPanel.apply(this,[Clazz.new_($I$(2,1).c$$S$S$S,[xlabel, ylabel, null])]);C$.$init$.apply(this);
this.drawingPanel.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(3,1).c$$I$I,[350, 350]));
this.setTitle$S(frameTitle);
this.plot.setShowGridLines$Z(false);
(this.drawingPanel).getAxes$().setShowMajorXGrid$Z(false);
(this.drawingPanel).getAxes$().setShowMajorYGrid$Z(false);
this.drawingPanel.addDrawable$org_opensourcephysics_display_Drawable(this.plot);
this.addMenuItems$();
this.setAnimated$Z(true);
this.setAutoclear$Z(true);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (frameTitle) {
;C$.superclazz.c$$org_opensourcephysics_display_DrawingPanel.apply(this,[Clazz.new_($I$(4,1))]);C$.$init$.apply(this);
this.setTitle$S(frameTitle);
this.plot.setShowGridLines$Z(false);
this.drawingPanel.addDrawable$org_opensourcephysics_display_Drawable(this.plot);
this.addMenuItems$();
this.setAnimated$Z(true);
this.setAutoclear$Z(true);
}, 1);

Clazz.newMeth(C$, 'addMenuItems$', function () {
var menuBar=this.getJMenuBar$();
if (menuBar == null ) {
return;
}var helpMenu=this.removeMenu$S($I$(5).getString$S("DrawingFrame.Help_menu_item"));
var menu=this.getMenu$S($I$(5).getString$S("DrawingFrame.Views_menu"));
if (menu == null ) {
menu=Clazz.new_([$I$(5).getString$S("DrawingFrame.Views_menu")],$I$(6,1).c$$S);
menuBar.add$javax_swing_JMenu(menu);
menuBar.validate$();
} else {
menu.addSeparator$();
}if (helpMenu != null ) {
menuBar.add$javax_swing_JMenu(helpMenu);
}var tableItem=Clazz.new_([$I$(5).getString$S("GUIUtils.Legend")],$I$(7,1).c$$S);
var tableListener=((P$.Vector2DFrame$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "Vector2DFrame$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.frames.Vector2DFrame'].plot.showLegend$();
});
})()
), Clazz.new_(P$.Vector2DFrame$1.$init$,[this, null]));
tableItem.addActionListener$java_awt_event_ActionListener(tableListener);
menu.add$javax_swing_JMenuItem(tableItem);
menu.addSeparator$();
tableItem=Clazz.new_([$I$(5).getString$S("DrawingFrame.DataTable_menu_item")],$I$(7,1).c$$S);
tableItem.setAccelerator$javax_swing_KeyStroke($I$(8,"getKeyStroke$I$I",["T".$c(), $I$(9).MENU_SHORTCUT_KEY_MASK]));
var actionListener=((P$.Vector2DFrame$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "Vector2DFrame$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['org.opensourcephysics.frames.Vector2DFrame'].showDataTable$Z.apply(this.b$['org.opensourcephysics.frames.Vector2DFrame'], [true]);
});
})()
), Clazz.new_(P$.Vector2DFrame$2.$init$,[this, null]));
tableItem.addActionListener$java_awt_event_ActionListener(actionListener);
menu.add$javax_swing_JMenuItem(tableItem);
if ((this.drawingPanel != null ) && (this.drawingPanel.getPopupMenu$() != null ) ) {
var item=Clazz.new_([$I$(5).getString$S("DrawingFrame.DataTable_menu_item")],$I$(7,1).c$$S);
item.addActionListener$java_awt_event_ActionListener(actionListener);
this.drawingPanel.getPopupMenu$().add$javax_swing_JMenuItem(item);
}});

Clazz.newMeth(C$, 'clearDrawables$', function () {
this.drawingPanel.clear$();
this.drawingPanel.addDrawable$org_opensourcephysics_display_Drawable(this.plot);
});

Clazz.newMeth(C$, 'getDrawables$', function () {
var list=C$.superclazz.prototype.getDrawables$.apply(this, []);
list.remove$O(this.plot);
return list;
});

Clazz.newMeth(C$, 'indexToX$I', function (i) {
if (this.gridData == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Data has not been set.  Invoke setAll before invoking this method."]);
}return this.gridData.indexToX$I(i);
});

Clazz.newMeth(C$, 'indexToY$I', function (i) {
if (this.gridData == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Data has not been set.  Invoke setAll before invoking this method."]);
}return this.gridData.indexToY$I(i);
});

Clazz.newMeth(C$, 'xToIndex$D', function (x) {
if (this.gridData == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Data has not been set.  Invoke setAll before invoking this method."]);
}return this.gridData.xToIndex$D(x);
});

Clazz.newMeth(C$, 'yToIndex$D', function (y) {
if (this.gridData == null ) {
throw Clazz.new_(Clazz.load('IllegalStateException').c$$S,["Data has not been set.  Invoke setAll before invoking this method."]);
}return this.gridData.yToIndex$D(y);
});

Clazz.newMeth(C$, 'getNx$', function () {
if (this.gridData == null ) {
return 0;
}return this.gridData.getNx$();
});

Clazz.newMeth(C$, 'getNy$', function () {
if (this.gridData == null ) {
return 0;
}return this.gridData.getNy$();
});

Clazz.newMeth(C$, 'getDrawables$Class', function (c) {
var list=C$.superclazz.prototype.getDrawables$Class.apply(this, [c]);
list.remove$O(this.plot);
return list;
});

Clazz.newMeth(C$, 'clearData$', function () {
if (this.gridData != null ) {
this.setAll$DAAA(Clazz.array(Double.TYPE, [2, this.gridData.getNx$(), this.gridData.getNy$()]));
}this.drawingPanel.invalidateImage$();
});

Clazz.newMeth(C$, 'resizeGrid$I$I', function (nx, ny) {
var xmin;
var xmax;
var ymin;
var ymax;
var cellScale=false;
if (this.gridData == null ) {
xmin=this.drawingPanel.getPreferredXMin$();
xmax=this.drawingPanel.getPreferredXMax$();
ymin=this.drawingPanel.getPreferredYMin$();
ymax=this.drawingPanel.getPreferredYMax$();
} else {
xmin=this.gridData.getLeft$();
xmax=this.gridData.getRight$();
ymin=this.gridData.getBottom$();
ymax=this.gridData.getTop$();
cellScale=this.gridData.isCellData$();
}this.gridData=Clazz.new_($I$(10,1).c$$I$I$I,[nx, ny, 3]);
this.gridData.setComponentName$I$S(0, "magnitude");
this.gridData.setComponentName$I$S(1, "x component");
this.gridData.setComponentName$I$S(2, "y component");
if (cellScale) {
this.gridData.setCellScale$D$D$D$D(xmin, xmax, ymin, ymax);
} else {
this.gridData.setScale$D$D$D$D(xmin, xmax, ymin, ymax);
}this.plot.setGridData$org_opensourcephysics_display2d_GridData(this.gridData);
this.plot.update$();
if ((this.tableFrame != null ) && this.tableFrame.isShowing$() ) {
this.tableFrame.refreshTable$();
}this.drawingPanel.invalidateImage$();
this.drawingPanel.repaint$();
});

Clazz.newMeth(C$, 'setRow$I$DAA', function (row, vals) {
if (this.gridData.getNx$() != vals.length) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Row data length does not match grid size."]);
}var re=this.gridData.getData$()[1][row];
var im=this.gridData.getData$()[2][row];
var phase=this.gridData.getData$()[0][row];
System.arraycopy$O$I$O$I$I(vals[0], 0, re, 0, vals.length);
System.arraycopy$O$I$O$I$I(vals[1], 0, im, 0, vals.length);
for (var j=0, ny=phase.length; j < ny; j++) {
phase[j]=Math.atan2(re[j], im[j]);
}
this.plot.update$();
if ((this.tableFrame != null ) && this.tableFrame.isShowing$() ) {
this.tableFrame.refreshTable$();
}});

Clazz.newMeth(C$, 'setAll$DAAA$D$D$D$D', function (vals, xmin, xmax, ymin, ymax) {
this.setAll$DAAA(vals);
if (this.gridData.isCellData$()) {
this.gridData.setCellScale$D$D$D$D(xmin, xmax, ymin, ymax);
} else {
this.gridData.setScale$D$D$D$D(xmin, xmax, ymin, ymax);
}});

Clazz.newMeth(C$, 'setAll$DAAA', function (vals) {
if ((this.gridData == null ) || (this.gridData.getNx$() != vals.length) || (this.gridData.getNy$() != vals[0].length)  ) {
this.resizeGrid$I$I(vals[0].length, vals[0][0].length);
}var colorValue=this.gridData.getData$()[0];
var xComp=this.gridData.getData$()[1];
var yComp=this.gridData.getData$()[2];
var ny=vals[0][0].length;
for (var i=0, nx=vals[0].length; i < nx; i++) {
for (var j=0; j < ny; j++) {
colorValue[i][j]=Math.sqrt(vals[0][i][j] * vals[0][i][j] + vals[1][i][j] * vals[1][i][j]);
xComp[i][j]=(colorValue[i][j] == 0 ) ? 0 : vals[0][i][j] / colorValue[i][j];
yComp[i][j]=(colorValue[i][j] == 0 ) ? 0 : vals[1][i][j] / colorValue[i][j];
}
}
this.plot.update$();
if ((this.tableFrame != null ) && this.tableFrame.isShowing$() ) {
this.tableFrame.refreshTable$();
}this.drawingPanel.invalidateImage$();
});

Clazz.newMeth(C$, 'setZRange$Z$D$D', function (isAutoscale, floor, ceil) {
this.plot.setAutoscaleZ$Z$D$D(isAutoscale, floor, ceil);
});

Clazz.newMeth(C$, 'showDataTable$Z', function (show) {
if (show) {
if ((this.tableFrame == null ) || !this.tableFrame.isDisplayable$() ) {
if (this.gridData == null ) {
return;
}this.tableFrame=Clazz.new_($I$(11,1).c$$org_opensourcephysics_display2d_GridData,[this.gridData]);
this.tableFrame.setTitle$S($I$(5).getString$S("Vector2DFrame.Title"));
this.tableFrame.setDefaultCloseOperation$I(2);
}this.tableFrame.refreshTable$();
this.tableFrame.setVisible$Z(true);
} else {
this.tableFrame.setVisible$Z(false);
this.tableFrame.dispose$();
this.tableFrame=null;
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-04 17:55:27 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
